'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var require$$1 = require('path');
var require$$2 = require('fs');
var url = require('url');
var crypto = require('crypto');
var util$2 = require('util');
var buffer = require('buffer');
var http = require('http');
var os = require('os');
var child_process = require('child_process');
var stream = require('stream');
var https = require('https');
require('http2');
var process$1 = require('process');

function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

var require$$1__default = /*#__PURE__*/_interopDefaultLegacy(require$$1);
var require$$2__default = /*#__PURE__*/_interopDefaultLegacy(require$$2);
var crypto__default = /*#__PURE__*/_interopDefaultLegacy(crypto);

function getAugmentedNamespace(n) {
	if (n.__esModule) return n;
	var a = Object.defineProperty({}, '__esModule', {value: true});
	Object.keys(n).forEach(function (k) {
		var d = Object.getOwnPropertyDescriptor(n, k);
		Object.defineProperty(a, k, d.get ? d : {
			enumerable: true,
			get: function () {
				return n[k];
			}
		});
	});
	return a;
}

function createCommonjsModule(fn) {
  var module = { exports: {} };
	return fn(module, module.exports), module.exports;
}

/* -*- Mode: js; js-indent-level: 2; -*- */

/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */
var intToCharMap = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'.split('');
/**
 * Encode an integer in the range of 0 to 63 to a single base 64 digit.
 */

var encode = function (number) {
  if (0 <= number && number < intToCharMap.length) {
    return intToCharMap[number];
  }

  throw new TypeError("Must be between 0 and 63: " + number);
};
/**
 * Decode a single base 64 character code digit to an integer. Returns -1 on
 * failure.
 */


var decode = function (charCode) {
  var bigA = 65; // 'A'

  var bigZ = 90; // 'Z'

  var littleA = 97; // 'a'

  var littleZ = 122; // 'z'

  var zero = 48; // '0'

  var nine = 57; // '9'

  var plus = 43; // '+'

  var slash = 47; // '/'

  var littleOffset = 26;
  var numberOffset = 52; // 0 - 25: ABCDEFGHIJKLMNOPQRSTUVWXYZ

  if (bigA <= charCode && charCode <= bigZ) {
    return charCode - bigA;
  } // 26 - 51: abcdefghijklmnopqrstuvwxyz


  if (littleA <= charCode && charCode <= littleZ) {
    return charCode - littleA + littleOffset;
  } // 52 - 61: 0123456789


  if (zero <= charCode && charCode <= nine) {
    return charCode - zero + numberOffset;
  } // 62: +


  if (charCode == plus) {
    return 62;
  } // 63: /


  if (charCode == slash) {
    return 63;
  } // Invalid base64 digit.


  return -1;
};

var base64 = {
  encode: encode,
  decode: decode
};

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 *
 * Based on the Base 64 VLQ implementation in Closure Compiler:
 * https://code.google.com/p/closure-compiler/source/browse/trunk/src/com/google/debugging/sourcemap/Base64VLQ.java
 *
 * Copyright 2011 The Closure Compiler Authors. All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *  * Neither the name of Google Inc. nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
// A single base 64 digit can contain 6 bits of data. For the base 64 variable
// length quantities we use in the source map spec, the first bit is the sign,
// the next four bits are the actual value, and the 6th bit is the
// continuation bit. The continuation bit tells us whether there are more
// digits in this value following this digit.
//
//   Continuation
//   |    Sign
//   |    |
//   V    V
//   101011

var VLQ_BASE_SHIFT = 5; // binary: 100000

var VLQ_BASE = 1 << VLQ_BASE_SHIFT; // binary: 011111

var VLQ_BASE_MASK = VLQ_BASE - 1; // binary: 100000

var VLQ_CONTINUATION_BIT = VLQ_BASE;
/**
 * Converts from a two-complement value to a value where the sign bit is
 * placed in the least significant bit.  For example, as decimals:
 *   1 becomes 2 (10 binary), -1 becomes 3 (11 binary)
 *   2 becomes 4 (100 binary), -2 becomes 5 (101 binary)
 */

function toVLQSigned(aValue) {
  return aValue < 0 ? (-aValue << 1) + 1 : (aValue << 1) + 0;
}
/**
 * Converts to a two-complement value from a value where the sign bit is
 * placed in the least significant bit.  For example, as decimals:
 *   2 (10 binary) becomes 1, 3 (11 binary) becomes -1
 *   4 (100 binary) becomes 2, 5 (101 binary) becomes -2
 */


function fromVLQSigned(aValue) {
  var isNegative = (aValue & 1) === 1;
  var shifted = aValue >> 1;
  return isNegative ? -shifted : shifted;
}
/**
 * Returns the base 64 VLQ encoded value.
 */


var encode$1 = function base64VLQ_encode(aValue) {
  var encoded = "";
  var digit;
  var vlq = toVLQSigned(aValue);

  do {
    digit = vlq & VLQ_BASE_MASK;
    vlq >>>= VLQ_BASE_SHIFT;

    if (vlq > 0) {
      // There are still more digits in this value, so we must make sure the
      // continuation bit is marked.
      digit |= VLQ_CONTINUATION_BIT;
    }

    encoded += base64.encode(digit);
  } while (vlq > 0);

  return encoded;
};
/**
 * Decodes the next base 64 VLQ value from the given string and returns the
 * value and the rest of the string via the out parameter.
 */


var decode$1 = function base64VLQ_decode(aStr, aIndex, aOutParam) {
  var strLen = aStr.length;
  var result = 0;
  var shift = 0;
  var continuation, digit;

  do {
    if (aIndex >= strLen) {
      throw new Error("Expected more digits in base 64 VLQ value.");
    }

    digit = base64.decode(aStr.charCodeAt(aIndex++));

    if (digit === -1) {
      throw new Error("Invalid base64 digit: " + aStr.charAt(aIndex - 1));
    }

    continuation = !!(digit & VLQ_CONTINUATION_BIT);
    digit &= VLQ_BASE_MASK;
    result = result + (digit << shift);
    shift += VLQ_BASE_SHIFT;
  } while (continuation);

  aOutParam.value = fromVLQSigned(result);
  aOutParam.rest = aIndex;
};

var base64Vlq = {
  encode: encode$1,
  decode: decode$1
};

/* -*- Mode: js; js-indent-level: 2; -*- */
var util = createCommonjsModule(function (module, exports) {
  /*
   * Copyright 2011 Mozilla Foundation and contributors
   * Licensed under the New BSD license. See LICENSE or:
   * http://opensource.org/licenses/BSD-3-Clause
   */

  /**
   * This is a helper function for getting values from parameter/options
   * objects.
   *
   * @param args The object we are extracting values from
   * @param name The name of the property we are getting.
   * @param defaultValue An optional value to return if the property is missing
   * from the object. If this is not specified and the property is missing, an
   * error will be thrown.
   */
  function getArg(aArgs, aName, aDefaultValue) {
    if (aName in aArgs) {
      return aArgs[aName];
    } else if (arguments.length === 3) {
      return aDefaultValue;
    } else {
      throw new Error('"' + aName + '" is a required argument.');
    }
  }

  exports.getArg = getArg;
  var urlRegexp = /^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.-]*)(?::(\d+))?(.*)$/;
  var dataUrlRegexp = /^data:.+\,.+$/;

  function urlParse(aUrl) {
    var match = aUrl.match(urlRegexp);

    if (!match) {
      return null;
    }

    return {
      scheme: match[1],
      auth: match[2],
      host: match[3],
      port: match[4],
      path: match[5]
    };
  }

  exports.urlParse = urlParse;

  function urlGenerate(aParsedUrl) {
    var url = '';

    if (aParsedUrl.scheme) {
      url += aParsedUrl.scheme + ':';
    }

    url += '//';

    if (aParsedUrl.auth) {
      url += aParsedUrl.auth + '@';
    }

    if (aParsedUrl.host) {
      url += aParsedUrl.host;
    }

    if (aParsedUrl.port) {
      url += ":" + aParsedUrl.port;
    }

    if (aParsedUrl.path) {
      url += aParsedUrl.path;
    }

    return url;
  }

  exports.urlGenerate = urlGenerate;
  /**
   * Normalizes a path, or the path portion of a URL:
   *
   * - Replaces consecutive slashes with one slash.
   * - Removes unnecessary '.' parts.
   * - Removes unnecessary '<dir>/..' parts.
   *
   * Based on code in the Node.js 'path' core module.
   *
   * @param aPath The path or url to normalize.
   */

  function normalize(aPath) {
    var path = aPath;
    var url = urlParse(aPath);

    if (url) {
      if (!url.path) {
        return aPath;
      }

      path = url.path;
    }

    var isAbsolute = exports.isAbsolute(path);
    var parts = path.split(/\/+/);

    for (var part, up = 0, i = parts.length - 1; i >= 0; i--) {
      part = parts[i];

      if (part === '.') {
        parts.splice(i, 1);
      } else if (part === '..') {
        up++;
      } else if (up > 0) {
        if (part === '') {
          // The first part is blank if the path is absolute. Trying to go
          // above the root is a no-op. Therefore we can remove all '..' parts
          // directly after the root.
          parts.splice(i + 1, up);
          up = 0;
        } else {
          parts.splice(i, 2);
          up--;
        }
      }
    }

    path = parts.join('/');

    if (path === '') {
      path = isAbsolute ? '/' : '.';
    }

    if (url) {
      url.path = path;
      return urlGenerate(url);
    }

    return path;
  }

  exports.normalize = normalize;
  /**
   * Joins two paths/URLs.
   *
   * @param aRoot The root path or URL.
   * @param aPath The path or URL to be joined with the root.
   *
   * - If aPath is a URL or a data URI, aPath is returned, unless aPath is a
   *   scheme-relative URL: Then the scheme of aRoot, if any, is prepended
   *   first.
   * - Otherwise aPath is a path. If aRoot is a URL, then its path portion
   *   is updated with the result and aRoot is returned. Otherwise the result
   *   is returned.
   *   - If aPath is absolute, the result is aPath.
   *   - Otherwise the two paths are joined with a slash.
   * - Joining for example 'http://' and 'www.example.com' is also supported.
   */

  function join(aRoot, aPath) {
    if (aRoot === "") {
      aRoot = ".";
    }

    if (aPath === "") {
      aPath = ".";
    }

    var aPathUrl = urlParse(aPath);
    var aRootUrl = urlParse(aRoot);

    if (aRootUrl) {
      aRoot = aRootUrl.path || '/';
    } // `join(foo, '//www.example.org')`


    if (aPathUrl && !aPathUrl.scheme) {
      if (aRootUrl) {
        aPathUrl.scheme = aRootUrl.scheme;
      }

      return urlGenerate(aPathUrl);
    }

    if (aPathUrl || aPath.match(dataUrlRegexp)) {
      return aPath;
    } // `join('http://', 'www.example.com')`


    if (aRootUrl && !aRootUrl.host && !aRootUrl.path) {
      aRootUrl.host = aPath;
      return urlGenerate(aRootUrl);
    }

    var joined = aPath.charAt(0) === '/' ? aPath : normalize(aRoot.replace(/\/+$/, '') + '/' + aPath);

    if (aRootUrl) {
      aRootUrl.path = joined;
      return urlGenerate(aRootUrl);
    }

    return joined;
  }

  exports.join = join;

  exports.isAbsolute = function (aPath) {
    return aPath.charAt(0) === '/' || urlRegexp.test(aPath);
  };
  /**
   * Make a path relative to a URL or another path.
   *
   * @param aRoot The root path or URL.
   * @param aPath The path or URL to be made relative to aRoot.
   */


  function relative(aRoot, aPath) {
    if (aRoot === "") {
      aRoot = ".";
    }

    aRoot = aRoot.replace(/\/$/, ''); // It is possible for the path to be above the root. In this case, simply
    // checking whether the root is a prefix of the path won't work. Instead, we
    // need to remove components from the root one by one, until either we find
    // a prefix that fits, or we run out of components to remove.

    var level = 0;

    while (aPath.indexOf(aRoot + '/') !== 0) {
      var index = aRoot.lastIndexOf("/");

      if (index < 0) {
        return aPath;
      } // If the only part of the root that is left is the scheme (i.e. http://,
      // file:///, etc.), one or more slashes (/), or simply nothing at all, we
      // have exhausted all components, so the path is not relative to the root.


      aRoot = aRoot.slice(0, index);

      if (aRoot.match(/^([^\/]+:\/)?\/*$/)) {
        return aPath;
      }

      ++level;
    } // Make sure we add a "../" for each component we removed from the root.


    return Array(level + 1).join("../") + aPath.substr(aRoot.length + 1);
  }

  exports.relative = relative;

  var supportsNullProto = function () {
    var obj = Object.create(null);
    return !('__proto__' in obj);
  }();

  function identity(s) {
    return s;
  }
  /**
   * Because behavior goes wacky when you set `__proto__` on objects, we
   * have to prefix all the strings in our set with an arbitrary character.
   *
   * See https://github.com/mozilla/source-map/pull/31 and
   * https://github.com/mozilla/source-map/issues/30
   *
   * @param String aStr
   */


  function toSetString(aStr) {
    if (isProtoString(aStr)) {
      return '$' + aStr;
    }

    return aStr;
  }

  exports.toSetString = supportsNullProto ? identity : toSetString;

  function fromSetString(aStr) {
    if (isProtoString(aStr)) {
      return aStr.slice(1);
    }

    return aStr;
  }

  exports.fromSetString = supportsNullProto ? identity : fromSetString;

  function isProtoString(s) {
    if (!s) {
      return false;
    }

    var length = s.length;

    if (length < 9
    /* "__proto__".length */
    ) {
        return false;
      }

    if (s.charCodeAt(length - 1) !== 95
    /* '_' */
    || s.charCodeAt(length - 2) !== 95
    /* '_' */
    || s.charCodeAt(length - 3) !== 111
    /* 'o' */
    || s.charCodeAt(length - 4) !== 116
    /* 't' */
    || s.charCodeAt(length - 5) !== 111
    /* 'o' */
    || s.charCodeAt(length - 6) !== 114
    /* 'r' */
    || s.charCodeAt(length - 7) !== 112
    /* 'p' */
    || s.charCodeAt(length - 8) !== 95
    /* '_' */
    || s.charCodeAt(length - 9) !== 95
    /* '_' */
    ) {
        return false;
      }

    for (var i = length - 10; i >= 0; i--) {
      if (s.charCodeAt(i) !== 36
      /* '$' */
      ) {
          return false;
        }
    }

    return true;
  }
  /**
   * Comparator between two mappings where the original positions are compared.
   *
   * Optionally pass in `true` as `onlyCompareGenerated` to consider two
   * mappings with the same original source/line/column, but different generated
   * line and column the same. Useful when searching for a mapping with a
   * stubbed out mapping.
   */


  function compareByOriginalPositions(mappingA, mappingB, onlyCompareOriginal) {
    var cmp = strcmp(mappingA.source, mappingB.source);

    if (cmp !== 0) {
      return cmp;
    }

    cmp = mappingA.originalLine - mappingB.originalLine;

    if (cmp !== 0) {
      return cmp;
    }

    cmp = mappingA.originalColumn - mappingB.originalColumn;

    if (cmp !== 0 || onlyCompareOriginal) {
      return cmp;
    }

    cmp = mappingA.generatedColumn - mappingB.generatedColumn;

    if (cmp !== 0) {
      return cmp;
    }

    cmp = mappingA.generatedLine - mappingB.generatedLine;

    if (cmp !== 0) {
      return cmp;
    }

    return strcmp(mappingA.name, mappingB.name);
  }

  exports.compareByOriginalPositions = compareByOriginalPositions;
  /**
   * Comparator between two mappings with deflated source and name indices where
   * the generated positions are compared.
   *
   * Optionally pass in `true` as `onlyCompareGenerated` to consider two
   * mappings with the same generated line and column, but different
   * source/name/original line and column the same. Useful when searching for a
   * mapping with a stubbed out mapping.
   */

  function compareByGeneratedPositionsDeflated(mappingA, mappingB, onlyCompareGenerated) {
    var cmp = mappingA.generatedLine - mappingB.generatedLine;

    if (cmp !== 0) {
      return cmp;
    }

    cmp = mappingA.generatedColumn - mappingB.generatedColumn;

    if (cmp !== 0 || onlyCompareGenerated) {
      return cmp;
    }

    cmp = strcmp(mappingA.source, mappingB.source);

    if (cmp !== 0) {
      return cmp;
    }

    cmp = mappingA.originalLine - mappingB.originalLine;

    if (cmp !== 0) {
      return cmp;
    }

    cmp = mappingA.originalColumn - mappingB.originalColumn;

    if (cmp !== 0) {
      return cmp;
    }

    return strcmp(mappingA.name, mappingB.name);
  }

  exports.compareByGeneratedPositionsDeflated = compareByGeneratedPositionsDeflated;

  function strcmp(aStr1, aStr2) {
    if (aStr1 === aStr2) {
      return 0;
    }

    if (aStr1 === null) {
      return 1; // aStr2 !== null
    }

    if (aStr2 === null) {
      return -1; // aStr1 !== null
    }

    if (aStr1 > aStr2) {
      return 1;
    }

    return -1;
  }
  /**
   * Comparator between two mappings with inflated source and name strings where
   * the generated positions are compared.
   */


  function compareByGeneratedPositionsInflated(mappingA, mappingB) {
    var cmp = mappingA.generatedLine - mappingB.generatedLine;

    if (cmp !== 0) {
      return cmp;
    }

    cmp = mappingA.generatedColumn - mappingB.generatedColumn;

    if (cmp !== 0) {
      return cmp;
    }

    cmp = strcmp(mappingA.source, mappingB.source);

    if (cmp !== 0) {
      return cmp;
    }

    cmp = mappingA.originalLine - mappingB.originalLine;

    if (cmp !== 0) {
      return cmp;
    }

    cmp = mappingA.originalColumn - mappingB.originalColumn;

    if (cmp !== 0) {
      return cmp;
    }

    return strcmp(mappingA.name, mappingB.name);
  }

  exports.compareByGeneratedPositionsInflated = compareByGeneratedPositionsInflated;
  /**
   * Strip any JSON XSSI avoidance prefix from the string (as documented
   * in the source maps specification), and then parse the string as
   * JSON.
   */

  function parseSourceMapInput(str) {
    return JSON.parse(str.replace(/^\)]}'[^\n]*\n/, ''));
  }

  exports.parseSourceMapInput = parseSourceMapInput;
  /**
   * Compute the URL of a source given the the source root, the source's
   * URL, and the source map's URL.
   */

  function computeSourceURL(sourceRoot, sourceURL, sourceMapURL) {
    sourceURL = sourceURL || '';

    if (sourceRoot) {
      // This follows what Chrome does.
      if (sourceRoot[sourceRoot.length - 1] !== '/' && sourceURL[0] !== '/') {
        sourceRoot += '/';
      } // The spec says:
      //   Line 4: An optional source root, useful for relocating source
      //   files on a server or removing repeated values in the
      //   “sources” entry.  This value is prepended to the individual
      //   entries in the “source” field.


      sourceURL = sourceRoot + sourceURL;
    } // Historically, SourceMapConsumer did not take the sourceMapURL as
    // a parameter.  This mode is still somewhat supported, which is why
    // this code block is conditional.  However, it's preferable to pass
    // the source map URL to SourceMapConsumer, so that this function
    // can implement the source URL resolution algorithm as outlined in
    // the spec.  This block is basically the equivalent of:
    //    new URL(sourceURL, sourceMapURL).toString()
    // ... except it avoids using URL, which wasn't available in the
    // older releases of node still supported by this library.
    //
    // The spec says:
    //   If the sources are not absolute URLs after prepending of the
    //   “sourceRoot”, the sources are resolved relative to the
    //   SourceMap (like resolving script src in a html document).


    if (sourceMapURL) {
      var parsed = urlParse(sourceMapURL);

      if (!parsed) {
        throw new Error("sourceMapURL could not be parsed");
      }

      if (parsed.path) {
        // Strip the last path component, but keep the "/".
        var index = parsed.path.lastIndexOf('/');

        if (index >= 0) {
          parsed.path = parsed.path.substring(0, index + 1);
        }
      }

      sourceURL = join(urlGenerate(parsed), sourceURL);
    }

    return normalize(sourceURL);
  }

  exports.computeSourceURL = computeSourceURL;
});

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

var has = Object.prototype.hasOwnProperty;
var hasNativeMap = typeof Map !== "undefined";
/**
 * A data structure which is a combination of an array and a set. Adding a new
 * member is O(1), testing for membership is O(1), and finding the index of an
 * element is O(1). Removing elements from the set is not supported. Only
 * strings are supported for membership.
 */

function ArraySet() {
  this._array = [];
  this._set = hasNativeMap ? new Map() : Object.create(null);
}
/**
 * Static method for creating ArraySet instances from an existing array.
 */


ArraySet.fromArray = function ArraySet_fromArray(aArray, aAllowDuplicates) {
  var set = new ArraySet();

  for (var i = 0, len = aArray.length; i < len; i++) {
    set.add(aArray[i], aAllowDuplicates);
  }

  return set;
};
/**
 * Return how many unique items are in this ArraySet. If duplicates have been
 * added, than those do not count towards the size.
 *
 * @returns Number
 */


ArraySet.prototype.size = function ArraySet_size() {
  return hasNativeMap ? this._set.size : Object.getOwnPropertyNames(this._set).length;
};
/**
 * Add the given string to this set.
 *
 * @param String aStr
 */


ArraySet.prototype.add = function ArraySet_add(aStr, aAllowDuplicates) {
  var sStr = hasNativeMap ? aStr : util.toSetString(aStr);
  var isDuplicate = hasNativeMap ? this.has(aStr) : has.call(this._set, sStr);
  var idx = this._array.length;

  if (!isDuplicate || aAllowDuplicates) {
    this._array.push(aStr);
  }

  if (!isDuplicate) {
    if (hasNativeMap) {
      this._set.set(aStr, idx);
    } else {
      this._set[sStr] = idx;
    }
  }
};
/**
 * Is the given string a member of this set?
 *
 * @param String aStr
 */


ArraySet.prototype.has = function ArraySet_has(aStr) {
  if (hasNativeMap) {
    return this._set.has(aStr);
  } else {
    var sStr = util.toSetString(aStr);
    return has.call(this._set, sStr);
  }
};
/**
 * What is the index of the given string in the array?
 *
 * @param String aStr
 */


ArraySet.prototype.indexOf = function ArraySet_indexOf(aStr) {
  if (hasNativeMap) {
    var idx = this._set.get(aStr);

    if (idx >= 0) {
      return idx;
    }
  } else {
    var sStr = util.toSetString(aStr);

    if (has.call(this._set, sStr)) {
      return this._set[sStr];
    }
  }

  throw new Error('"' + aStr + '" is not in the set.');
};
/**
 * What is the element at the given index?
 *
 * @param Number aIdx
 */


ArraySet.prototype.at = function ArraySet_at(aIdx) {
  if (aIdx >= 0 && aIdx < this._array.length) {
    return this._array[aIdx];
  }

  throw new Error('No element indexed by ' + aIdx);
};
/**
 * Returns the array representation of this set (which has the proper indices
 * indicated by indexOf). Note that this is a copy of the internal array used
 * for storing the members so that no one can mess with internal state.
 */


ArraySet.prototype.toArray = function ArraySet_toArray() {
  return this._array.slice();
};

var ArraySet_1 = ArraySet;
var arraySet = {
  ArraySet: ArraySet_1
};

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2014 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

/**
 * Determine whether mappingB is after mappingA with respect to generated
 * position.
 */

function generatedPositionAfter(mappingA, mappingB) {
  // Optimized for most common case
  var lineA = mappingA.generatedLine;
  var lineB = mappingB.generatedLine;
  var columnA = mappingA.generatedColumn;
  var columnB = mappingB.generatedColumn;
  return lineB > lineA || lineB == lineA && columnB >= columnA || util.compareByGeneratedPositionsInflated(mappingA, mappingB) <= 0;
}
/**
 * A data structure to provide a sorted view of accumulated mappings in a
 * performance conscious manner. It trades a neglibable overhead in general
 * case for a large speedup in case of mappings being added in order.
 */


function MappingList() {
  this._array = [];
  this._sorted = true; // Serves as infimum

  this._last = {
    generatedLine: -1,
    generatedColumn: 0
  };
}
/**
 * Iterate through internal items. This method takes the same arguments that
 * `Array.prototype.forEach` takes.
 *
 * NOTE: The order of the mappings is NOT guaranteed.
 */


MappingList.prototype.unsortedForEach = function MappingList_forEach(aCallback, aThisArg) {
  this._array.forEach(aCallback, aThisArg);
};
/**
 * Add the given source mapping.
 *
 * @param Object aMapping
 */


MappingList.prototype.add = function MappingList_add(aMapping) {
  if (generatedPositionAfter(this._last, aMapping)) {
    this._last = aMapping;

    this._array.push(aMapping);
  } else {
    this._sorted = false;

    this._array.push(aMapping);
  }
};
/**
 * Returns the flat, sorted array of mappings. The mappings are sorted by
 * generated position.
 *
 * WARNING: This method returns internal data without copying, for
 * performance. The return value must NOT be mutated, and should be treated as
 * an immutable borrow. If you want to take ownership, you must make your own
 * copy.
 */


MappingList.prototype.toArray = function MappingList_toArray() {
  if (!this._sorted) {
    this._array.sort(util.compareByGeneratedPositionsInflated);

    this._sorted = true;
  }

  return this._array;
};

var MappingList_1 = MappingList;
var mappingList = {
  MappingList: MappingList_1
};

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

var ArraySet$1 = arraySet.ArraySet;
var MappingList$1 = mappingList.MappingList;
/**
 * An instance of the SourceMapGenerator represents a source map which is
 * being built incrementally. You may pass an object with the following
 * properties:
 *
 *   - file: The filename of the generated source.
 *   - sourceRoot: A root for all relative URLs in this source map.
 */

function SourceMapGenerator(aArgs) {
  if (!aArgs) {
    aArgs = {};
  }

  this._file = util.getArg(aArgs, 'file', null);
  this._sourceRoot = util.getArg(aArgs, 'sourceRoot', null);
  this._skipValidation = util.getArg(aArgs, 'skipValidation', false);
  this._sources = new ArraySet$1();
  this._names = new ArraySet$1();
  this._mappings = new MappingList$1();
  this._sourcesContents = null;
}

SourceMapGenerator.prototype._version = 3;
/**
 * Creates a new SourceMapGenerator based on a SourceMapConsumer
 *
 * @param aSourceMapConsumer The SourceMap.
 */

SourceMapGenerator.fromSourceMap = function SourceMapGenerator_fromSourceMap(aSourceMapConsumer) {
  var sourceRoot = aSourceMapConsumer.sourceRoot;
  var generator = new SourceMapGenerator({
    file: aSourceMapConsumer.file,
    sourceRoot: sourceRoot
  });
  aSourceMapConsumer.eachMapping(function (mapping) {
    var newMapping = {
      generated: {
        line: mapping.generatedLine,
        column: mapping.generatedColumn
      }
    };

    if (mapping.source != null) {
      newMapping.source = mapping.source;

      if (sourceRoot != null) {
        newMapping.source = util.relative(sourceRoot, newMapping.source);
      }

      newMapping.original = {
        line: mapping.originalLine,
        column: mapping.originalColumn
      };

      if (mapping.name != null) {
        newMapping.name = mapping.name;
      }
    }

    generator.addMapping(newMapping);
  });
  aSourceMapConsumer.sources.forEach(function (sourceFile) {
    var sourceRelative = sourceFile;

    if (sourceRoot !== null) {
      sourceRelative = util.relative(sourceRoot, sourceFile);
    }

    if (!generator._sources.has(sourceRelative)) {
      generator._sources.add(sourceRelative);
    }

    var content = aSourceMapConsumer.sourceContentFor(sourceFile);

    if (content != null) {
      generator.setSourceContent(sourceFile, content);
    }
  });
  return generator;
};
/**
 * Add a single mapping from original source line and column to the generated
 * source's line and column for this source map being created. The mapping
 * object should have the following properties:
 *
 *   - generated: An object with the generated line and column positions.
 *   - original: An object with the original line and column positions.
 *   - source: The original source file (relative to the sourceRoot).
 *   - name: An optional original token name for this mapping.
 */


SourceMapGenerator.prototype.addMapping = function SourceMapGenerator_addMapping(aArgs) {
  var generated = util.getArg(aArgs, 'generated');
  var original = util.getArg(aArgs, 'original', null);
  var source = util.getArg(aArgs, 'source', null);
  var name = util.getArg(aArgs, 'name', null);

  if (!this._skipValidation) {
    this._validateMapping(generated, original, source, name);
  }

  if (source != null) {
    source = String(source);

    if (!this._sources.has(source)) {
      this._sources.add(source);
    }
  }

  if (name != null) {
    name = String(name);

    if (!this._names.has(name)) {
      this._names.add(name);
    }
  }

  this._mappings.add({
    generatedLine: generated.line,
    generatedColumn: generated.column,
    originalLine: original != null && original.line,
    originalColumn: original != null && original.column,
    source: source,
    name: name
  });
};
/**
 * Set the source content for a source file.
 */


SourceMapGenerator.prototype.setSourceContent = function SourceMapGenerator_setSourceContent(aSourceFile, aSourceContent) {
  var source = aSourceFile;

  if (this._sourceRoot != null) {
    source = util.relative(this._sourceRoot, source);
  }

  if (aSourceContent != null) {
    // Add the source content to the _sourcesContents map.
    // Create a new _sourcesContents map if the property is null.
    if (!this._sourcesContents) {
      this._sourcesContents = Object.create(null);
    }

    this._sourcesContents[util.toSetString(source)] = aSourceContent;
  } else if (this._sourcesContents) {
    // Remove the source file from the _sourcesContents map.
    // If the _sourcesContents map is empty, set the property to null.
    delete this._sourcesContents[util.toSetString(source)];

    if (Object.keys(this._sourcesContents).length === 0) {
      this._sourcesContents = null;
    }
  }
};
/**
 * Applies the mappings of a sub-source-map for a specific source file to the
 * source map being generated. Each mapping to the supplied source file is
 * rewritten using the supplied source map. Note: The resolution for the
 * resulting mappings is the minimium of this map and the supplied map.
 *
 * @param aSourceMapConsumer The source map to be applied.
 * @param aSourceFile Optional. The filename of the source file.
 *        If omitted, SourceMapConsumer's file property will be used.
 * @param aSourceMapPath Optional. The dirname of the path to the source map
 *        to be applied. If relative, it is relative to the SourceMapConsumer.
 *        This parameter is needed when the two source maps aren't in the same
 *        directory, and the source map to be applied contains relative source
 *        paths. If so, those relative source paths need to be rewritten
 *        relative to the SourceMapGenerator.
 */


SourceMapGenerator.prototype.applySourceMap = function SourceMapGenerator_applySourceMap(aSourceMapConsumer, aSourceFile, aSourceMapPath) {
  var sourceFile = aSourceFile; // If aSourceFile is omitted, we will use the file property of the SourceMap

  if (aSourceFile == null) {
    if (aSourceMapConsumer.file == null) {
      throw new Error('SourceMapGenerator.prototype.applySourceMap requires either an explicit source file, ' + 'or the source map\'s "file" property. Both were omitted.');
    }

    sourceFile = aSourceMapConsumer.file;
  }

  var sourceRoot = this._sourceRoot; // Make "sourceFile" relative if an absolute Url is passed.

  if (sourceRoot != null) {
    sourceFile = util.relative(sourceRoot, sourceFile);
  } // Applying the SourceMap can add and remove items from the sources and
  // the names array.


  var newSources = new ArraySet$1();
  var newNames = new ArraySet$1(); // Find mappings for the "sourceFile"

  this._mappings.unsortedForEach(function (mapping) {
    if (mapping.source === sourceFile && mapping.originalLine != null) {
      // Check if it can be mapped by the source map, then update the mapping.
      var original = aSourceMapConsumer.originalPositionFor({
        line: mapping.originalLine,
        column: mapping.originalColumn
      });

      if (original.source != null) {
        // Copy mapping
        mapping.source = original.source;

        if (aSourceMapPath != null) {
          mapping.source = util.join(aSourceMapPath, mapping.source);
        }

        if (sourceRoot != null) {
          mapping.source = util.relative(sourceRoot, mapping.source);
        }

        mapping.originalLine = original.line;
        mapping.originalColumn = original.column;

        if (original.name != null) {
          mapping.name = original.name;
        }
      }
    }

    var source = mapping.source;

    if (source != null && !newSources.has(source)) {
      newSources.add(source);
    }

    var name = mapping.name;

    if (name != null && !newNames.has(name)) {
      newNames.add(name);
    }
  }, this);

  this._sources = newSources;
  this._names = newNames; // Copy sourcesContents of applied map.

  aSourceMapConsumer.sources.forEach(function (sourceFile) {
    var content = aSourceMapConsumer.sourceContentFor(sourceFile);

    if (content != null) {
      if (aSourceMapPath != null) {
        sourceFile = util.join(aSourceMapPath, sourceFile);
      }

      if (sourceRoot != null) {
        sourceFile = util.relative(sourceRoot, sourceFile);
      }

      this.setSourceContent(sourceFile, content);
    }
  }, this);
};
/**
 * A mapping can have one of the three levels of data:
 *
 *   1. Just the generated position.
 *   2. The Generated position, original position, and original source.
 *   3. Generated and original position, original source, as well as a name
 *      token.
 *
 * To maintain consistency, we validate that any new mapping being added falls
 * in to one of these categories.
 */


SourceMapGenerator.prototype._validateMapping = function SourceMapGenerator_validateMapping(aGenerated, aOriginal, aSource, aName) {
  // When aOriginal is truthy but has empty values for .line and .column,
  // it is most likely a programmer error. In this case we throw a very
  // specific error message to try to guide them the right way.
  // For example: https://github.com/Polymer/polymer-bundler/pull/519
  if (aOriginal && typeof aOriginal.line !== 'number' && typeof aOriginal.column !== 'number') {
    throw new Error('original.line and original.column are not numbers -- you probably meant to omit ' + 'the original mapping entirely and only map the generated position. If so, pass ' + 'null for the original mapping instead of an object with empty or null values.');
  }

  if (aGenerated && 'line' in aGenerated && 'column' in aGenerated && aGenerated.line > 0 && aGenerated.column >= 0 && !aOriginal && !aSource && !aName) {
    // Case 1.
    return;
  } else if (aGenerated && 'line' in aGenerated && 'column' in aGenerated && aOriginal && 'line' in aOriginal && 'column' in aOriginal && aGenerated.line > 0 && aGenerated.column >= 0 && aOriginal.line > 0 && aOriginal.column >= 0 && aSource) {
    // Cases 2 and 3.
    return;
  } else {
    throw new Error('Invalid mapping: ' + JSON.stringify({
      generated: aGenerated,
      source: aSource,
      original: aOriginal,
      name: aName
    }));
  }
};
/**
 * Serialize the accumulated mappings in to the stream of base 64 VLQs
 * specified by the source map format.
 */


SourceMapGenerator.prototype._serializeMappings = function SourceMapGenerator_serializeMappings() {
  var previousGeneratedColumn = 0;
  var previousGeneratedLine = 1;
  var previousOriginalColumn = 0;
  var previousOriginalLine = 0;
  var previousName = 0;
  var previousSource = 0;
  var result = '';
  var next;
  var mapping;
  var nameIdx;
  var sourceIdx;

  var mappings = this._mappings.toArray();

  for (var i = 0, len = mappings.length; i < len; i++) {
    mapping = mappings[i];
    next = '';

    if (mapping.generatedLine !== previousGeneratedLine) {
      previousGeneratedColumn = 0;

      while (mapping.generatedLine !== previousGeneratedLine) {
        next += ';';
        previousGeneratedLine++;
      }
    } else {
      if (i > 0) {
        if (!util.compareByGeneratedPositionsInflated(mapping, mappings[i - 1])) {
          continue;
        }

        next += ',';
      }
    }

    next += base64Vlq.encode(mapping.generatedColumn - previousGeneratedColumn);
    previousGeneratedColumn = mapping.generatedColumn;

    if (mapping.source != null) {
      sourceIdx = this._sources.indexOf(mapping.source);
      next += base64Vlq.encode(sourceIdx - previousSource);
      previousSource = sourceIdx; // lines are stored 0-based in SourceMap spec version 3

      next += base64Vlq.encode(mapping.originalLine - 1 - previousOriginalLine);
      previousOriginalLine = mapping.originalLine - 1;
      next += base64Vlq.encode(mapping.originalColumn - previousOriginalColumn);
      previousOriginalColumn = mapping.originalColumn;

      if (mapping.name != null) {
        nameIdx = this._names.indexOf(mapping.name);
        next += base64Vlq.encode(nameIdx - previousName);
        previousName = nameIdx;
      }
    }

    result += next;
  }

  return result;
};

SourceMapGenerator.prototype._generateSourcesContent = function SourceMapGenerator_generateSourcesContent(aSources, aSourceRoot) {
  return aSources.map(function (source) {
    if (!this._sourcesContents) {
      return null;
    }

    if (aSourceRoot != null) {
      source = util.relative(aSourceRoot, source);
    }

    var key = util.toSetString(source);
    return Object.prototype.hasOwnProperty.call(this._sourcesContents, key) ? this._sourcesContents[key] : null;
  }, this);
};
/**
 * Externalize the source map.
 */


SourceMapGenerator.prototype.toJSON = function SourceMapGenerator_toJSON() {
  var map = {
    version: this._version,
    sources: this._sources.toArray(),
    names: this._names.toArray(),
    mappings: this._serializeMappings()
  };

  if (this._file != null) {
    map.file = this._file;
  }

  if (this._sourceRoot != null) {
    map.sourceRoot = this._sourceRoot;
  }

  if (this._sourcesContents) {
    map.sourcesContent = this._generateSourcesContent(map.sources, map.sourceRoot);
  }

  return map;
};
/**
 * Render the source map being generated to a string.
 */


SourceMapGenerator.prototype.toString = function SourceMapGenerator_toString() {
  return JSON.stringify(this.toJSON());
};

var SourceMapGenerator_1 = SourceMapGenerator;
var sourceMapGenerator = {
  SourceMapGenerator: SourceMapGenerator_1
};

/* -*- Mode: js; js-indent-level: 2; -*- */
var binarySearch = createCommonjsModule(function (module, exports) {
  /*
   * Copyright 2011 Mozilla Foundation and contributors
   * Licensed under the New BSD license. See LICENSE or:
   * http://opensource.org/licenses/BSD-3-Clause
   */
  exports.GREATEST_LOWER_BOUND = 1;
  exports.LEAST_UPPER_BOUND = 2;
  /**
   * Recursive implementation of binary search.
   *
   * @param aLow Indices here and lower do not contain the needle.
   * @param aHigh Indices here and higher do not contain the needle.
   * @param aNeedle The element being searched for.
   * @param aHaystack The non-empty array being searched.
   * @param aCompare Function which takes two elements and returns -1, 0, or 1.
   * @param aBias Either 'binarySearch.GREATEST_LOWER_BOUND' or
   *     'binarySearch.LEAST_UPPER_BOUND'. Specifies whether to return the
   *     closest element that is smaller than or greater than the one we are
   *     searching for, respectively, if the exact element cannot be found.
   */

  function recursiveSearch(aLow, aHigh, aNeedle, aHaystack, aCompare, aBias) {
    // This function terminates when one of the following is true:
    //
    //   1. We find the exact element we are looking for.
    //
    //   2. We did not find the exact element, but we can return the index of
    //      the next-closest element.
    //
    //   3. We did not find the exact element, and there is no next-closest
    //      element than the one we are searching for, so we return -1.
    var mid = Math.floor((aHigh - aLow) / 2) + aLow;
    var cmp = aCompare(aNeedle, aHaystack[mid], true);

    if (cmp === 0) {
      // Found the element we are looking for.
      return mid;
    } else if (cmp > 0) {
      // Our needle is greater than aHaystack[mid].
      if (aHigh - mid > 1) {
        // The element is in the upper half.
        return recursiveSearch(mid, aHigh, aNeedle, aHaystack, aCompare, aBias);
      } // The exact needle element was not found in this haystack. Determine if
      // we are in termination case (3) or (2) and return the appropriate thing.


      if (aBias == exports.LEAST_UPPER_BOUND) {
        return aHigh < aHaystack.length ? aHigh : -1;
      } else {
        return mid;
      }
    } else {
      // Our needle is less than aHaystack[mid].
      if (mid - aLow > 1) {
        // The element is in the lower half.
        return recursiveSearch(aLow, mid, aNeedle, aHaystack, aCompare, aBias);
      } // we are in termination case (3) or (2) and return the appropriate thing.


      if (aBias == exports.LEAST_UPPER_BOUND) {
        return mid;
      } else {
        return aLow < 0 ? -1 : aLow;
      }
    }
  }
  /**
   * This is an implementation of binary search which will always try and return
   * the index of the closest element if there is no exact hit. This is because
   * mappings between original and generated line/col pairs are single points,
   * and there is an implicit region between each of them, so a miss just means
   * that you aren't on the very start of a region.
   *
   * @param aNeedle The element you are looking for.
   * @param aHaystack The array that is being searched.
   * @param aCompare A function which takes the needle and an element in the
   *     array and returns -1, 0, or 1 depending on whether the needle is less
   *     than, equal to, or greater than the element, respectively.
   * @param aBias Either 'binarySearch.GREATEST_LOWER_BOUND' or
   *     'binarySearch.LEAST_UPPER_BOUND'. Specifies whether to return the
   *     closest element that is smaller than or greater than the one we are
   *     searching for, respectively, if the exact element cannot be found.
   *     Defaults to 'binarySearch.GREATEST_LOWER_BOUND'.
   */


  exports.search = function search(aNeedle, aHaystack, aCompare, aBias) {
    if (aHaystack.length === 0) {
      return -1;
    }

    var index = recursiveSearch(-1, aHaystack.length, aNeedle, aHaystack, aCompare, aBias || exports.GREATEST_LOWER_BOUND);

    if (index < 0) {
      return -1;
    } // We have found either the exact element, or the next-closest element than
    // the one we are searching for. However, there may be more than one such
    // element. Make sure we always return the smallest of these.


    while (index - 1 >= 0) {
      if (aCompare(aHaystack[index], aHaystack[index - 1], true) !== 0) {
        break;
      }

      --index;
    }

    return index;
  };
});

/* -*- Mode: js; js-indent-level: 2; -*- */

/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */
// It turns out that some (most?) JavaScript engines don't self-host
// `Array.prototype.sort`. This makes sense because C++ will likely remain
// faster than JS when doing raw CPU-intensive sorting. However, when using a
// custom comparator function, calling back and forth between the VM's C++ and
// JIT'd JS is rather slow *and* loses JIT type information, resulting in
// worse generated code for the comparator function than would be optimal. In
// fact, when sorting with a comparator, these costs outweigh the benefits of
// sorting in C++. By using our own JS-implemented Quick Sort (below), we get
// a ~3500ms mean speed-up in `bench/bench.html`.

/**
 * Swap the elements indexed by `x` and `y` in the array `ary`.
 *
 * @param {Array} ary
 *        The array.
 * @param {Number} x
 *        The index of the first item.
 * @param {Number} y
 *        The index of the second item.
 */
function swap(ary, x, y) {
  var temp = ary[x];
  ary[x] = ary[y];
  ary[y] = temp;
}
/**
 * Returns a random integer within the range `low .. high` inclusive.
 *
 * @param {Number} low
 *        The lower bound on the range.
 * @param {Number} high
 *        The upper bound on the range.
 */


function randomIntInRange(low, high) {
  return Math.round(low + Math.random() * (high - low));
}
/**
 * The Quick Sort algorithm.
 *
 * @param {Array} ary
 *        An array to sort.
 * @param {function} comparator
 *        Function to use to compare two items.
 * @param {Number} p
 *        Start index of the array
 * @param {Number} r
 *        End index of the array
 */


function doQuickSort(ary, comparator, p, r) {
  // If our lower bound is less than our upper bound, we (1) partition the
  // array into two pieces and (2) recurse on each half. If it is not, this is
  // the empty array and our base case.
  if (p < r) {
    // (1) Partitioning.
    //
    // The partitioning chooses a pivot between `p` and `r` and moves all
    // elements that are less than or equal to the pivot to the before it, and
    // all the elements that are greater than it after it. The effect is that
    // once partition is done, the pivot is in the exact place it will be when
    // the array is put in sorted order, and it will not need to be moved
    // again. This runs in O(n) time.
    // Always choose a random pivot so that an input array which is reverse
    // sorted does not cause O(n^2) running time.
    var pivotIndex = randomIntInRange(p, r);
    var i = p - 1;
    swap(ary, pivotIndex, r);
    var pivot = ary[r]; // Immediately after `j` is incremented in this loop, the following hold
    // true:
    //
    //   * Every element in `ary[p .. i]` is less than or equal to the pivot.
    //
    //   * Every element in `ary[i+1 .. j-1]` is greater than the pivot.

    for (var j = p; j < r; j++) {
      if (comparator(ary[j], pivot) <= 0) {
        i += 1;
        swap(ary, i, j);
      }
    }

    swap(ary, i + 1, j);
    var q = i + 1; // (2) Recurse on each half.

    doQuickSort(ary, comparator, p, q - 1);
    doQuickSort(ary, comparator, q + 1, r);
  }
}
/**
 * Sort the given array in-place with the given comparator function.
 *
 * @param {Array} ary
 *        An array to sort.
 * @param {function} comparator
 *        Function to use to compare two items.
 */


var quickSort_1 = function (ary, comparator) {
  doQuickSort(ary, comparator, 0, ary.length - 1);
};

var quickSort = {
  quickSort: quickSort_1
};

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

var ArraySet$2 = arraySet.ArraySet;
var quickSort$1 = quickSort.quickSort;

function SourceMapConsumer(aSourceMap, aSourceMapURL) {
  var sourceMap = aSourceMap;

  if (typeof aSourceMap === 'string') {
    sourceMap = util.parseSourceMapInput(aSourceMap);
  }

  return sourceMap.sections != null ? new IndexedSourceMapConsumer(sourceMap, aSourceMapURL) : new BasicSourceMapConsumer(sourceMap, aSourceMapURL);
}

SourceMapConsumer.fromSourceMap = function (aSourceMap, aSourceMapURL) {
  return BasicSourceMapConsumer.fromSourceMap(aSourceMap, aSourceMapURL);
};
/**
 * The version of the source mapping spec that we are consuming.
 */


SourceMapConsumer.prototype._version = 3; // `__generatedMappings` and `__originalMappings` are arrays that hold the
// parsed mapping coordinates from the source map's "mappings" attribute. They
// are lazily instantiated, accessed via the `_generatedMappings` and
// `_originalMappings` getters respectively, and we only parse the mappings
// and create these arrays once queried for a source location. We jump through
// these hoops because there can be many thousands of mappings, and parsing
// them is expensive, so we only want to do it if we must.
//
// Each object in the arrays is of the form:
//
//     {
//       generatedLine: The line number in the generated code,
//       generatedColumn: The column number in the generated code,
//       source: The path to the original source file that generated this
//               chunk of code,
//       originalLine: The line number in the original source that
//                     corresponds to this chunk of generated code,
//       originalColumn: The column number in the original source that
//                       corresponds to this chunk of generated code,
//       name: The name of the original symbol which generated this chunk of
//             code.
//     }
//
// All properties except for `generatedLine` and `generatedColumn` can be
// `null`.
//
// `_generatedMappings` is ordered by the generated positions.
//
// `_originalMappings` is ordered by the original positions.

SourceMapConsumer.prototype.__generatedMappings = null;
Object.defineProperty(SourceMapConsumer.prototype, '_generatedMappings', {
  configurable: true,
  enumerable: true,
  get: function () {
    if (!this.__generatedMappings) {
      this._parseMappings(this._mappings, this.sourceRoot);
    }

    return this.__generatedMappings;
  }
});
SourceMapConsumer.prototype.__originalMappings = null;
Object.defineProperty(SourceMapConsumer.prototype, '_originalMappings', {
  configurable: true,
  enumerable: true,
  get: function () {
    if (!this.__originalMappings) {
      this._parseMappings(this._mappings, this.sourceRoot);
    }

    return this.__originalMappings;
  }
});

SourceMapConsumer.prototype._charIsMappingSeparator = function SourceMapConsumer_charIsMappingSeparator(aStr, index) {
  var c = aStr.charAt(index);
  return c === ";" || c === ",";
};
/**
 * Parse the mappings in a string in to a data structure which we can easily
 * query (the ordered arrays in the `this.__generatedMappings` and
 * `this.__originalMappings` properties).
 */


SourceMapConsumer.prototype._parseMappings = function SourceMapConsumer_parseMappings(aStr, aSourceRoot) {
  throw new Error("Subclasses must implement _parseMappings");
};

SourceMapConsumer.GENERATED_ORDER = 1;
SourceMapConsumer.ORIGINAL_ORDER = 2;
SourceMapConsumer.GREATEST_LOWER_BOUND = 1;
SourceMapConsumer.LEAST_UPPER_BOUND = 2;
/**
 * Iterate over each mapping between an original source/line/column and a
 * generated line/column in this source map.
 *
 * @param Function aCallback
 *        The function that is called with each mapping.
 * @param Object aContext
 *        Optional. If specified, this object will be the value of `this` every
 *        time that `aCallback` is called.
 * @param aOrder
 *        Either `SourceMapConsumer.GENERATED_ORDER` or
 *        `SourceMapConsumer.ORIGINAL_ORDER`. Specifies whether you want to
 *        iterate over the mappings sorted by the generated file's line/column
 *        order or the original's source/line/column order, respectively. Defaults to
 *        `SourceMapConsumer.GENERATED_ORDER`.
 */

SourceMapConsumer.prototype.eachMapping = function SourceMapConsumer_eachMapping(aCallback, aContext, aOrder) {
  var context = aContext || null;
  var order = aOrder || SourceMapConsumer.GENERATED_ORDER;
  var mappings;

  switch (order) {
    case SourceMapConsumer.GENERATED_ORDER:
      mappings = this._generatedMappings;
      break;

    case SourceMapConsumer.ORIGINAL_ORDER:
      mappings = this._originalMappings;
      break;

    default:
      throw new Error("Unknown order of iteration.");
  }

  var sourceRoot = this.sourceRoot;
  mappings.map(function (mapping) {
    var source = mapping.source === null ? null : this._sources.at(mapping.source);
    source = util.computeSourceURL(sourceRoot, source, this._sourceMapURL);
    return {
      source: source,
      generatedLine: mapping.generatedLine,
      generatedColumn: mapping.generatedColumn,
      originalLine: mapping.originalLine,
      originalColumn: mapping.originalColumn,
      name: mapping.name === null ? null : this._names.at(mapping.name)
    };
  }, this).forEach(aCallback, context);
};
/**
 * Returns all generated line and column information for the original source,
 * line, and column provided. If no column is provided, returns all mappings
 * corresponding to a either the line we are searching for or the next
 * closest line that has any mappings. Otherwise, returns all mappings
 * corresponding to the given line and either the column we are searching for
 * or the next closest column that has any offsets.
 *
 * The only argument is an object with the following properties:
 *
 *   - source: The filename of the original source.
 *   - line: The line number in the original source.  The line number is 1-based.
 *   - column: Optional. the column number in the original source.
 *    The column number is 0-based.
 *
 * and an array of objects is returned, each with the following properties:
 *
 *   - line: The line number in the generated source, or null.  The
 *    line number is 1-based.
 *   - column: The column number in the generated source, or null.
 *    The column number is 0-based.
 */


SourceMapConsumer.prototype.allGeneratedPositionsFor = function SourceMapConsumer_allGeneratedPositionsFor(aArgs) {
  var line = util.getArg(aArgs, 'line'); // When there is no exact match, BasicSourceMapConsumer.prototype._findMapping
  // returns the index of the closest mapping less than the needle. By
  // setting needle.originalColumn to 0, we thus find the last mapping for
  // the given line, provided such a mapping exists.

  var needle = {
    source: util.getArg(aArgs, 'source'),
    originalLine: line,
    originalColumn: util.getArg(aArgs, 'column', 0)
  };
  needle.source = this._findSourceIndex(needle.source);

  if (needle.source < 0) {
    return [];
  }

  var mappings = [];

  var index = this._findMapping(needle, this._originalMappings, "originalLine", "originalColumn", util.compareByOriginalPositions, binarySearch.LEAST_UPPER_BOUND);

  if (index >= 0) {
    var mapping = this._originalMappings[index];

    if (aArgs.column === undefined) {
      var originalLine = mapping.originalLine; // Iterate until either we run out of mappings, or we run into
      // a mapping for a different line than the one we found. Since
      // mappings are sorted, this is guaranteed to find all mappings for
      // the line we found.

      while (mapping && mapping.originalLine === originalLine) {
        mappings.push({
          line: util.getArg(mapping, 'generatedLine', null),
          column: util.getArg(mapping, 'generatedColumn', null),
          lastColumn: util.getArg(mapping, 'lastGeneratedColumn', null)
        });
        mapping = this._originalMappings[++index];
      }
    } else {
      var originalColumn = mapping.originalColumn; // Iterate until either we run out of mappings, or we run into
      // a mapping for a different line than the one we were searching for.
      // Since mappings are sorted, this is guaranteed to find all mappings for
      // the line we are searching for.

      while (mapping && mapping.originalLine === line && mapping.originalColumn == originalColumn) {
        mappings.push({
          line: util.getArg(mapping, 'generatedLine', null),
          column: util.getArg(mapping, 'generatedColumn', null),
          lastColumn: util.getArg(mapping, 'lastGeneratedColumn', null)
        });
        mapping = this._originalMappings[++index];
      }
    }
  }

  return mappings;
};

var SourceMapConsumer_1 = SourceMapConsumer;
/**
 * A BasicSourceMapConsumer instance represents a parsed source map which we can
 * query for information about the original file positions by giving it a file
 * position in the generated source.
 *
 * The first parameter is the raw source map (either as a JSON string, or
 * already parsed to an object). According to the spec, source maps have the
 * following attributes:
 *
 *   - version: Which version of the source map spec this map is following.
 *   - sources: An array of URLs to the original source files.
 *   - names: An array of identifiers which can be referrenced by individual mappings.
 *   - sourceRoot: Optional. The URL root from which all sources are relative.
 *   - sourcesContent: Optional. An array of contents of the original source files.
 *   - mappings: A string of base64 VLQs which contain the actual mappings.
 *   - file: Optional. The generated file this source map is associated with.
 *
 * Here is an example source map, taken from the source map spec[0]:
 *
 *     {
 *       version : 3,
 *       file: "out.js",
 *       sourceRoot : "",
 *       sources: ["foo.js", "bar.js"],
 *       names: ["src", "maps", "are", "fun"],
 *       mappings: "AA,AB;;ABCDE;"
 *     }
 *
 * The second parameter, if given, is a string whose value is the URL
 * at which the source map was found.  This URL is used to compute the
 * sources array.
 *
 * [0]: https://docs.google.com/document/d/1U1RGAehQwRypUTovF1KRlpiOFze0b-_2gc6fAH0KY0k/edit?pli=1#
 */

function BasicSourceMapConsumer(aSourceMap, aSourceMapURL) {
  var sourceMap = aSourceMap;

  if (typeof aSourceMap === 'string') {
    sourceMap = util.parseSourceMapInput(aSourceMap);
  }

  var version = util.getArg(sourceMap, 'version');
  var sources = util.getArg(sourceMap, 'sources'); // Sass 3.3 leaves out the 'names' array, so we deviate from the spec (which
  // requires the array) to play nice here.

  var names = util.getArg(sourceMap, 'names', []);
  var sourceRoot = util.getArg(sourceMap, 'sourceRoot', null);
  var sourcesContent = util.getArg(sourceMap, 'sourcesContent', null);
  var mappings = util.getArg(sourceMap, 'mappings');
  var file = util.getArg(sourceMap, 'file', null); // Once again, Sass deviates from the spec and supplies the version as a
  // string rather than a number, so we use loose equality checking here.

  if (version != this._version) {
    throw new Error('Unsupported version: ' + version);
  }

  if (sourceRoot) {
    sourceRoot = util.normalize(sourceRoot);
  }

  sources = sources.map(String) // Some source maps produce relative source paths like "./foo.js" instead of
  // "foo.js".  Normalize these first so that future comparisons will succeed.
  // See bugzil.la/1090768.
  .map(util.normalize) // Always ensure that absolute sources are internally stored relative to
  // the source root, if the source root is absolute. Not doing this would
  // be particularly problematic when the source root is a prefix of the
  // source (valid, but why??). See github issue #199 and bugzil.la/1188982.
  .map(function (source) {
    return sourceRoot && util.isAbsolute(sourceRoot) && util.isAbsolute(source) ? util.relative(sourceRoot, source) : source;
  }); // Pass `true` below to allow duplicate names and sources. While source maps
  // are intended to be compressed and deduplicated, the TypeScript compiler
  // sometimes generates source maps with duplicates in them. See Github issue
  // #72 and bugzil.la/889492.

  this._names = ArraySet$2.fromArray(names.map(String), true);
  this._sources = ArraySet$2.fromArray(sources, true);
  this._absoluteSources = this._sources.toArray().map(function (s) {
    return util.computeSourceURL(sourceRoot, s, aSourceMapURL);
  });
  this.sourceRoot = sourceRoot;
  this.sourcesContent = sourcesContent;
  this._mappings = mappings;
  this._sourceMapURL = aSourceMapURL;
  this.file = file;
}

BasicSourceMapConsumer.prototype = Object.create(SourceMapConsumer.prototype);
BasicSourceMapConsumer.prototype.consumer = SourceMapConsumer;
/**
 * Utility function to find the index of a source.  Returns -1 if not
 * found.
 */

BasicSourceMapConsumer.prototype._findSourceIndex = function (aSource) {
  var relativeSource = aSource;

  if (this.sourceRoot != null) {
    relativeSource = util.relative(this.sourceRoot, relativeSource);
  }

  if (this._sources.has(relativeSource)) {
    return this._sources.indexOf(relativeSource);
  } // Maybe aSource is an absolute URL as returned by |sources|.  In
  // this case we can't simply undo the transform.


  var i;

  for (i = 0; i < this._absoluteSources.length; ++i) {
    if (this._absoluteSources[i] == aSource) {
      return i;
    }
  }

  return -1;
};
/**
 * Create a BasicSourceMapConsumer from a SourceMapGenerator.
 *
 * @param SourceMapGenerator aSourceMap
 *        The source map that will be consumed.
 * @param String aSourceMapURL
 *        The URL at which the source map can be found (optional)
 * @returns BasicSourceMapConsumer
 */


BasicSourceMapConsumer.fromSourceMap = function SourceMapConsumer_fromSourceMap(aSourceMap, aSourceMapURL) {
  var smc = Object.create(BasicSourceMapConsumer.prototype);
  var names = smc._names = ArraySet$2.fromArray(aSourceMap._names.toArray(), true);
  var sources = smc._sources = ArraySet$2.fromArray(aSourceMap._sources.toArray(), true);
  smc.sourceRoot = aSourceMap._sourceRoot;
  smc.sourcesContent = aSourceMap._generateSourcesContent(smc._sources.toArray(), smc.sourceRoot);
  smc.file = aSourceMap._file;
  smc._sourceMapURL = aSourceMapURL;
  smc._absoluteSources = smc._sources.toArray().map(function (s) {
    return util.computeSourceURL(smc.sourceRoot, s, aSourceMapURL);
  }); // Because we are modifying the entries (by converting string sources and
  // names to indices into the sources and names ArraySets), we have to make
  // a copy of the entry or else bad things happen. Shared mutable state
  // strikes again! See github issue #191.

  var generatedMappings = aSourceMap._mappings.toArray().slice();

  var destGeneratedMappings = smc.__generatedMappings = [];
  var destOriginalMappings = smc.__originalMappings = [];

  for (var i = 0, length = generatedMappings.length; i < length; i++) {
    var srcMapping = generatedMappings[i];
    var destMapping = new Mapping();
    destMapping.generatedLine = srcMapping.generatedLine;
    destMapping.generatedColumn = srcMapping.generatedColumn;

    if (srcMapping.source) {
      destMapping.source = sources.indexOf(srcMapping.source);
      destMapping.originalLine = srcMapping.originalLine;
      destMapping.originalColumn = srcMapping.originalColumn;

      if (srcMapping.name) {
        destMapping.name = names.indexOf(srcMapping.name);
      }

      destOriginalMappings.push(destMapping);
    }

    destGeneratedMappings.push(destMapping);
  }

  quickSort$1(smc.__originalMappings, util.compareByOriginalPositions);
  return smc;
};
/**
 * The version of the source mapping spec that we are consuming.
 */


BasicSourceMapConsumer.prototype._version = 3;
/**
 * The list of original sources.
 */

Object.defineProperty(BasicSourceMapConsumer.prototype, 'sources', {
  get: function () {
    return this._absoluteSources.slice();
  }
});
/**
 * Provide the JIT with a nice shape / hidden class.
 */

function Mapping() {
  this.generatedLine = 0;
  this.generatedColumn = 0;
  this.source = null;
  this.originalLine = null;
  this.originalColumn = null;
  this.name = null;
}
/**
 * Parse the mappings in a string in to a data structure which we can easily
 * query (the ordered arrays in the `this.__generatedMappings` and
 * `this.__originalMappings` properties).
 */


BasicSourceMapConsumer.prototype._parseMappings = function SourceMapConsumer_parseMappings(aStr, aSourceRoot) {
  var generatedLine = 1;
  var previousGeneratedColumn = 0;
  var previousOriginalLine = 0;
  var previousOriginalColumn = 0;
  var previousSource = 0;
  var previousName = 0;
  var length = aStr.length;
  var index = 0;
  var cachedSegments = {};
  var temp = {};
  var originalMappings = [];
  var generatedMappings = [];
  var mapping, str, segment, end, value;

  while (index < length) {
    if (aStr.charAt(index) === ';') {
      generatedLine++;
      index++;
      previousGeneratedColumn = 0;
    } else if (aStr.charAt(index) === ',') {
      index++;
    } else {
      mapping = new Mapping();
      mapping.generatedLine = generatedLine; // Because each offset is encoded relative to the previous one,
      // many segments often have the same encoding. We can exploit this
      // fact by caching the parsed variable length fields of each segment,
      // allowing us to avoid a second parse if we encounter the same
      // segment again.

      for (end = index; end < length; end++) {
        if (this._charIsMappingSeparator(aStr, end)) {
          break;
        }
      }

      str = aStr.slice(index, end);
      segment = cachedSegments[str];

      if (segment) {
        index += str.length;
      } else {
        segment = [];

        while (index < end) {
          base64Vlq.decode(aStr, index, temp);
          value = temp.value;
          index = temp.rest;
          segment.push(value);
        }

        if (segment.length === 2) {
          throw new Error('Found a source, but no line and column');
        }

        if (segment.length === 3) {
          throw new Error('Found a source and line, but no column');
        }

        cachedSegments[str] = segment;
      } // Generated column.


      mapping.generatedColumn = previousGeneratedColumn + segment[0];
      previousGeneratedColumn = mapping.generatedColumn;

      if (segment.length > 1) {
        // Original source.
        mapping.source = previousSource + segment[1];
        previousSource += segment[1]; // Original line.

        mapping.originalLine = previousOriginalLine + segment[2];
        previousOriginalLine = mapping.originalLine; // Lines are stored 0-based

        mapping.originalLine += 1; // Original column.

        mapping.originalColumn = previousOriginalColumn + segment[3];
        previousOriginalColumn = mapping.originalColumn;

        if (segment.length > 4) {
          // Original name.
          mapping.name = previousName + segment[4];
          previousName += segment[4];
        }
      }

      generatedMappings.push(mapping);

      if (typeof mapping.originalLine === 'number') {
        originalMappings.push(mapping);
      }
    }
  }

  quickSort$1(generatedMappings, util.compareByGeneratedPositionsDeflated);
  this.__generatedMappings = generatedMappings;
  quickSort$1(originalMappings, util.compareByOriginalPositions);
  this.__originalMappings = originalMappings;
};
/**
 * Find the mapping that best matches the hypothetical "needle" mapping that
 * we are searching for in the given "haystack" of mappings.
 */


BasicSourceMapConsumer.prototype._findMapping = function SourceMapConsumer_findMapping(aNeedle, aMappings, aLineName, aColumnName, aComparator, aBias) {
  // To return the position we are searching for, we must first find the
  // mapping for the given position and then return the opposite position it
  // points to. Because the mappings are sorted, we can use binary search to
  // find the best mapping.
  if (aNeedle[aLineName] <= 0) {
    throw new TypeError('Line must be greater than or equal to 1, got ' + aNeedle[aLineName]);
  }

  if (aNeedle[aColumnName] < 0) {
    throw new TypeError('Column must be greater than or equal to 0, got ' + aNeedle[aColumnName]);
  }

  return binarySearch.search(aNeedle, aMappings, aComparator, aBias);
};
/**
 * Compute the last column for each generated mapping. The last column is
 * inclusive.
 */


BasicSourceMapConsumer.prototype.computeColumnSpans = function SourceMapConsumer_computeColumnSpans() {
  for (var index = 0; index < this._generatedMappings.length; ++index) {
    var mapping = this._generatedMappings[index]; // Mappings do not contain a field for the last generated columnt. We
    // can come up with an optimistic estimate, however, by assuming that
    // mappings are contiguous (i.e. given two consecutive mappings, the
    // first mapping ends where the second one starts).

    if (index + 1 < this._generatedMappings.length) {
      var nextMapping = this._generatedMappings[index + 1];

      if (mapping.generatedLine === nextMapping.generatedLine) {
        mapping.lastGeneratedColumn = nextMapping.generatedColumn - 1;
        continue;
      }
    } // The last mapping for each line spans the entire line.


    mapping.lastGeneratedColumn = Infinity;
  }
};
/**
 * Returns the original source, line, and column information for the generated
 * source's line and column positions provided. The only argument is an object
 * with the following properties:
 *
 *   - line: The line number in the generated source.  The line number
 *     is 1-based.
 *   - column: The column number in the generated source.  The column
 *     number is 0-based.
 *   - bias: Either 'SourceMapConsumer.GREATEST_LOWER_BOUND' or
 *     'SourceMapConsumer.LEAST_UPPER_BOUND'. Specifies whether to return the
 *     closest element that is smaller than or greater than the one we are
 *     searching for, respectively, if the exact element cannot be found.
 *     Defaults to 'SourceMapConsumer.GREATEST_LOWER_BOUND'.
 *
 * and an object is returned with the following properties:
 *
 *   - source: The original source file, or null.
 *   - line: The line number in the original source, or null.  The
 *     line number is 1-based.
 *   - column: The column number in the original source, or null.  The
 *     column number is 0-based.
 *   - name: The original identifier, or null.
 */


BasicSourceMapConsumer.prototype.originalPositionFor = function SourceMapConsumer_originalPositionFor(aArgs) {
  var needle = {
    generatedLine: util.getArg(aArgs, 'line'),
    generatedColumn: util.getArg(aArgs, 'column')
  };

  var index = this._findMapping(needle, this._generatedMappings, "generatedLine", "generatedColumn", util.compareByGeneratedPositionsDeflated, util.getArg(aArgs, 'bias', SourceMapConsumer.GREATEST_LOWER_BOUND));

  if (index >= 0) {
    var mapping = this._generatedMappings[index];

    if (mapping.generatedLine === needle.generatedLine) {
      var source = util.getArg(mapping, 'source', null);

      if (source !== null) {
        source = this._sources.at(source);
        source = util.computeSourceURL(this.sourceRoot, source, this._sourceMapURL);
      }

      var name = util.getArg(mapping, 'name', null);

      if (name !== null) {
        name = this._names.at(name);
      }

      return {
        source: source,
        line: util.getArg(mapping, 'originalLine', null),
        column: util.getArg(mapping, 'originalColumn', null),
        name: name
      };
    }
  }

  return {
    source: null,
    line: null,
    column: null,
    name: null
  };
};
/**
 * Return true if we have the source content for every source in the source
 * map, false otherwise.
 */


BasicSourceMapConsumer.prototype.hasContentsOfAllSources = function BasicSourceMapConsumer_hasContentsOfAllSources() {
  if (!this.sourcesContent) {
    return false;
  }

  return this.sourcesContent.length >= this._sources.size() && !this.sourcesContent.some(function (sc) {
    return sc == null;
  });
};
/**
 * Returns the original source content. The only argument is the url of the
 * original source file. Returns null if no original source content is
 * available.
 */


BasicSourceMapConsumer.prototype.sourceContentFor = function SourceMapConsumer_sourceContentFor(aSource, nullOnMissing) {
  if (!this.sourcesContent) {
    return null;
  }

  var index = this._findSourceIndex(aSource);

  if (index >= 0) {
    return this.sourcesContent[index];
  }

  var relativeSource = aSource;

  if (this.sourceRoot != null) {
    relativeSource = util.relative(this.sourceRoot, relativeSource);
  }

  var url;

  if (this.sourceRoot != null && (url = util.urlParse(this.sourceRoot))) {
    // XXX: file:// URIs and absolute paths lead to unexpected behavior for
    // many users. We can help them out when they expect file:// URIs to
    // behave like it would if they were running a local HTTP server. See
    // https://bugzilla.mozilla.org/show_bug.cgi?id=885597.
    var fileUriAbsPath = relativeSource.replace(/^file:\/\//, "");

    if (url.scheme == "file" && this._sources.has(fileUriAbsPath)) {
      return this.sourcesContent[this._sources.indexOf(fileUriAbsPath)];
    }

    if ((!url.path || url.path == "/") && this._sources.has("/" + relativeSource)) {
      return this.sourcesContent[this._sources.indexOf("/" + relativeSource)];
    }
  } // This function is used recursively from
  // IndexedSourceMapConsumer.prototype.sourceContentFor. In that case, we
  // don't want to throw if we can't find the source - we just want to
  // return null, so we provide a flag to exit gracefully.


  if (nullOnMissing) {
    return null;
  } else {
    throw new Error('"' + relativeSource + '" is not in the SourceMap.');
  }
};
/**
 * Returns the generated line and column information for the original source,
 * line, and column positions provided. The only argument is an object with
 * the following properties:
 *
 *   - source: The filename of the original source.
 *   - line: The line number in the original source.  The line number
 *     is 1-based.
 *   - column: The column number in the original source.  The column
 *     number is 0-based.
 *   - bias: Either 'SourceMapConsumer.GREATEST_LOWER_BOUND' or
 *     'SourceMapConsumer.LEAST_UPPER_BOUND'. Specifies whether to return the
 *     closest element that is smaller than or greater than the one we are
 *     searching for, respectively, if the exact element cannot be found.
 *     Defaults to 'SourceMapConsumer.GREATEST_LOWER_BOUND'.
 *
 * and an object is returned with the following properties:
 *
 *   - line: The line number in the generated source, or null.  The
 *     line number is 1-based.
 *   - column: The column number in the generated source, or null.
 *     The column number is 0-based.
 */


BasicSourceMapConsumer.prototype.generatedPositionFor = function SourceMapConsumer_generatedPositionFor(aArgs) {
  var source = util.getArg(aArgs, 'source');
  source = this._findSourceIndex(source);

  if (source < 0) {
    return {
      line: null,
      column: null,
      lastColumn: null
    };
  }

  var needle = {
    source: source,
    originalLine: util.getArg(aArgs, 'line'),
    originalColumn: util.getArg(aArgs, 'column')
  };

  var index = this._findMapping(needle, this._originalMappings, "originalLine", "originalColumn", util.compareByOriginalPositions, util.getArg(aArgs, 'bias', SourceMapConsumer.GREATEST_LOWER_BOUND));

  if (index >= 0) {
    var mapping = this._originalMappings[index];

    if (mapping.source === needle.source) {
      return {
        line: util.getArg(mapping, 'generatedLine', null),
        column: util.getArg(mapping, 'generatedColumn', null),
        lastColumn: util.getArg(mapping, 'lastGeneratedColumn', null)
      };
    }
  }

  return {
    line: null,
    column: null,
    lastColumn: null
  };
};

var BasicSourceMapConsumer_1 = BasicSourceMapConsumer;
/**
 * An IndexedSourceMapConsumer instance represents a parsed source map which
 * we can query for information. It differs from BasicSourceMapConsumer in
 * that it takes "indexed" source maps (i.e. ones with a "sections" field) as
 * input.
 *
 * The first parameter is a raw source map (either as a JSON string, or already
 * parsed to an object). According to the spec for indexed source maps, they
 * have the following attributes:
 *
 *   - version: Which version of the source map spec this map is following.
 *   - file: Optional. The generated file this source map is associated with.
 *   - sections: A list of section definitions.
 *
 * Each value under the "sections" field has two fields:
 *   - offset: The offset into the original specified at which this section
 *       begins to apply, defined as an object with a "line" and "column"
 *       field.
 *   - map: A source map definition. This source map could also be indexed,
 *       but doesn't have to be.
 *
 * Instead of the "map" field, it's also possible to have a "url" field
 * specifying a URL to retrieve a source map from, but that's currently
 * unsupported.
 *
 * Here's an example source map, taken from the source map spec[0], but
 * modified to omit a section which uses the "url" field.
 *
 *  {
 *    version : 3,
 *    file: "app.js",
 *    sections: [{
 *      offset: {line:100, column:10},
 *      map: {
 *        version : 3,
 *        file: "section.js",
 *        sources: ["foo.js", "bar.js"],
 *        names: ["src", "maps", "are", "fun"],
 *        mappings: "AAAA,E;;ABCDE;"
 *      }
 *    }],
 *  }
 *
 * The second parameter, if given, is a string whose value is the URL
 * at which the source map was found.  This URL is used to compute the
 * sources array.
 *
 * [0]: https://docs.google.com/document/d/1U1RGAehQwRypUTovF1KRlpiOFze0b-_2gc6fAH0KY0k/edit#heading=h.535es3xeprgt
 */

function IndexedSourceMapConsumer(aSourceMap, aSourceMapURL) {
  var sourceMap = aSourceMap;

  if (typeof aSourceMap === 'string') {
    sourceMap = util.parseSourceMapInput(aSourceMap);
  }

  var version = util.getArg(sourceMap, 'version');
  var sections = util.getArg(sourceMap, 'sections');

  if (version != this._version) {
    throw new Error('Unsupported version: ' + version);
  }

  this._sources = new ArraySet$2();
  this._names = new ArraySet$2();
  var lastOffset = {
    line: -1,
    column: 0
  };
  this._sections = sections.map(function (s) {
    if (s.url) {
      // The url field will require support for asynchronicity.
      // See https://github.com/mozilla/source-map/issues/16
      throw new Error('Support for url field in sections not implemented.');
    }

    var offset = util.getArg(s, 'offset');
    var offsetLine = util.getArg(offset, 'line');
    var offsetColumn = util.getArg(offset, 'column');

    if (offsetLine < lastOffset.line || offsetLine === lastOffset.line && offsetColumn < lastOffset.column) {
      throw new Error('Section offsets must be ordered and non-overlapping.');
    }

    lastOffset = offset;
    return {
      generatedOffset: {
        // The offset fields are 0-based, but we use 1-based indices when
        // encoding/decoding from VLQ.
        generatedLine: offsetLine + 1,
        generatedColumn: offsetColumn + 1
      },
      consumer: new SourceMapConsumer(util.getArg(s, 'map'), aSourceMapURL)
    };
  });
}

IndexedSourceMapConsumer.prototype = Object.create(SourceMapConsumer.prototype);
IndexedSourceMapConsumer.prototype.constructor = SourceMapConsumer;
/**
 * The version of the source mapping spec that we are consuming.
 */

IndexedSourceMapConsumer.prototype._version = 3;
/**
 * The list of original sources.
 */

Object.defineProperty(IndexedSourceMapConsumer.prototype, 'sources', {
  get: function () {
    var sources = [];

    for (var i = 0; i < this._sections.length; i++) {
      for (var j = 0; j < this._sections[i].consumer.sources.length; j++) {
        sources.push(this._sections[i].consumer.sources[j]);
      }
    }

    return sources;
  }
});
/**
 * Returns the original source, line, and column information for the generated
 * source's line and column positions provided. The only argument is an object
 * with the following properties:
 *
 *   - line: The line number in the generated source.  The line number
 *     is 1-based.
 *   - column: The column number in the generated source.  The column
 *     number is 0-based.
 *
 * and an object is returned with the following properties:
 *
 *   - source: The original source file, or null.
 *   - line: The line number in the original source, or null.  The
 *     line number is 1-based.
 *   - column: The column number in the original source, or null.  The
 *     column number is 0-based.
 *   - name: The original identifier, or null.
 */

IndexedSourceMapConsumer.prototype.originalPositionFor = function IndexedSourceMapConsumer_originalPositionFor(aArgs) {
  var needle = {
    generatedLine: util.getArg(aArgs, 'line'),
    generatedColumn: util.getArg(aArgs, 'column')
  }; // Find the section containing the generated position we're trying to map
  // to an original position.

  var sectionIndex = binarySearch.search(needle, this._sections, function (needle, section) {
    var cmp = needle.generatedLine - section.generatedOffset.generatedLine;

    if (cmp) {
      return cmp;
    }

    return needle.generatedColumn - section.generatedOffset.generatedColumn;
  });
  var section = this._sections[sectionIndex];

  if (!section) {
    return {
      source: null,
      line: null,
      column: null,
      name: null
    };
  }

  return section.consumer.originalPositionFor({
    line: needle.generatedLine - (section.generatedOffset.generatedLine - 1),
    column: needle.generatedColumn - (section.generatedOffset.generatedLine === needle.generatedLine ? section.generatedOffset.generatedColumn - 1 : 0),
    bias: aArgs.bias
  });
};
/**
 * Return true if we have the source content for every source in the source
 * map, false otherwise.
 */


IndexedSourceMapConsumer.prototype.hasContentsOfAllSources = function IndexedSourceMapConsumer_hasContentsOfAllSources() {
  return this._sections.every(function (s) {
    return s.consumer.hasContentsOfAllSources();
  });
};
/**
 * Returns the original source content. The only argument is the url of the
 * original source file. Returns null if no original source content is
 * available.
 */


IndexedSourceMapConsumer.prototype.sourceContentFor = function IndexedSourceMapConsumer_sourceContentFor(aSource, nullOnMissing) {
  for (var i = 0; i < this._sections.length; i++) {
    var section = this._sections[i];
    var content = section.consumer.sourceContentFor(aSource, true);

    if (content) {
      return content;
    }
  }

  if (nullOnMissing) {
    return null;
  } else {
    throw new Error('"' + aSource + '" is not in the SourceMap.');
  }
};
/**
 * Returns the generated line and column information for the original source,
 * line, and column positions provided. The only argument is an object with
 * the following properties:
 *
 *   - source: The filename of the original source.
 *   - line: The line number in the original source.  The line number
 *     is 1-based.
 *   - column: The column number in the original source.  The column
 *     number is 0-based.
 *
 * and an object is returned with the following properties:
 *
 *   - line: The line number in the generated source, or null.  The
 *     line number is 1-based. 
 *   - column: The column number in the generated source, or null.
 *     The column number is 0-based.
 */


IndexedSourceMapConsumer.prototype.generatedPositionFor = function IndexedSourceMapConsumer_generatedPositionFor(aArgs) {
  for (var i = 0; i < this._sections.length; i++) {
    var section = this._sections[i]; // Only consider this section if the requested source is in the list of
    // sources of the consumer.

    if (section.consumer._findSourceIndex(util.getArg(aArgs, 'source')) === -1) {
      continue;
    }

    var generatedPosition = section.consumer.generatedPositionFor(aArgs);

    if (generatedPosition) {
      var ret = {
        line: generatedPosition.line + (section.generatedOffset.generatedLine - 1),
        column: generatedPosition.column + (section.generatedOffset.generatedLine === generatedPosition.line ? section.generatedOffset.generatedColumn - 1 : 0)
      };
      return ret;
    }
  }

  return {
    line: null,
    column: null
  };
};
/**
 * Parse the mappings in a string in to a data structure which we can easily
 * query (the ordered arrays in the `this.__generatedMappings` and
 * `this.__originalMappings` properties).
 */


IndexedSourceMapConsumer.prototype._parseMappings = function IndexedSourceMapConsumer_parseMappings(aStr, aSourceRoot) {
  this.__generatedMappings = [];
  this.__originalMappings = [];

  for (var i = 0; i < this._sections.length; i++) {
    var section = this._sections[i];
    var sectionMappings = section.consumer._generatedMappings;

    for (var j = 0; j < sectionMappings.length; j++) {
      var mapping = sectionMappings[j];

      var source = section.consumer._sources.at(mapping.source);

      source = util.computeSourceURL(section.consumer.sourceRoot, source, this._sourceMapURL);

      this._sources.add(source);

      source = this._sources.indexOf(source);
      var name = null;

      if (mapping.name) {
        name = section.consumer._names.at(mapping.name);

        this._names.add(name);

        name = this._names.indexOf(name);
      } // The mappings coming from the consumer for the section have
      // generated positions relative to the start of the section, so we
      // need to offset them to be relative to the start of the concatenated
      // generated file.


      var adjustedMapping = {
        source: source,
        generatedLine: mapping.generatedLine + (section.generatedOffset.generatedLine - 1),
        generatedColumn: mapping.generatedColumn + (section.generatedOffset.generatedLine === mapping.generatedLine ? section.generatedOffset.generatedColumn - 1 : 0),
        originalLine: mapping.originalLine,
        originalColumn: mapping.originalColumn,
        name: name
      };

      this.__generatedMappings.push(adjustedMapping);

      if (typeof adjustedMapping.originalLine === 'number') {
        this.__originalMappings.push(adjustedMapping);
      }
    }
  }

  quickSort$1(this.__generatedMappings, util.compareByGeneratedPositionsDeflated);
  quickSort$1(this.__originalMappings, util.compareByOriginalPositions);
};

var IndexedSourceMapConsumer_1 = IndexedSourceMapConsumer;
var sourceMapConsumer = {
  SourceMapConsumer: SourceMapConsumer_1,
  BasicSourceMapConsumer: BasicSourceMapConsumer_1,
  IndexedSourceMapConsumer: IndexedSourceMapConsumer_1
};

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

var SourceMapGenerator$1 = sourceMapGenerator.SourceMapGenerator; // Matches a Windows-style `\r\n` newline or a `\n` newline used by all other
// operating systems these days (capturing the result).

var REGEX_NEWLINE = /(\r?\n)/; // Newline character code for charCodeAt() comparisons

var NEWLINE_CODE = 10; // Private symbol for identifying `SourceNode`s when multiple versions of
// the source-map library are loaded. This MUST NOT CHANGE across
// versions!

var isSourceNode = "$$$isSourceNode$$$";
/**
 * SourceNodes provide a way to abstract over interpolating/concatenating
 * snippets of generated JavaScript source code while maintaining the line and
 * column information associated with the original source code.
 *
 * @param aLine The original line number.
 * @param aColumn The original column number.
 * @param aSource The original source's filename.
 * @param aChunks Optional. An array of strings which are snippets of
 *        generated JS, or other SourceNodes.
 * @param aName The original identifier.
 */

function SourceNode(aLine, aColumn, aSource, aChunks, aName) {
  this.children = [];
  this.sourceContents = {};
  this.line = aLine == null ? null : aLine;
  this.column = aColumn == null ? null : aColumn;
  this.source = aSource == null ? null : aSource;
  this.name = aName == null ? null : aName;
  this[isSourceNode] = true;
  if (aChunks != null) this.add(aChunks);
}
/**
 * Creates a SourceNode from generated code and a SourceMapConsumer.
 *
 * @param aGeneratedCode The generated code
 * @param aSourceMapConsumer The SourceMap for the generated code
 * @param aRelativePath Optional. The path that relative sources in the
 *        SourceMapConsumer should be relative to.
 */


SourceNode.fromStringWithSourceMap = function SourceNode_fromStringWithSourceMap(aGeneratedCode, aSourceMapConsumer, aRelativePath) {
  // The SourceNode we want to fill with the generated code
  // and the SourceMap
  var node = new SourceNode(); // All even indices of this array are one line of the generated code,
  // while all odd indices are the newlines between two adjacent lines
  // (since `REGEX_NEWLINE` captures its match).
  // Processed fragments are accessed by calling `shiftNextLine`.

  var remainingLines = aGeneratedCode.split(REGEX_NEWLINE);
  var remainingLinesIndex = 0;

  var shiftNextLine = function () {
    var lineContents = getNextLine(); // The last line of a file might not have a newline.

    var newLine = getNextLine() || "";
    return lineContents + newLine;

    function getNextLine() {
      return remainingLinesIndex < remainingLines.length ? remainingLines[remainingLinesIndex++] : undefined;
    }
  }; // We need to remember the position of "remainingLines"


  var lastGeneratedLine = 1,
      lastGeneratedColumn = 0; // The generate SourceNodes we need a code range.
  // To extract it current and last mapping is used.
  // Here we store the last mapping.

  var lastMapping = null;
  aSourceMapConsumer.eachMapping(function (mapping) {
    if (lastMapping !== null) {
      // We add the code from "lastMapping" to "mapping":
      // First check if there is a new line in between.
      if (lastGeneratedLine < mapping.generatedLine) {
        // Associate first line with "lastMapping"
        addMappingWithCode(lastMapping, shiftNextLine());
        lastGeneratedLine++;
        lastGeneratedColumn = 0; // The remaining code is added without mapping
      } else {
        // There is no new line in between.
        // Associate the code between "lastGeneratedColumn" and
        // "mapping.generatedColumn" with "lastMapping"
        var nextLine = remainingLines[remainingLinesIndex] || '';
        var code = nextLine.substr(0, mapping.generatedColumn - lastGeneratedColumn);
        remainingLines[remainingLinesIndex] = nextLine.substr(mapping.generatedColumn - lastGeneratedColumn);
        lastGeneratedColumn = mapping.generatedColumn;
        addMappingWithCode(lastMapping, code); // No more remaining code, continue

        lastMapping = mapping;
        return;
      }
    } // We add the generated code until the first mapping
    // to the SourceNode without any mapping.
    // Each line is added as separate string.


    while (lastGeneratedLine < mapping.generatedLine) {
      node.add(shiftNextLine());
      lastGeneratedLine++;
    }

    if (lastGeneratedColumn < mapping.generatedColumn) {
      var nextLine = remainingLines[remainingLinesIndex] || '';
      node.add(nextLine.substr(0, mapping.generatedColumn));
      remainingLines[remainingLinesIndex] = nextLine.substr(mapping.generatedColumn);
      lastGeneratedColumn = mapping.generatedColumn;
    }

    lastMapping = mapping;
  }, this); // We have processed all mappings.

  if (remainingLinesIndex < remainingLines.length) {
    if (lastMapping) {
      // Associate the remaining code in the current line with "lastMapping"
      addMappingWithCode(lastMapping, shiftNextLine());
    } // and add the remaining lines without any mapping


    node.add(remainingLines.splice(remainingLinesIndex).join(""));
  } // Copy sourcesContent into SourceNode


  aSourceMapConsumer.sources.forEach(function (sourceFile) {
    var content = aSourceMapConsumer.sourceContentFor(sourceFile);

    if (content != null) {
      if (aRelativePath != null) {
        sourceFile = util.join(aRelativePath, sourceFile);
      }

      node.setSourceContent(sourceFile, content);
    }
  });
  return node;

  function addMappingWithCode(mapping, code) {
    if (mapping === null || mapping.source === undefined) {
      node.add(code);
    } else {
      var source = aRelativePath ? util.join(aRelativePath, mapping.source) : mapping.source;
      node.add(new SourceNode(mapping.originalLine, mapping.originalColumn, source, code, mapping.name));
    }
  }
};
/**
 * Add a chunk of generated JS to this source node.
 *
 * @param aChunk A string snippet of generated JS code, another instance of
 *        SourceNode, or an array where each member is one of those things.
 */


SourceNode.prototype.add = function SourceNode_add(aChunk) {
  if (Array.isArray(aChunk)) {
    aChunk.forEach(function (chunk) {
      this.add(chunk);
    }, this);
  } else if (aChunk[isSourceNode] || typeof aChunk === "string") {
    if (aChunk) {
      this.children.push(aChunk);
    }
  } else {
    throw new TypeError("Expected a SourceNode, string, or an array of SourceNodes and strings. Got " + aChunk);
  }

  return this;
};
/**
 * Add a chunk of generated JS to the beginning of this source node.
 *
 * @param aChunk A string snippet of generated JS code, another instance of
 *        SourceNode, or an array where each member is one of those things.
 */


SourceNode.prototype.prepend = function SourceNode_prepend(aChunk) {
  if (Array.isArray(aChunk)) {
    for (var i = aChunk.length - 1; i >= 0; i--) {
      this.prepend(aChunk[i]);
    }
  } else if (aChunk[isSourceNode] || typeof aChunk === "string") {
    this.children.unshift(aChunk);
  } else {
    throw new TypeError("Expected a SourceNode, string, or an array of SourceNodes and strings. Got " + aChunk);
  }

  return this;
};
/**
 * Walk over the tree of JS snippets in this node and its children. The
 * walking function is called once for each snippet of JS and is passed that
 * snippet and the its original associated source's line/column location.
 *
 * @param aFn The traversal function.
 */


SourceNode.prototype.walk = function SourceNode_walk(aFn) {
  var chunk;

  for (var i = 0, len = this.children.length; i < len; i++) {
    chunk = this.children[i];

    if (chunk[isSourceNode]) {
      chunk.walk(aFn);
    } else {
      if (chunk !== '') {
        aFn(chunk, {
          source: this.source,
          line: this.line,
          column: this.column,
          name: this.name
        });
      }
    }
  }
};
/**
 * Like `String.prototype.join` except for SourceNodes. Inserts `aStr` between
 * each of `this.children`.
 *
 * @param aSep The separator.
 */


SourceNode.prototype.join = function SourceNode_join(aSep) {
  var newChildren;
  var i;
  var len = this.children.length;

  if (len > 0) {
    newChildren = [];

    for (i = 0; i < len - 1; i++) {
      newChildren.push(this.children[i]);
      newChildren.push(aSep);
    }

    newChildren.push(this.children[i]);
    this.children = newChildren;
  }

  return this;
};
/**
 * Call String.prototype.replace on the very right-most source snippet. Useful
 * for trimming whitespace from the end of a source node, etc.
 *
 * @param aPattern The pattern to replace.
 * @param aReplacement The thing to replace the pattern with.
 */


SourceNode.prototype.replaceRight = function SourceNode_replaceRight(aPattern, aReplacement) {
  var lastChild = this.children[this.children.length - 1];

  if (lastChild[isSourceNode]) {
    lastChild.replaceRight(aPattern, aReplacement);
  } else if (typeof lastChild === 'string') {
    this.children[this.children.length - 1] = lastChild.replace(aPattern, aReplacement);
  } else {
    this.children.push(''.replace(aPattern, aReplacement));
  }

  return this;
};
/**
 * Set the source content for a source file. This will be added to the SourceMapGenerator
 * in the sourcesContent field.
 *
 * @param aSourceFile The filename of the source file
 * @param aSourceContent The content of the source file
 */


SourceNode.prototype.setSourceContent = function SourceNode_setSourceContent(aSourceFile, aSourceContent) {
  this.sourceContents[util.toSetString(aSourceFile)] = aSourceContent;
};
/**
 * Walk over the tree of SourceNodes. The walking function is called for each
 * source file content and is passed the filename and source content.
 *
 * @param aFn The traversal function.
 */


SourceNode.prototype.walkSourceContents = function SourceNode_walkSourceContents(aFn) {
  for (var i = 0, len = this.children.length; i < len; i++) {
    if (this.children[i][isSourceNode]) {
      this.children[i].walkSourceContents(aFn);
    }
  }

  var sources = Object.keys(this.sourceContents);

  for (var i = 0, len = sources.length; i < len; i++) {
    aFn(util.fromSetString(sources[i]), this.sourceContents[sources[i]]);
  }
};
/**
 * Return the string representation of this source node. Walks over the tree
 * and concatenates all the various snippets together to one string.
 */


SourceNode.prototype.toString = function SourceNode_toString() {
  var str = "";
  this.walk(function (chunk) {
    str += chunk;
  });
  return str;
};
/**
 * Returns the string representation of this source node along with a source
 * map.
 */


SourceNode.prototype.toStringWithSourceMap = function SourceNode_toStringWithSourceMap(aArgs) {
  var generated = {
    code: "",
    line: 1,
    column: 0
  };
  var map = new SourceMapGenerator$1(aArgs);
  var sourceMappingActive = false;
  var lastOriginalSource = null;
  var lastOriginalLine = null;
  var lastOriginalColumn = null;
  var lastOriginalName = null;
  this.walk(function (chunk, original) {
    generated.code += chunk;

    if (original.source !== null && original.line !== null && original.column !== null) {
      if (lastOriginalSource !== original.source || lastOriginalLine !== original.line || lastOriginalColumn !== original.column || lastOriginalName !== original.name) {
        map.addMapping({
          source: original.source,
          original: {
            line: original.line,
            column: original.column
          },
          generated: {
            line: generated.line,
            column: generated.column
          },
          name: original.name
        });
      }

      lastOriginalSource = original.source;
      lastOriginalLine = original.line;
      lastOriginalColumn = original.column;
      lastOriginalName = original.name;
      sourceMappingActive = true;
    } else if (sourceMappingActive) {
      map.addMapping({
        generated: {
          line: generated.line,
          column: generated.column
        }
      });
      lastOriginalSource = null;
      sourceMappingActive = false;
    }

    for (var idx = 0, length = chunk.length; idx < length; idx++) {
      if (chunk.charCodeAt(idx) === NEWLINE_CODE) {
        generated.line++;
        generated.column = 0; // Mappings end at eol

        if (idx + 1 === length) {
          lastOriginalSource = null;
          sourceMappingActive = false;
        } else if (sourceMappingActive) {
          map.addMapping({
            source: original.source,
            original: {
              line: original.line,
              column: original.column
            },
            generated: {
              line: generated.line,
              column: generated.column
            },
            name: original.name
          });
        }
      } else {
        generated.column++;
      }
    }
  });
  this.walkSourceContents(function (sourceFile, sourceContent) {
    map.setSourceContent(sourceFile, sourceContent);
  });
  return {
    code: generated.code,
    map: map
  };
};

var SourceNode_1 = SourceNode;
var sourceNode = {
  SourceNode: SourceNode_1
};

/*
 * Copyright 2009-2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE.txt or:
 * http://opensource.org/licenses/BSD-3-Clause
 */
var SourceMapGenerator$2 = sourceMapGenerator.SourceMapGenerator;
var SourceMapConsumer$1 = sourceMapConsumer.SourceMapConsumer;
var SourceNode$1 = sourceNode.SourceNode;
var sourceMap = {
  SourceMapGenerator: SourceMapGenerator$2,
  SourceMapConsumer: SourceMapConsumer$1,
  SourceNode: SourceNode$1
};

var toString = Object.prototype.toString;
var isModern = typeof Buffer.alloc === 'function' && typeof Buffer.allocUnsafe === 'function' && typeof Buffer.from === 'function';

function isArrayBuffer(input) {
  return toString.call(input).slice(8, -1) === 'ArrayBuffer';
}

function fromArrayBuffer(obj, byteOffset, length) {
  byteOffset >>>= 0;
  var maxLength = obj.byteLength - byteOffset;

  if (maxLength < 0) {
    throw new RangeError("'offset' is out of bounds");
  }

  if (length === undefined) {
    length = maxLength;
  } else {
    length >>>= 0;

    if (length > maxLength) {
      throw new RangeError("'length' is out of bounds");
    }
  }

  return isModern ? Buffer.from(obj.slice(byteOffset, byteOffset + length)) : new Buffer(new Uint8Array(obj.slice(byteOffset, byteOffset + length)));
}

function fromString(string, encoding) {
  if (typeof encoding !== 'string' || encoding === '') {
    encoding = 'utf8';
  }

  if (!Buffer.isEncoding(encoding)) {
    throw new TypeError('"encoding" must be a valid string encoding');
  }

  return isModern ? Buffer.from(string, encoding) : new Buffer(string, encoding);
}

function bufferFrom(value, encodingOrOffset, length) {
  if (typeof value === 'number') {
    throw new TypeError('"value" argument must not be a number');
  }

  if (isArrayBuffer(value)) {
    return fromArrayBuffer(value, encodingOrOffset, length);
  }

  if (typeof value === 'string') {
    return fromString(value, encodingOrOffset);
  }

  return isModern ? Buffer.from(value) : new Buffer(value);
}

var bufferFrom_1 = bufferFrom;

var sourceMapSupport = createCommonjsModule(function (module, exports) {
  var SourceMapConsumer = sourceMap.SourceMapConsumer;
  var path = require$$1__default['default'];
  var fs;

  try {
    fs = require$$2__default['default'];

    if (!fs.existsSync || !fs.readFileSync) {
      // fs doesn't have all methods we need
      fs = null;
    }
  } catch (err) {
    /* nop */
  }
  /**
   * Requires a module which is protected against bundler minification.
   *
   * @param {NodeModule} mod
   * @param {string} request
   */


  function dynamicRequire(mod, request) {
    return mod.require(request);
  } // Only install once if called multiple times


  var errorFormatterInstalled = false;
  var uncaughtShimInstalled = false; // If true, the caches are reset before a stack trace formatting operation

  var emptyCacheBetweenOperations = false; // Supports {browser, node, auto}

  var environment = "auto"; // Maps a file path to a string containing the file contents

  var fileContentsCache = {}; // Maps a file path to a source map for that file

  var sourceMapCache = {}; // Regex for detecting source maps

  var reSourceMap = /^data:application\/json[^,]+base64,/; // Priority list of retrieve handlers

  var retrieveFileHandlers = [];
  var retrieveMapHandlers = [];

  function isInBrowser() {
    if (environment === "browser") return true;
    if (environment === "node") return false;
    return typeof window !== 'undefined' && typeof XMLHttpRequest === 'function' && !(window.require && window.module && window.process && window.process.type === "renderer");
  }

  function hasGlobalProcessEventEmitter() {
    return typeof process === 'object' && process !== null && typeof process.on === 'function';
  }

  function handlerExec(list) {
    return function (arg) {
      for (var i = 0; i < list.length; i++) {
        var ret = list[i](arg);

        if (ret) {
          return ret;
        }
      }

      return null;
    };
  }

  var retrieveFile = handlerExec(retrieveFileHandlers);
  retrieveFileHandlers.push(function (path) {
    // Trim the path to make sure there is no extra whitespace.
    path = path.trim();

    if (/^file:/.test(path)) {
      // existsSync/readFileSync can't handle file protocol, but once stripped, it works
      path = path.replace(/file:\/\/\/(\w:)?/, function (protocol, drive) {
        return drive ? '' : // file:///C:/dir/file -> C:/dir/file
        '/'; // file:///root-dir/file -> /root-dir/file
      });
    }

    if (path in fileContentsCache) {
      return fileContentsCache[path];
    }

    var contents = '';

    try {
      if (!fs) {
        // Use SJAX if we are in the browser
        var xhr = new XMLHttpRequest();
        xhr.open('GET', path,
        /** async */
        false);
        xhr.send(null);

        if (xhr.readyState === 4 && xhr.status === 200) {
          contents = xhr.responseText;
        }
      } else if (fs.existsSync(path)) {
        // Otherwise, use the filesystem
        contents = fs.readFileSync(path, 'utf8');
      }
    } catch (er) {
      /* ignore any errors */
    }

    return fileContentsCache[path] = contents;
  }); // Support URLs relative to a directory, but be careful about a protocol prefix
  // in case we are in the browser (i.e. directories may start with "http://" or "file:///")

  function supportRelativeURL(file, url) {
    if (!file) return url;
    var dir = path.dirname(file);
    var match = /^\w+:\/\/[^\/]*/.exec(dir);
    var protocol = match ? match[0] : '';
    var startPath = dir.slice(protocol.length);

    if (protocol && /^\/\w\:/.test(startPath)) {
      // handle file:///C:/ paths
      protocol += '/';
      return protocol + path.resolve(dir.slice(protocol.length), url).replace(/\\/g, '/');
    }

    return protocol + path.resolve(dir.slice(protocol.length), url);
  }

  function retrieveSourceMapURL(source) {
    var fileData;

    if (isInBrowser()) {
      try {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', source, false);
        xhr.send(null);
        fileData = xhr.readyState === 4 ? xhr.responseText : null; // Support providing a sourceMappingURL via the SourceMap header

        var sourceMapHeader = xhr.getResponseHeader("SourceMap") || xhr.getResponseHeader("X-SourceMap");

        if (sourceMapHeader) {
          return sourceMapHeader;
        }
      } catch (e) {}
    } // Get the URL of the source map


    fileData = retrieveFile(source);
    var re = /(?:\/\/[@#][\s]*sourceMappingURL=([^\s'"]+)[\s]*$)|(?:\/\*[@#][\s]*sourceMappingURL=([^\s*'"]+)[\s]*(?:\*\/)[\s]*$)/mg; // Keep executing the search to find the *last* sourceMappingURL to avoid
    // picking up sourceMappingURLs from comments, strings, etc.

    var lastMatch, match;

    while (match = re.exec(fileData)) lastMatch = match;

    if (!lastMatch) return null;
    return lastMatch[1];
  }
  // generated source filename; returns a {map, optional url} object, or null if
  // there is no source map.  The map field may be either a string or the parsed
  // JSON object (ie, it must be a valid argument to the SourceMapConsumer
  // constructor).

  var retrieveSourceMap = handlerExec(retrieveMapHandlers);
  retrieveMapHandlers.push(function (source) {
    var sourceMappingURL = retrieveSourceMapURL(source);
    if (!sourceMappingURL) return null; // Read the contents of the source map

    var sourceMapData;

    if (reSourceMap.test(sourceMappingURL)) {
      // Support source map URL as a data url
      var rawData = sourceMappingURL.slice(sourceMappingURL.indexOf(',') + 1);
      sourceMapData = bufferFrom_1(rawData, "base64").toString();
      sourceMappingURL = source;
    } else {
      // Support source map URLs relative to the source URL
      sourceMappingURL = supportRelativeURL(source, sourceMappingURL);
      sourceMapData = retrieveFile(sourceMappingURL);
    }

    if (!sourceMapData) {
      return null;
    }

    return {
      url: sourceMappingURL,
      map: sourceMapData
    };
  });

  function mapSourcePosition(position) {
    var sourceMap = sourceMapCache[position.source];

    if (!sourceMap) {
      // Call the (overrideable) retrieveSourceMap function to get the source map.
      var urlAndMap = retrieveSourceMap(position.source);

      if (urlAndMap) {
        sourceMap = sourceMapCache[position.source] = {
          url: urlAndMap.url,
          map: new SourceMapConsumer(urlAndMap.map)
        }; // Load all sources stored inline with the source map into the file cache
        // to pretend like they are already loaded. They may not exist on disk.

        if (sourceMap.map.sourcesContent) {
          sourceMap.map.sources.forEach(function (source, i) {
            var contents = sourceMap.map.sourcesContent[i];

            if (contents) {
              var url = supportRelativeURL(sourceMap.url, source);
              fileContentsCache[url] = contents;
            }
          });
        }
      } else {
        sourceMap = sourceMapCache[position.source] = {
          url: null,
          map: null
        };
      }
    } // Resolve the source URL relative to the URL of the source map


    if (sourceMap && sourceMap.map && typeof sourceMap.map.originalPositionFor === 'function') {
      var originalPosition = sourceMap.map.originalPositionFor(position); // Only return the original position if a matching line was found. If no
      // matching line is found then we return position instead, which will cause
      // the stack trace to print the path and line for the compiled file. It is
      // better to give a precise location in the compiled file than a vague
      // location in the original file.

      if (originalPosition.source !== null) {
        originalPosition.source = supportRelativeURL(sourceMap.url, originalPosition.source);
        return originalPosition;
      }
    }

    return position;
  } // Parses code generated by FormatEvalOrigin(), a function inside V8:
  // https://code.google.com/p/v8/source/browse/trunk/src/messages.js


  function mapEvalOrigin(origin) {
    // Most eval() calls are in this format
    var match = /^eval at ([^(]+) \((.+):(\d+):(\d+)\)$/.exec(origin);

    if (match) {
      var position = mapSourcePosition({
        source: match[2],
        line: +match[3],
        column: match[4] - 1
      });
      return 'eval at ' + match[1] + ' (' + position.source + ':' + position.line + ':' + (position.column + 1) + ')';
    } // Parse nested eval() calls using recursion


    match = /^eval at ([^(]+) \((.+)\)$/.exec(origin);

    if (match) {
      return 'eval at ' + match[1] + ' (' + mapEvalOrigin(match[2]) + ')';
    } // Make sure we still return useful information if we didn't find anything


    return origin;
  } // This is copied almost verbatim from the V8 source code at
  // https://code.google.com/p/v8/source/browse/trunk/src/messages.js. The
  // implementation of wrapCallSite() used to just forward to the actual source
  // code of CallSite.prototype.toString but unfortunately a new release of V8
  // did something to the prototype chain and broke the shim. The only fix I
  // could find was copy/paste.


  function CallSiteToString() {
    var fileName;
    var fileLocation = "";

    if (this.isNative()) {
      fileLocation = "native";
    } else {
      fileName = this.getScriptNameOrSourceURL();

      if (!fileName && this.isEval()) {
        fileLocation = this.getEvalOrigin();
        fileLocation += ", "; // Expecting source position to follow.
      }

      if (fileName) {
        fileLocation += fileName;
      } else {
        // Source code does not originate from a file and is not native, but we
        // can still get the source position inside the source string, e.g. in
        // an eval string.
        fileLocation += "<anonymous>";
      }

      var lineNumber = this.getLineNumber();

      if (lineNumber != null) {
        fileLocation += ":" + lineNumber;
        var columnNumber = this.getColumnNumber();

        if (columnNumber) {
          fileLocation += ":" + columnNumber;
        }
      }
    }

    var line = "";
    var functionName = this.getFunctionName();
    var addSuffix = true;
    var isConstructor = this.isConstructor();
    var isMethodCall = !(this.isToplevel() || isConstructor);

    if (isMethodCall) {
      var typeName = this.getTypeName(); // Fixes shim to be backward compatable with Node v0 to v4

      if (typeName === "[object Object]") {
        typeName = "null";
      }

      var methodName = this.getMethodName();

      if (functionName) {
        if (typeName && functionName.indexOf(typeName) != 0) {
          line += typeName + ".";
        }

        line += functionName;

        if (methodName && functionName.indexOf("." + methodName) != functionName.length - methodName.length - 1) {
          line += " [as " + methodName + "]";
        }
      } else {
        line += typeName + "." + (methodName || "<anonymous>");
      }
    } else if (isConstructor) {
      line += "new " + (functionName || "<anonymous>");
    } else if (functionName) {
      line += functionName;
    } else {
      line += fileLocation;
      addSuffix = false;
    }

    if (addSuffix) {
      line += " (" + fileLocation + ")";
    }

    return line;
  }

  function cloneCallSite(frame) {
    var object = {};
    Object.getOwnPropertyNames(Object.getPrototypeOf(frame)).forEach(function (name) {
      object[name] = /^(?:is|get)/.test(name) ? function () {
        return frame[name].call(frame);
      } : frame[name];
    });
    object.toString = CallSiteToString;
    return object;
  }

  function wrapCallSite(frame, state) {
    // provides interface backward compatibility
    if (state === undefined) {
      state = {
        nextPosition: null,
        curPosition: null
      };
    }

    if (frame.isNative()) {
      state.curPosition = null;
      return frame;
    } // Most call sites will return the source file from getFileName(), but code
    // passed to eval() ending in "//# sourceURL=..." will return the source file
    // from getScriptNameOrSourceURL() instead


    var source = frame.getFileName() || frame.getScriptNameOrSourceURL();

    if (source) {
      var line = frame.getLineNumber();
      var column = frame.getColumnNumber() - 1; // Fix position in Node where some (internal) code is prepended.
      // See https://github.com/evanw/node-source-map-support/issues/36
      // Header removed in node at ^10.16 || >=11.11.0
      // v11 is not an LTS candidate, we can just test the one version with it.
      // Test node versions for: 10.16-19, 10.20+, 12-19, 20-99, 100+, or 11.11

      var noHeader = /^v(10\.1[6-9]|10\.[2-9][0-9]|10\.[0-9]{3,}|1[2-9]\d*|[2-9]\d|\d{3,}|11\.11)/;
      var headerLength = noHeader.test(process.version) ? 0 : 62;

      if (line === 1 && column > headerLength && !isInBrowser() && !frame.isEval()) {
        column -= headerLength;
      }

      var position = mapSourcePosition({
        source: source,
        line: line,
        column: column
      });
      state.curPosition = position;
      frame = cloneCallSite(frame);
      var originalFunctionName = frame.getFunctionName;

      frame.getFunctionName = function () {
        if (state.nextPosition == null) {
          return originalFunctionName();
        }

        return state.nextPosition.name || originalFunctionName();
      };

      frame.getFileName = function () {
        return position.source;
      };

      frame.getLineNumber = function () {
        return position.line;
      };

      frame.getColumnNumber = function () {
        return position.column + 1;
      };

      frame.getScriptNameOrSourceURL = function () {
        return position.source;
      };

      return frame;
    } // Code called using eval() needs special handling


    var origin = frame.isEval() && frame.getEvalOrigin();

    if (origin) {
      origin = mapEvalOrigin(origin);
      frame = cloneCallSite(frame);

      frame.getEvalOrigin = function () {
        return origin;
      };

      return frame;
    } // If we get here then we were unable to change the source position


    return frame;
  } // This function is part of the V8 stack trace API, for more info see:
  // https://v8.dev/docs/stack-trace-api


  function prepareStackTrace(error, stack) {
    if (emptyCacheBetweenOperations) {
      fileContentsCache = {};
      sourceMapCache = {};
    }

    var name = error.name || 'Error';
    var message = error.message || '';
    var errorString = name + ": " + message;
    var state = {
      nextPosition: null,
      curPosition: null
    };
    var processedStack = [];

    for (var i = stack.length - 1; i >= 0; i--) {
      processedStack.push('\n    at ' + wrapCallSite(stack[i], state));
      state.nextPosition = state.curPosition;
    }

    state.curPosition = state.nextPosition = null;
    return errorString + processedStack.reverse().join('');
  } // Generate position and snippet of original source with pointer


  function getErrorSource(error) {
    var match = /\n    at [^(]+ \((.*):(\d+):(\d+)\)/.exec(error.stack);

    if (match) {
      var source = match[1];
      var line = +match[2];
      var column = +match[3]; // Support the inline sourceContents inside the source map

      var contents = fileContentsCache[source]; // Support files on disk

      if (!contents && fs && fs.existsSync(source)) {
        try {
          contents = fs.readFileSync(source, 'utf8');
        } catch (er) {
          contents = '';
        }
      } // Format the line from the original source code like node does


      if (contents) {
        var code = contents.split(/(?:\r\n|\r|\n)/)[line - 1];

        if (code) {
          return source + ':' + line + '\n' + code + '\n' + new Array(column).join(' ') + '^';
        }
      }
    }

    return null;
  }

  function printErrorAndExit(error) {
    var source = getErrorSource(error); // Ensure error is printed synchronously and not truncated

    if (process.stderr._handle && process.stderr._handle.setBlocking) {
      process.stderr._handle.setBlocking(true);
    }

    if (source) {
      console.error();
      console.error(source);
    }

    console.error(error.stack);
    process.exit(1);
  }

  function shimEmitUncaughtException() {
    var origEmit = process.emit;

    process.emit = function (type) {
      if (type === 'uncaughtException') {
        var hasStack = arguments[1] && arguments[1].stack;
        var hasListeners = this.listeners(type).length > 0;

        if (hasStack && !hasListeners) {
          return printErrorAndExit(arguments[1]);
        }
      }

      return origEmit.apply(this, arguments);
    };
  }

  var originalRetrieveFileHandlers = retrieveFileHandlers.slice(0);
  var originalRetrieveMapHandlers = retrieveMapHandlers.slice(0);
  exports.wrapCallSite = wrapCallSite;
  exports.getErrorSource = getErrorSource;
  exports.mapSourcePosition = mapSourcePosition;
  exports.retrieveSourceMap = retrieveSourceMap;

  exports.install = function (options) {
    options = options || {};

    if (options.environment) {
      environment = options.environment;

      if (["node", "browser", "auto"].indexOf(environment) === -1) {
        throw new Error("environment " + environment + " was unknown. Available options are {auto, browser, node}");
      }
    } // Allow sources to be found by methods other than reading the files
    // directly from disk.


    if (options.retrieveFile) {
      if (options.overrideRetrieveFile) {
        retrieveFileHandlers.length = 0;
      }

      retrieveFileHandlers.unshift(options.retrieveFile);
    } // Allow source maps to be found by methods other than reading the files
    // directly from disk.


    if (options.retrieveSourceMap) {
      if (options.overrideRetrieveSourceMap) {
        retrieveMapHandlers.length = 0;
      }

      retrieveMapHandlers.unshift(options.retrieveSourceMap);
    } // Support runtime transpilers that include inline source maps


    if (options.hookRequire && !isInBrowser()) {
      // Use dynamicRequire to avoid including in browser bundles
      var Module = dynamicRequire(module, 'module');
      var $compile = Module.prototype._compile;

      if (!$compile.__sourceMapSupport) {
        Module.prototype._compile = function (content, filename) {
          fileContentsCache[filename] = content;
          sourceMapCache[filename] = undefined;
          return $compile.call(this, content, filename);
        };

        Module.prototype._compile.__sourceMapSupport = true;
      }
    } // Configure options


    if (!emptyCacheBetweenOperations) {
      emptyCacheBetweenOperations = 'emptyCacheBetweenOperations' in options ? options.emptyCacheBetweenOperations : false;
    } // Install the error reformatter


    if (!errorFormatterInstalled) {
      errorFormatterInstalled = true;
      Error.prepareStackTrace = prepareStackTrace;
    }

    if (!uncaughtShimInstalled) {
      var installHandler = 'handleUncaughtExceptions' in options ? options.handleUncaughtExceptions : true; // Do not override 'uncaughtException' with our own handler in Node.js
      // Worker threads. Workers pass the error to the main thread as an event,
      // rather than printing something to stderr and exiting.

      try {
        // We need to use `dynamicRequire` because `require` on it's own will be optimized by WebPack/Browserify.
        var worker_threads = dynamicRequire(module, 'worker_threads');

        if (worker_threads.isMainThread === false) {
          installHandler = false;
        }
      } catch (e) {} // Provide the option to not install the uncaught exception handler. This is
      // to support other uncaught exception handlers (in test frameworks, for
      // example). If this handler is not installed and there are no other uncaught
      // exception handlers, uncaught exceptions will be caught by node's built-in
      // exception handler and the process will still be terminated. However, the
      // generated JavaScript code will be shown above the stack trace instead of
      // the original source code.


      if (installHandler && hasGlobalProcessEventEmitter()) {
        uncaughtShimInstalled = true;
        shimEmitUncaughtException();
      }
    }
  };

  exports.resetRetrieveHandlers = function () {
    retrieveFileHandlers.length = 0;
    retrieveMapHandlers.length = 0;
    retrieveFileHandlers = originalRetrieveFileHandlers.slice(0);
    retrieveMapHandlers = originalRetrieveMapHandlers.slice(0);
    retrieveSourceMap = handlerExec(retrieveMapHandlers);
    retrieveFile = handlerExec(retrieveFileHandlers);
  };
});

sourceMapSupport.install();

/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */

/* global Reflect, Promise */
var extendStatics = function (d, b) {
  extendStatics = Object.setPrototypeOf || {
    __proto__: []
  } instanceof Array && function (d, b) {
    d.__proto__ = b;
  } || function (d, b) {
    for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
  };

  return extendStatics(d, b);
};

function __extends(d, b) {
  if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
  extendStatics(d, b);

  function __() {
    this.constructor = d;
  }

  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign = function () {
  __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }

    return t;
  };

  return __assign.apply(this, arguments);
};
function __awaiter(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
}
function __generator(thisArg, body) {
  var _ = {
    label: 0,
    sent: function () {
      if (t[0] & 1) throw t[1];
      return t[1];
    },
    trys: [],
    ops: []
  },
      f,
      y,
      t,
      g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;

  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }

  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");

    while (_) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];

      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;

        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };

        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;

        case 7:
          op = _.ops.pop();

          _.trys.pop();

          continue;

        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }

          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }

          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }

          if (t && _.label < t[2]) {
            _.label = t[2];

            _.ops.push(op);

            break;
          }

          if (t[2]) _.ops.pop();

          _.trys.pop();

          continue;
      }

      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }

    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
}

var name = "@aws-sdk/client-s3";
var description = "AWS SDK for JavaScript S3 Client for Node.js, Browser and React Native";
var version = "3.6.0";
var scripts = {
	clean: "yarn remove-definitions && yarn remove-dist && yarn remove-documentation",
	"build-documentation": "yarn remove-documentation && typedoc ./",
	prepublishOnly: "yarn build",
	pretest: "yarn build:cjs",
	"remove-definitions": "rimraf ./types",
	"remove-dist": "rimraf ./dist",
	"remove-documentation": "rimraf ./docs",
	"test:unit": "mocha **/cjs/**/*.spec.js",
	"test:e2e": "mocha **/cjs/**/*.ispec.js && karma start karma.conf.js",
	test: "yarn test:unit",
	"build:cjs": "tsc -p tsconfig.json",
	"build:es": "tsc -p tsconfig.es.json",
	build: "yarn build:cjs && yarn build:es",
	postbuild: "downlevel-dts types types/ts3.4"
};
var main = "./dist/cjs/index.js";
var types = "./types/index.d.ts";
var module$1 = "./dist/es/index.js";
var browser = {
	"./runtimeConfig": "./runtimeConfig.browser"
};
var sideEffects = false;
var dependencies = {
	"@aws-crypto/sha256-browser": "^1.0.0",
	"@aws-crypto/sha256-js": "^1.0.0",
	"@aws-sdk/config-resolver": "3.6.0",
	"@aws-sdk/credential-provider-node": "3.6.0",
	"@aws-sdk/eventstream-serde-browser": "3.4.1",
	"@aws-sdk/eventstream-serde-config-resolver": "3.4.1",
	"@aws-sdk/eventstream-serde-node": "3.4.1",
	"@aws-sdk/fetch-http-handler": "3.5.0",
	"@aws-sdk/hash-blob-browser": "3.4.1",
	"@aws-sdk/hash-node": "3.4.1",
	"@aws-sdk/hash-stream-node": "3.4.1",
	"@aws-sdk/invalid-dependency": "3.4.1",
	"@aws-sdk/md5-js": "3.4.1",
	"@aws-sdk/middleware-apply-body-checksum": "3.5.0",
	"@aws-sdk/middleware-bucket-endpoint": "3.6.0",
	"@aws-sdk/middleware-content-length": "3.5.0",
	"@aws-sdk/middleware-expect-continue": "3.5.0",
	"@aws-sdk/middleware-host-header": "3.5.0",
	"@aws-sdk/middleware-location-constraint": "3.4.1",
	"@aws-sdk/middleware-logger": "3.5.0",
	"@aws-sdk/middleware-retry": "3.6.0",
	"@aws-sdk/middleware-sdk-s3": "3.5.0",
	"@aws-sdk/middleware-serde": "3.4.1",
	"@aws-sdk/middleware-signing": "3.5.0",
	"@aws-sdk/middleware-ssec": "3.4.1",
	"@aws-sdk/middleware-stack": "3.4.1",
	"@aws-sdk/middleware-user-agent": "3.5.0",
	"@aws-sdk/node-config-provider": "3.6.0",
	"@aws-sdk/node-http-handler": "3.5.0",
	"@aws-sdk/protocol-http": "3.5.0",
	"@aws-sdk/smithy-client": "3.5.0",
	"@aws-sdk/types": "3.4.1",
	"@aws-sdk/url-parser": "3.4.1",
	"@aws-sdk/url-parser-native": "3.4.1",
	"@aws-sdk/util-base64-browser": "3.4.1",
	"@aws-sdk/util-base64-node": "3.4.1",
	"@aws-sdk/util-body-length-browser": "3.4.1",
	"@aws-sdk/util-body-length-node": "3.4.1",
	"@aws-sdk/util-user-agent-browser": "3.5.0",
	"@aws-sdk/util-user-agent-node": "3.6.0",
	"@aws-sdk/util-utf8-browser": "3.4.1",
	"@aws-sdk/util-utf8-node": "3.4.1",
	"@aws-sdk/util-waiter": "3.4.1",
	"@aws-sdk/xml-builder": "3.4.1",
	"fast-xml-parser": "^3.16.0",
	tslib: "^2.0.0"
};
var devDependencies = {
	"@aws-sdk/client-documentation-generator": "3.4.1",
	"@types/chai": "^4.2.11",
	"@types/mocha": "^8.0.4",
	"@types/node": "^12.7.5",
	"downlevel-dts": "0.7.0",
	jest: "^26.1.0",
	rimraf: "^3.0.0",
	typedoc: "^0.19.2",
	typescript: "~4.1.2"
};
var engines = {
	node: ">=10.0.0"
};
var typesVersions = {
	"<4.0": {
		"types/*": [
			"types/ts3.4/*"
		]
	}
};
var author = {
	name: "AWS SDK for JavaScript Team",
	url: "https://aws.amazon.com/javascript/"
};
var license = "Apache-2.0";
var homepage = "https://github.com/aws/aws-sdk-js-v3/tree/master/clients/client-s3";
var repository = {
	type: "git",
	url: "https://github.com/aws/aws-sdk-js-v3.git",
	directory: "clients/client-s3"
};
var packageInfo = {
	name: name,
	description: description,
	version: version,
	scripts: scripts,
	main: main,
	types: types,
	module: module$1,
	browser: browser,
	"react-native": {
	"./runtimeConfig": "./runtimeConfig.native"
},
	sideEffects: sideEffects,
	dependencies: dependencies,
	devDependencies: devDependencies,
	engines: engines,
	typesVersions: typesVersions,
	author: author,
	license: license,
	homepage: homepage,
	repository: repository
};

/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */

/* global Reflect, Promise */
var extendStatics$1 = function (d, b) {
  extendStatics$1 = Object.setPrototypeOf || {
    __proto__: []
  } instanceof Array && function (d, b) {
    d.__proto__ = b;
  } || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
  };

  return extendStatics$1(d, b);
};

function __extends$1(d, b) {
  extendStatics$1(d, b);

  function __() {
    this.constructor = d;
  }

  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign$1 = function () {
  __assign$1 = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }

    return t;
  };

  return __assign$1.apply(this, arguments);
};
function __rest(s, e) {
  var t = {};

  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
}
function __decorate(decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function __param(paramIndex, decorator) {
  return function (target, key) {
    decorator(target, key, paramIndex);
  };
}
function __metadata(metadataKey, metadataValue) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}
function __awaiter$1(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
}
function __generator$1(thisArg, body) {
  var _ = {
    label: 0,
    sent: function () {
      if (t[0] & 1) throw t[1];
      return t[1];
    },
    trys: [],
    ops: []
  },
      f,
      y,
      t,
      g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;

  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }

  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");

    while (_) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];

      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;

        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };

        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;

        case 7:
          op = _.ops.pop();

          _.trys.pop();

          continue;

        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }

          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }

          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }

          if (t && _.label < t[2]) {
            _.label = t[2];

            _.ops.push(op);

            break;
          }

          if (t[2]) _.ops.pop();

          _.trys.pop();

          continue;
      }

      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }

    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
}
function __createBinding(o, m, k, k2) {
  if (k2 === undefined) k2 = k;
  o[k2] = m[k];
}
function __exportStar(m, exports) {
  for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) exports[p] = m[p];
}
function __values(o) {
  var s = typeof Symbol === "function" && Symbol.iterator,
      m = s && o[s],
      i = 0;
  if (m) return m.call(o);
  if (o && typeof o.length === "number") return {
    next: function () {
      if (o && i >= o.length) o = void 0;
      return {
        value: o && o[i++],
        done: !o
      };
    }
  };
  throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o),
      r,
      ar = [],
      e;

  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = {
      error: error
    };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }

  return ar;
}
function __spread() {
  for (var ar = [], i = 0; i < arguments.length; i++) ar = ar.concat(__read(arguments[i]));

  return ar;
}
function __spreadArrays() {
  for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;

  for (var r = Array(s), k = 0, i = 0; i < il; i++) for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) r[k] = a[j];

  return r;
}
function __await(v) {
  return this instanceof __await ? (this.v = v, this) : new __await(v);
}
function __asyncGenerator(thisArg, _arguments, generator) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var g = generator.apply(thisArg, _arguments || []),
      i,
      q = [];
  return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
    return this;
  }, i;

  function verb(n) {
    if (g[n]) i[n] = function (v) {
      return new Promise(function (a, b) {
        q.push([n, v, a, b]) > 1 || resume(n, v);
      });
    };
  }

  function resume(n, v) {
    try {
      step(g[n](v));
    } catch (e) {
      settle(q[0][3], e);
    }
  }

  function step(r) {
    r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
  }

  function fulfill(value) {
    resume("next", value);
  }

  function reject(value) {
    resume("throw", value);
  }

  function settle(f, v) {
    if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
  }
}
function __asyncDelegator(o) {
  var i, p;
  return i = {}, verb("next"), verb("throw", function (e) {
    throw e;
  }), verb("return"), i[Symbol.iterator] = function () {
    return this;
  }, i;

  function verb(n, f) {
    i[n] = o[n] ? function (v) {
      return (p = !p) ? {
        value: __await(o[n](v)),
        done: n === "return"
      } : f ? f(v) : v;
    } : f;
  }
}
function __asyncValues(o) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var m = o[Symbol.asyncIterator],
      i;
  return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
    return this;
  }, i);

  function verb(n) {
    i[n] = o[n] && function (v) {
      return new Promise(function (resolve, reject) {
        v = o[n](v), settle(resolve, reject, v.done, v.value);
      });
    };
  }

  function settle(resolve, reject, d, v) {
    Promise.resolve(v).then(function (v) {
      resolve({
        value: v,
        done: d
      });
    }, reject);
  }
}
function __makeTemplateObject(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", {
      value: raw
    });
  } else {
    cooked.raw = raw;
  }

  return cooked;
}
function __importStar(mod) {
  if (mod && mod.__esModule) return mod;
  var result = {};
  if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
  result.default = mod;
  return result;
}
function __importDefault(mod) {
  return mod && mod.__esModule ? mod : {
    default: mod
  };
}
function __classPrivateFieldGet(receiver, privateMap) {
  if (!privateMap.has(receiver)) {
    throw new TypeError("attempted to get private field on non-instance");
  }

  return privateMap.get(receiver);
}
function __classPrivateFieldSet(receiver, privateMap, value) {
  if (!privateMap.has(receiver)) {
    throw new TypeError("attempted to set private field on non-instance");
  }

  privateMap.set(receiver, value);
  return value;
}

var tslib_es6 = /*#__PURE__*/Object.freeze({
	__proto__: null,
	__extends: __extends$1,
	get __assign () { return __assign$1; },
	__rest: __rest,
	__decorate: __decorate,
	__param: __param,
	__metadata: __metadata,
	__awaiter: __awaiter$1,
	__generator: __generator$1,
	__createBinding: __createBinding,
	__exportStar: __exportStar,
	__values: __values,
	__read: __read,
	__spread: __spread,
	__spreadArrays: __spreadArrays,
	__await: __await,
	__asyncGenerator: __asyncGenerator,
	__asyncDelegator: __asyncDelegator,
	__asyncValues: __asyncValues,
	__makeTemplateObject: __makeTemplateObject,
	__importStar: __importStar,
	__importDefault: __importDefault,
	__classPrivateFieldGet: __classPrivateFieldGet,
	__classPrivateFieldSet: __classPrivateFieldSet
});

var resolveEndpointsConfig = function (input) {
  var _a;

  return __assign$1(__assign$1({}, input), {
    tls: (_a = input.tls) !== null && _a !== void 0 ? _a : true,
    endpoint: input.endpoint ? normalizeEndpoint(input) : function () {
      return getEndPointFromRegion(input);
    },
    isCustomEndpoint: input.endpoint ? true : false
  });
};

var normalizeEndpoint = function (input) {
  var endpoint = input.endpoint,
      urlParser = input.urlParser;

  if (typeof endpoint === "string") {
    var promisified_1 = Promise.resolve(urlParser(endpoint));
    return function () {
      return promisified_1;
    };
  } else if (typeof endpoint === "object") {
    var promisified_2 = Promise.resolve(endpoint);
    return function () {
      return promisified_2;
    };
  }

  return endpoint;
};

var getEndPointFromRegion = function (input) {
  return __awaiter$1(void 0, void 0, void 0, function () {
    var _a, tls, region, dnsHostRegex, hostname;

    var _b;

    return __generator$1(this, function (_c) {
      switch (_c.label) {
        case 0:
          _a = input.tls, tls = _a === void 0 ? true : _a;
          return [4
          /*yield*/
          , input.region()];

        case 1:
          region = _c.sent();
          dnsHostRegex = new RegExp(/^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])$/);

          if (!dnsHostRegex.test(region)) {
            throw new Error("Invalid region in client config");
          }

          return [4
          /*yield*/
          , input.regionInfoProvider(region)];

        case 2:
          hostname = ((_b = _c.sent()) !== null && _b !== void 0 ? _b : {}).hostname;

          if (!hostname) {
            throw new Error("Cannot resolve hostname from client config");
          }

          return [2
          /*return*/
          , input.urlParser((tls ? "https:" : "http:") + "//" + hostname)];
      }
    });
  });
};

var REGION_ENV_NAME = "AWS_REGION";
var REGION_INI_NAME = "region";
var NODE_REGION_CONFIG_OPTIONS = {
  environmentVariableSelector: function (env) {
    return env[REGION_ENV_NAME];
  },
  configFileSelector: function (profile) {
    return profile[REGION_INI_NAME];
  },
  default: function () {
    throw new Error("Region is missing");
  }
};
var NODE_REGION_CONFIG_FILE_OPTIONS = {
  preferredFile: "credentials"
};
var resolveRegionConfig = function (input) {
  if (!input.region) {
    throw new Error("Region is missing");
  }

  return __assign$1(__assign$1({}, input), {
    region: normalizeRegion(input.region)
  });
};

var normalizeRegion = function (region) {
  if (typeof region === "string") {
    var promisified_1 = Promise.resolve(region);
    return function () {
      return promisified_1;
    };
  }

  return region;
};

/**
 * An error representing a failure of an individual credential provider.
 *
 * This error class has special meaning to the {@link chain} method. If a
 * provider in the chain is rejected with an error, the chain will only proceed
 * to the next provider if the value of the `tryNextLink` property on the error
 * is truthy. This allows individual providers to halt the chain and also
 * ensures the chain will stop if an entirely unexpected error is encountered.
 */

var ProviderError =
/** @class */
function (_super) {
  __extends$1(ProviderError, _super);

  function ProviderError(message, tryNextLink) {
    if (tryNextLink === void 0) {
      tryNextLink = true;
    }

    var _this = _super.call(this, message) || this;

    _this.tryNextLink = tryNextLink;
    return _this;
  }

  return ProviderError;
}(Error);

/**
 * Compose a single credential provider function from multiple credential
 * providers. The first provider in the argument list will always be invoked;
 * subsequent providers in the list will be invoked in the order in which the
 * were received if the preceding provider did not successfully resolve.
 *
 * If no providers were received or no provider resolves successfully, the
 * returned promise will be rejected.
 */

function chain() {
  var providers = [];

  for (var _i = 0; _i < arguments.length; _i++) {
    providers[_i] = arguments[_i];
  }

  return function () {
    var e_1, _a;

    var promise = Promise.reject(new ProviderError("No providers in chain"));

    var _loop_1 = function (provider) {
      promise = promise.catch(function (err) {
        if (err === null || err === void 0 ? void 0 : err.tryNextLink) {
          return provider();
        }

        throw err;
      });
    };

    try {
      for (var providers_1 = __values(providers), providers_1_1 = providers_1.next(); !providers_1_1.done; providers_1_1 = providers_1.next()) {
        var provider = providers_1_1.value;

        _loop_1(provider);
      }
    } catch (e_1_1) {
      e_1 = {
        error: e_1_1
      };
    } finally {
      try {
        if (providers_1_1 && !providers_1_1.done && (_a = providers_1.return)) _a.call(providers_1);
      } finally {
        if (e_1) throw e_1.error;
      }
    }

    return promise;
  };
}

var fromStatic = function (staticValue) {
  return function () {
    return Promise.resolve(staticValue);
  };
};

var memoize = function (provider, isExpired, requiresRefresh) {
  var result;
  var hasResult;

  if (isExpired === undefined) {
    // This is a static memoization; no need to incorporate refreshing
    return function () {
      if (!hasResult) {
        result = provider();
        hasResult = true;
      }

      return result;
    };
  }

  var isConstant = false;
  return function () {
    return __awaiter$1(void 0, void 0, void 0, function () {
      var resolved;
      return __generator$1(this, function (_a) {
        switch (_a.label) {
          case 0:
            if (!hasResult) {
              result = provider();
              hasResult = true;
            }

            if (isConstant) {
              return [2
              /*return*/
              , result];
            }

            return [4
            /*yield*/
            , result];

          case 1:
            resolved = _a.sent();

            if (requiresRefresh && !requiresRefresh(resolved)) {
              isConstant = true;
              return [2
              /*return*/
              , resolved];
            }

            if (isExpired(resolved)) {
              return [2
              /*return*/
              , result = provider()];
            }

            return [2
            /*return*/
            , resolved];
        }
      });
    });
  };
};

var ENV_KEY = "AWS_ACCESS_KEY_ID";
var ENV_SECRET = "AWS_SECRET_ACCESS_KEY";
var ENV_SESSION = "AWS_SESSION_TOKEN";
var ENV_EXPIRATION = "AWS_CREDENTIAL_EXPIRATION";
/**
 * Source AWS credentials from known environment variables. If either the
 * `AWS_ACCESS_KEY_ID` or `AWS_SECRET_ACCESS_KEY` environment variable is not
 * set in this process, the provider will return a rejected promise.
 */

function fromEnv() {
  return function () {
    var accessKeyId = process.env[ENV_KEY];
    var secretAccessKey = process.env[ENV_SECRET];
    var expiry = process.env[ENV_EXPIRATION];

    if (accessKeyId && secretAccessKey) {
      return Promise.resolve({
        accessKeyId: accessKeyId,
        secretAccessKey: secretAccessKey,
        sessionToken: process.env[ENV_SESSION],
        expiration: expiry ? new Date(expiry) : undefined
      });
    }

    return Promise.reject(new ProviderError("Unable to find environment variable credentials."));
  };
}

/**
 * @internal
 */

function httpRequest(options) {
  return new Promise(function (resolve, reject) {
    var req = http.request(__assign$1({
      method: "GET"
    }, options));
    req.on("error", function (err) {
      reject(Object.assign(new ProviderError("Unable to connect to instance metadata service"), err));
    });
    req.on("timeout", function () {
      reject(new Error("TimeoutError"));
    });
    req.on("response", function (res) {
      var _a = res.statusCode,
          statusCode = _a === void 0 ? 400 : _a;

      if (statusCode < 200 || 300 <= statusCode) {
        reject(Object.assign(new ProviderError("Error response received from instance metadata service"), {
          statusCode: statusCode
        }));
      }

      var chunks = [];
      res.on("data", function (chunk) {
        chunks.push(chunk);
      });
      res.on("end", function () {
        resolve(buffer.Buffer.concat(chunks));
      });
    });
    req.end();
  });
}

var isImdsCredentials = function (arg) {
  return Boolean(arg) && typeof arg === "object" && typeof arg.AccessKeyId === "string" && typeof arg.SecretAccessKey === "string" && typeof arg.Token === "string" && typeof arg.Expiration === "string";
};
var fromImdsCredentials = function (creds) {
  return {
    accessKeyId: creds.AccessKeyId,
    secretAccessKey: creds.SecretAccessKey,
    sessionToken: creds.Token,
    expiration: new Date(creds.Expiration)
  };
};

var DEFAULT_TIMEOUT = 1000; // The default in AWS SDK for Python and CLI (botocore) is no retry or one attempt
// https://github.com/boto/botocore/blob/646c61a7065933e75bab545b785e6098bc94c081/botocore/utils.py#L273

var DEFAULT_MAX_RETRIES = 0;
var providerConfigFromInit = function (_a) {
  var _b = _a.maxRetries,
      maxRetries = _b === void 0 ? DEFAULT_MAX_RETRIES : _b,
      _c = _a.timeout,
      timeout = _c === void 0 ? DEFAULT_TIMEOUT : _c;
  return {
    maxRetries: maxRetries,
    timeout: timeout
  };
};

/**
 * @internal
 */
var retry = function (toRetry, maxRetries) {
  var promise = toRetry();

  for (var i = 0; i < maxRetries; i++) {
    promise = promise.catch(toRetry);
  }

  return promise;
};

var ENV_CMDS_FULL_URI = "AWS_CONTAINER_CREDENTIALS_FULL_URI";
var ENV_CMDS_RELATIVE_URI = "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI";
var ENV_CMDS_AUTH_TOKEN = "AWS_CONTAINER_AUTHORIZATION_TOKEN";
/**
 * Creates a credential provider that will source credentials from the ECS
 * Container Metadata Service
 */

function fromContainerMetadata(init) {
  var _this = this;

  if (init === void 0) {
    init = {};
  }

  var _a = providerConfigFromInit(init),
      timeout = _a.timeout,
      maxRetries = _a.maxRetries;

  return function () {
    return getCmdsUri().then(function (url) {
      return retry(function () {
        return __awaiter$1(_this, void 0, void 0, function () {
          var credsResponse, _a, _b;

          return __generator$1(this, function (_c) {
            switch (_c.label) {
              case 0:
                _b = (_a = JSON).parse;
                return [4
                /*yield*/
                , requestFromEcsImds(timeout, url)];

              case 1:
                credsResponse = _b.apply(_a, [_c.sent()]);

                if (!isImdsCredentials(credsResponse)) {
                  throw new ProviderError("Invalid response received from instance metadata service.");
                }

                return [2
                /*return*/
                , fromImdsCredentials(credsResponse)];
            }
          });
        });
      }, maxRetries);
    });
  };
}

function requestFromEcsImds(timeout, options) {
  if (process.env[ENV_CMDS_AUTH_TOKEN]) {
    var _a = options.headers,
        headers = _a === void 0 ? {} : _a;
    headers.Authorization = process.env[ENV_CMDS_AUTH_TOKEN];
    options.headers = headers;
  }

  return httpRequest(__assign$1(__assign$1({}, options), {
    timeout: timeout
  })).then(function (buffer) {
    return buffer.toString();
  });
}

var CMDS_IP = "169.254.170.2";
var GREENGRASS_HOSTS = {
  localhost: true,
  "127.0.0.1": true
};
var GREENGRASS_PROTOCOLS = {
  "http:": true,
  "https:": true
};

function getCmdsUri() {
  if (process.env[ENV_CMDS_RELATIVE_URI]) {
    return Promise.resolve({
      hostname: CMDS_IP,
      path: process.env[ENV_CMDS_RELATIVE_URI]
    });
  }

  if (process.env[ENV_CMDS_FULL_URI]) {
    var parsed = url.parse(process.env[ENV_CMDS_FULL_URI]);

    if (!parsed.hostname || !(parsed.hostname in GREENGRASS_HOSTS)) {
      return Promise.reject(new ProviderError(parsed.hostname + " is not a valid container metadata service hostname", false));
    }

    if (!parsed.protocol || !(parsed.protocol in GREENGRASS_PROTOCOLS)) {
      return Promise.reject(new ProviderError(parsed.protocol + " is not a valid container metadata service protocol", false));
    }

    return Promise.resolve(__assign$1(__assign$1({}, parsed), {
      port: parsed.port ? parseInt(parsed.port, 10) : undefined
    }));
  }

  return Promise.reject(new ProviderError("The container metadata credential provider cannot be used unless" + (" the " + ENV_CMDS_RELATIVE_URI + " or " + ENV_CMDS_FULL_URI + " environment") + " variable is set", false));
}

var IMDS_IP = "169.254.169.254";
var IMDS_PATH = "/latest/meta-data/iam/security-credentials/";
var IMDS_TOKEN_PATH = "/latest/api/token";
/**
 * Creates a credential provider that will source credentials from the EC2
 * Instance Metadata Service
 */

var fromInstanceMetadata = function (init) {
  if (init === void 0) {
    init = {};
  } // when set to true, metadata service will not fetch token


  var disableFetchToken = false;

  var _a = providerConfigFromInit(init),
      timeout = _a.timeout,
      maxRetries = _a.maxRetries;

  var getCredentials = function (maxRetries, options) {
    return __awaiter$1(void 0, void 0, void 0, function () {
      var profile;
      return __generator$1(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4
            /*yield*/
            , retry(function () {
              return __awaiter$1(void 0, void 0, void 0, function () {
                var profile, err_1;
                return __generator$1(this, function (_a) {
                  switch (_a.label) {
                    case 0:
                      _a.trys.push([0, 2,, 3]);

                      return [4
                      /*yield*/
                      , getProfile(options)];

                    case 1:
                      profile = _a.sent();
                      return [3
                      /*break*/
                      , 3];

                    case 2:
                      err_1 = _a.sent();

                      if (err_1.statusCode === 401) {
                        disableFetchToken = false;
                      }

                      throw err_1;

                    case 3:
                      return [2
                      /*return*/
                      , profile];
                  }
                });
              });
            }, maxRetries)];

          case 1:
            profile = _a.sent().trim();
            return [2
            /*return*/
            , retry(function () {
              return __awaiter$1(void 0, void 0, void 0, function () {
                var creds, err_2;
                return __generator$1(this, function (_a) {
                  switch (_a.label) {
                    case 0:
                      _a.trys.push([0, 2,, 3]);

                      return [4
                      /*yield*/
                      , getCredentialsFromProfile(profile, options)];

                    case 1:
                      creds = _a.sent();
                      return [3
                      /*break*/
                      , 3];

                    case 2:
                      err_2 = _a.sent();

                      if (err_2.statusCode === 401) {
                        disableFetchToken = false;
                      }

                      throw err_2;

                    case 3:
                      return [2
                      /*return*/
                      , creds];
                  }
                });
              });
            }, maxRetries)];
        }
      });
    });
  };

  return function () {
    return __awaiter$1(void 0, void 0, void 0, function () {
      var token, error_1;
      return __generator$1(this, function (_a) {
        switch (_a.label) {
          case 0:
            if (!disableFetchToken) return [3
            /*break*/
            , 1];
            return [2
            /*return*/
            , getCredentials(maxRetries, {
              timeout: timeout
            })];

          case 1:
            token = void 0;
            _a.label = 2;

          case 2:
            _a.trys.push([2, 4,, 5]);

            return [4
            /*yield*/
            , getMetadataToken({
              timeout: timeout
            })];

          case 3:
            token = _a.sent().toString();
            return [3
            /*break*/
            , 5];

          case 4:
            error_1 = _a.sent();

            if ((error_1 === null || error_1 === void 0 ? void 0 : error_1.statusCode) === 400) {
              throw Object.assign(error_1, {
                message: "EC2 Metadata token request returned error"
              });
            } else if (error_1.message === "TimeoutError" || [403, 404, 405].includes(error_1.statusCode)) {
              disableFetchToken = true;
            }

            return [2
            /*return*/
            , getCredentials(maxRetries, {
              timeout: timeout
            })];

          case 5:
            return [2
            /*return*/
            , getCredentials(maxRetries, {
              timeout: timeout,
              headers: {
                "x-aws-ec2-metadata-token": token
              }
            })];
        }
      });
    });
  };
};

var getMetadataToken = function (options) {
  return __awaiter$1(void 0, void 0, void 0, function () {
    return __generator$1(this, function (_a) {
      return [2
      /*return*/
      , httpRequest(__assign$1(__assign$1({}, options), {
        host: IMDS_IP,
        path: IMDS_TOKEN_PATH,
        method: "PUT",
        headers: {
          "x-aws-ec2-metadata-token-ttl-seconds": "21600"
        }
      }))];
    });
  });
};

var getProfile = function (options) {
  return __awaiter$1(void 0, void 0, void 0, function () {
    return __generator$1(this, function (_a) {
      switch (_a.label) {
        case 0:
          return [4
          /*yield*/
          , httpRequest(__assign$1(__assign$1({}, options), {
            host: IMDS_IP,
            path: IMDS_PATH
          }))];

        case 1:
          return [2
          /*return*/
          , _a.sent().toString()];
      }
    });
  });
};

var getCredentialsFromProfile = function (profile, options) {
  return __awaiter$1(void 0, void 0, void 0, function () {
    var credsResponse, _a, _b;

    return __generator$1(this, function (_c) {
      switch (_c.label) {
        case 0:
          _b = (_a = JSON).parse;
          return [4
          /*yield*/
          , httpRequest(__assign$1(__assign$1({}, options), {
            host: IMDS_IP,
            path: IMDS_PATH + profile
          }))];

        case 1:
          credsResponse = _b.apply(_a, [_c.sent().toString()]);

          if (!isImdsCredentials(credsResponse)) {
            throw new ProviderError("Invalid response received from instance metadata service.");
          }

          return [2
          /*return*/
          , fromImdsCredentials(credsResponse)];
      }
    });
  });
};

var ENV_CREDENTIALS_PATH = "AWS_SHARED_CREDENTIALS_FILE";
var ENV_CONFIG_PATH = "AWS_CONFIG_FILE";

var swallowError = function () {
  return {};
};

var loadSharedConfigFiles = function (init) {
  if (init === void 0) {
    init = {};
  }

  var _a = init.filepath,
      filepath = _a === void 0 ? process.env[ENV_CREDENTIALS_PATH] || require$$1.join(getHomeDir(), ".aws", "credentials") : _a,
      _b = init.configFilepath,
      configFilepath = _b === void 0 ? process.env[ENV_CONFIG_PATH] || require$$1.join(getHomeDir(), ".aws", "config") : _b;
  return Promise.all([slurpFile(configFilepath).then(parseIni).then(normalizeConfigFile).catch(swallowError), slurpFile(filepath).then(parseIni).catch(swallowError)]).then(function (parsedFiles) {
    var _a = __read(parsedFiles, 2),
        configFile = _a[0],
        credentialsFile = _a[1];

    return {
      configFile: configFile,
      credentialsFile: credentialsFile
    };
  });
};
var profileKeyRegex = /^profile\s(["'])?([^\1]+)\1$/;

var normalizeConfigFile = function (data) {
  var e_1, _a;

  var map = {};

  try {
    for (var _b = __values(Object.keys(data)), _c = _b.next(); !_c.done; _c = _b.next()) {
      var key = _c.value;
      var matches = void 0;

      if (key === "default") {
        map.default = data.default;
      } else if (matches = profileKeyRegex.exec(key)) {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        var _d = __read(matches, 3),
            _1 = _d[0],
            _2 = _d[1],
            normalizedKey = _d[2];

        if (normalizedKey) {
          map[normalizedKey] = data[key];
        }
      }
    }
  } catch (e_1_1) {
    e_1 = {
      error: e_1_1
    };
  } finally {
    try {
      if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
    } finally {
      if (e_1) throw e_1.error;
    }
  }

  return map;
};

var profileNameBlockList = ["__proto__", "profile __proto__"];

var parseIni = function (iniData) {
  var e_2, _a;

  var map = {};
  var currentSection;

  try {
    for (var _b = __values(iniData.split(/\r?\n/)), _c = _b.next(); !_c.done; _c = _b.next()) {
      var line = _c.value;
      line = line.split(/(^|\s)[;#]/)[0]; // remove comments

      var section = line.match(/^\s*\[([^\[\]]+)]\s*$/);

      if (section) {
        currentSection = section[1];

        if (profileNameBlockList.includes(currentSection)) {
          throw new Error("Found invalid profile name \"" + currentSection + "\"");
        }
      } else if (currentSection) {
        var item = line.match(/^\s*(.+?)\s*=\s*(.+?)\s*$/);

        if (item) {
          map[currentSection] = map[currentSection] || {};
          map[currentSection][item[1]] = item[2];
        }
      }
    }
  } catch (e_2_1) {
    e_2 = {
      error: e_2_1
    };
  } finally {
    try {
      if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
    } finally {
      if (e_2) throw e_2.error;
    }
  }

  return map;
};

var slurpFile = function (path) {
  return new Promise(function (resolve, reject) {
    require$$2.readFile(path, "utf8", function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

var getHomeDir = function () {
  var _a = process.env,
      HOME = _a.HOME,
      USERPROFILE = _a.USERPROFILE,
      HOMEPATH = _a.HOMEPATH,
      _b = _a.HOMEDRIVE,
      HOMEDRIVE = _b === void 0 ? "C:" + require$$1.sep : _b;
  if (HOME) return HOME;
  if (USERPROFILE) return USERPROFILE;
  if (HOMEPATH) return "" + HOMEDRIVE + HOMEPATH;
  return os.homedir();
};

var DEFAULT_PROFILE = "default";
var ENV_PROFILE = "AWS_PROFILE";

var isStaticCredsProfile = function (arg) {
  return Boolean(arg) && typeof arg === "object" && typeof arg.aws_access_key_id === "string" && typeof arg.aws_secret_access_key === "string" && ["undefined", "string"].indexOf(typeof arg.aws_session_token) > -1;
};

var isAssumeRoleProfile = function (arg) {
  return Boolean(arg) && typeof arg === "object" && typeof arg.role_arn === "string" && typeof arg.source_profile === "string" && ["undefined", "string"].indexOf(typeof arg.role_session_name) > -1 && ["undefined", "string"].indexOf(typeof arg.external_id) > -1 && ["undefined", "string"].indexOf(typeof arg.mfa_serial) > -1;
};
/**
 * Creates a credential provider that will read from ini files and supports
 * role assumption and multi-factor authentication.
 */


var fromIni = function (init) {
  if (init === void 0) {
    init = {};
  }

  return function () {
    return __awaiter$1(void 0, void 0, void 0, function () {
      var profiles;
      return __generator$1(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4
            /*yield*/
            , parseKnownFiles(init)];

          case 1:
            profiles = _a.sent();
            return [2
            /*return*/
            , resolveProfileData(getMasterProfileName(init), profiles, init)];
        }
      });
    });
  };
};
/**
 * Load profiles from credentials and config INI files and normalize them into a
 * single profile list.
 *
 * @internal
 */

var parseKnownFiles = function (init) {
  return __awaiter$1(void 0, void 0, void 0, function () {
    var _a, loadedConfig, parsedFiles;

    return __generator$1(this, function (_b) {
      switch (_b.label) {
        case 0:
          _a = init.loadedConfig, loadedConfig = _a === void 0 ? loadSharedConfigFiles(init) : _a;
          return [4
          /*yield*/
          , loadedConfig];

        case 1:
          parsedFiles = _b.sent();
          return [2
          /*return*/
          , __assign$1(__assign$1({}, parsedFiles.configFile), parsedFiles.credentialsFile)];
      }
    });
  });
};
/**
 * @internal
 */

var getMasterProfileName = function (init) {
  return init.profile || process.env[ENV_PROFILE] || DEFAULT_PROFILE;
};

var resolveProfileData = function (profileName, profiles, options, visitedProfiles) {
  if (visitedProfiles === void 0) {
    visitedProfiles = {};
  }

  return __awaiter$1(void 0, void 0, void 0, function () {
    var data, ExternalId, mfa_serial, RoleArn, _a, RoleSessionName, source_profile, sourceCreds, params, _b, _c, _d;

    var _e;

    return __generator$1(this, function (_f) {
      switch (_f.label) {
        case 0:
          data = profiles[profileName]; // If this is not the first profile visited, static credentials should be
          // preferred over role assumption metadata. This special treatment of
          // second and subsequent hops is to ensure compatibility with the AWS CLI.

          if (Object.keys(visitedProfiles).length > 0 && isStaticCredsProfile(data)) {
            return [2
            /*return*/
            , resolveStaticCredentials(data)];
          }

          if (!isAssumeRoleProfile(data)) return [3
          /*break*/
          , 4];
          ExternalId = data.external_id, mfa_serial = data.mfa_serial, RoleArn = data.role_arn, _a = data.role_session_name, RoleSessionName = _a === void 0 ? "aws-sdk-js-" + Date.now() : _a, source_profile = data.source_profile;

          if (!options.roleAssumer) {
            throw new ProviderError("Profile " + profileName + " requires a role to be assumed, but no" + " role assumption callback was provided.", false);
          }

          if (source_profile in visitedProfiles) {
            throw new ProviderError("Detected a cycle attempting to resolve credentials for profile" + (" " + getMasterProfileName(options) + ". Profiles visited: ") + Object.keys(visitedProfiles).join(", "), false);
          }

          sourceCreds = resolveProfileData(source_profile, profiles, options, __assign$1(__assign$1({}, visitedProfiles), (_e = {}, _e[source_profile] = true, _e)));
          params = {
            RoleArn: RoleArn,
            RoleSessionName: RoleSessionName,
            ExternalId: ExternalId
          };
          if (!mfa_serial) return [3
          /*break*/
          , 2];

          if (!options.mfaCodeProvider) {
            throw new ProviderError("Profile " + profileName + " requires multi-factor authentication," + " but no MFA code callback was provided.", false);
          }

          params.SerialNumber = mfa_serial;
          _b = params;
          return [4
          /*yield*/
          , options.mfaCodeProvider(mfa_serial)];

        case 1:
          _b.TokenCode = _f.sent();
          _f.label = 2;

        case 2:
          _d = (_c = options).roleAssumer;
          return [4
          /*yield*/
          , sourceCreds];

        case 3:
          return [2
          /*return*/
          , _d.apply(_c, [_f.sent(), params])];

        case 4:
          // If no role assumption metadata is present, attempt to load static
          // credentials from the selected profile.
          if (isStaticCredsProfile(data)) {
            return [2
            /*return*/
            , resolveStaticCredentials(data)];
          } // If the profile cannot be parsed or contains neither static credentials
          // nor role assumption metadata, throw an error. This should be considered a
          // terminal resolution error if a profile has been specified by the user
          // (whether via a parameter, an environment variable, or another profile's
          // `source_profile` key).


          throw new ProviderError("Profile " + profileName + " could not be found or parsed in shared" + " credentials file.");
      }
    });
  });
};

var resolveStaticCredentials = function (profile) {
  return Promise.resolve({
    accessKeyId: profile.aws_access_key_id,
    secretAccessKey: profile.aws_secret_access_key,
    sessionToken: profile.aws_session_token
  });
};

/**
 * Creates a credential provider that will read from a credential_process specified
 * in ini files.
 */

var fromProcess = function (init) {
  if (init === void 0) {
    init = {};
  }

  return function () {
    return __awaiter$1(void 0, void 0, void 0, function () {
      var profiles;
      return __generator$1(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4
            /*yield*/
            , parseKnownFiles(init)];

          case 1:
            profiles = _a.sent();
            return [2
            /*return*/
            , resolveProcessCredentials(getMasterProfileName(init), profiles)];
        }
      });
    });
  };
};

var resolveProcessCredentials = function (profileName, profiles) {
  return __awaiter$1(void 0, void 0, void 0, function () {
    var profile, credentialProcess;
    return __generator$1(this, function (_a) {
      switch (_a.label) {
        case 0:
          profile = profiles[profileName];
          if (!profiles[profileName]) return [3
          /*break*/
          , 4];
          credentialProcess = profile["credential_process"];
          if (!(credentialProcess !== undefined)) return [3
          /*break*/
          , 2];
          return [4
          /*yield*/
          , execPromise(credentialProcess).then(function (processResult) {
            var data;

            try {
              data = JSON.parse(processResult);
            } catch (_a) {
              throw Error("Profile " + profileName + " credential_process returned invalid JSON.");
            }

            var version = data.Version,
                accessKeyId = data.AccessKeyId,
                secretAccessKey = data.SecretAccessKey,
                sessionToken = data.SessionToken,
                expiration = data.Expiration;

            if (version !== 1) {
              throw Error("Profile " + profileName + " credential_process did not return Version 1.");
            }

            if (accessKeyId === undefined || secretAccessKey === undefined) {
              throw Error("Profile " + profileName + " credential_process returned invalid credentials.");
            }

            var expirationUnix;

            if (expiration) {
              var currentTime = new Date();
              var expireTime = new Date(expiration);

              if (expireTime < currentTime) {
                throw Error("Profile " + profileName + " credential_process returned expired credentials.");
              }

              expirationUnix = Math.floor(new Date(expiration).valueOf() / 1000);
            }

            return {
              accessKeyId: accessKeyId,
              secretAccessKey: secretAccessKey,
              sessionToken: sessionToken,
              expirationUnix: expirationUnix
            };
          }).catch(function (error) {
            throw new ProviderError(error.message);
          })];

        case 1:
          return [2
          /*return*/
          , _a.sent()];

        case 2:
          throw new ProviderError("Profile " + profileName + " did not contain credential_process.");

        case 3:
          return [3
          /*break*/
          , 5];

        case 4:
          // If the profile cannot be parsed or does not contain the default or
          // specified profile throw an error. This should be considered a terminal
          // resolution error if a profile has been specified by the user (whether via
          // a parameter, anenvironment variable, or another profile's `source_profile` key).
          throw new ProviderError("Profile " + profileName + " could not be found in shared credentials file.");

        case 5:
          return [2
          /*return*/
          ];
      }
    });
  });
};

var execPromise = function (command) {
  return new Promise(function (resolve, reject) {
    child_process.exec(command, function (error, stdout) {
      if (error) {
        reject(error);
        return;
      }

      resolve(stdout.trim());
    });
  });
};

var ENV_IMDS_DISABLED = "AWS_EC2_METADATA_DISABLED";
/**
 * Creates a credential provider that will attempt to find credentials from the
 * following sources (listed in order of precedence):
 *   * Environment variables exposed via `process.env`
 *   * Shared credentials and config ini files
 *   * The EC2/ECS Instance Metadata Service
 *
 * The default credential provider will invoke one provider at a time and only
 * continue to the next if no credentials have been located. For example, if
 * the process finds values defined via the `AWS_ACCESS_KEY_ID` and
 * `AWS_SECRET_ACCESS_KEY` environment variables, the files at
 * `~/.aws/credentials` and `~/.aws/config` will not be read, nor will any
 * messages be sent to the Instance Metadata Service.
 *
 * @param init                  Configuration that is passed to each individual
 *                              provider
 *
 * @see fromEnv                 The function used to source credentials from
 *                              environment variables
 * @see fromIni                 The function used to source credentials from INI
 *                              files
 * @see fromProcess             The function used to sources credentials from
 *                              credential_process in INI files
 * @see fromInstanceMetadata    The function used to source credentials from the
 *                              EC2 Instance Metadata Service
 * @see fromContainerMetadata   The function used to source credentials from the
 *                              ECS Container Metadata Service
 */

var defaultProvider = function (init) {
  if (init === void 0) {
    init = {};
  }

  var options = __assign$1({
    profile: process.env[ENV_PROFILE]
  }, init);

  if (!options.loadedConfig) options.loadedConfig = loadSharedConfigFiles(init);
  var providers = [fromIni(options), fromProcess(options), remoteProvider(options)];
  if (!options.profile) providers.unshift(fromEnv());
  var providerChain = chain.apply(void 0, __spread(providers));
  return memoize(providerChain, function (credentials) {
    return credentials.expiration !== undefined && credentials.expiration.getTime() - Date.now() < 300000;
  }, function (credentials) {
    return credentials.expiration !== undefined;
  });
};

var remoteProvider = function (init) {
  if (process.env[ENV_CMDS_RELATIVE_URI] || process.env[ENV_CMDS_FULL_URI]) {
    return fromContainerMetadata(init);
  }

  if (process.env[ENV_IMDS_DISABLED]) {
    return function () {
      return Promise.reject(new ProviderError("EC2 Instance Metadata Service access disabled"));
    };
  }

  return fromInstanceMetadata(init);
};

var tslib_1 = /*@__PURE__*/getAugmentedNamespace(tslib_es6);

var build = createCommonjsModule(function (module, exports) {

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Crc32 = exports.crc32 = void 0;

  function crc32(data) {
    return new Crc32().update(data).digest();
  }

  exports.crc32 = crc32;

  var Crc32 =
  /** @class */
  function () {
    function Crc32() {
      this.checksum = 0xffffffff;
    }

    Crc32.prototype.update = function (data) {
      var e_1, _a;

      try {
        for (var data_1 = tslib_1.__values(data), data_1_1 = data_1.next(); !data_1_1.done; data_1_1 = data_1.next()) {
          var byte = data_1_1.value;
          this.checksum = this.checksum >>> 8 ^ lookupTable[(this.checksum ^ byte) & 0xff];
        }
      } catch (e_1_1) {
        e_1 = {
          error: e_1_1
        };
      } finally {
        try {
          if (data_1_1 && !data_1_1.done && (_a = data_1.return)) _a.call(data_1);
        } finally {
          if (e_1) throw e_1.error;
        }
      }

      return this;
    };

    Crc32.prototype.digest = function () {
      return (this.checksum ^ 0xffffffff) >>> 0;
    };

    return Crc32;
  }();

  exports.Crc32 = Crc32; // prettier-ignore

  var lookupTable = Uint32Array.from([0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA, 0x076DC419, 0x706AF48F, 0xE963A535, 0x9E6495A3, 0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97D2D988, 0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91, 0x1DB71064, 0x6AB020F2, 0xF3B97148, 0x84BE41DE, 0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7, 0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC, 0x14015C4F, 0x63066CD9, 0xFA0F3D63, 0x8D080DF5, 0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172, 0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B, 0x35B5A8FA, 0x42B2986C, 0xDBBBC9D6, 0xACBCF940, 0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59, 0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116, 0x21B4F4B5, 0x56B3C423, 0xCFBA9599, 0xB8BDA50F, 0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924, 0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D, 0x76DC4190, 0x01DB7106, 0x98D220BC, 0xEFD5102A, 0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433, 0x7807C9A2, 0x0F00F934, 0x9609A88E, 0xE10E9818, 0x7F6A0DBB, 0x086D3D2D, 0x91646C97, 0xE6635C01, 0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E, 0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457, 0x65B0D9C6, 0x12B7E950, 0x8BBEB8EA, 0xFCB9887C, 0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65, 0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2, 0x4ADFA541, 0x3DD895D7, 0xA4D1C46D, 0xD3D6F4FB, 0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0, 0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9, 0x5005713C, 0x270241AA, 0xBE0B1010, 0xC90C2086, 0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F, 0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4, 0x59B33D17, 0x2EB40D81, 0xB7BD5C3B, 0xC0BA6CAD, 0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A, 0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683, 0xE3630B12, 0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8, 0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1, 0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE, 0xF762575D, 0x806567CB, 0x196C3671, 0x6E6B06E7, 0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC, 0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5, 0xD6D6A3E8, 0xA1D1937E, 0x38D8C2C4, 0x4FDFF252, 0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B, 0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60, 0xDF60EFC3, 0xA867DF55, 0x316E8EEF, 0x4669BE79, 0xCB61B38C, 0xBC66831A, 0x256FD2A0, 0x5268E236, 0xCC0C7795, 0xBB0B4703, 0x220216B9, 0x5505262F, 0xC5BA3BBE, 0xB2BD0B28, 0x2BB45A92, 0x5CB36A04, 0xC2D7FFA7, 0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D, 0x9B64C2B0, 0xEC63F226, 0x756AA39C, 0x026D930A, 0x9C0906A9, 0xEB0E363F, 0x72076785, 0x05005713, 0x95BF4A82, 0xE2B87A14, 0x7BB12BAE, 0x0CB61B38, 0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7, 0x0BDBDF21, 0x86D3D2D4, 0xF1D4E242, 0x68DDB3F8, 0x1FDA836E, 0x81BE16CD, 0xF6B9265B, 0x6FB077E1, 0x18B74777, 0x88085AE6, 0xFF0F6A70, 0x66063BCA, 0x11010B5C, 0x8F659EFF, 0xF862AE69, 0x616BFFD3, 0x166CCF45, 0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2, 0xA7672661, 0xD06016F7, 0x4969474D, 0x3E6E77DB, 0xAED16A4A, 0xD9D65ADC, 0x40DF0B66, 0x37D83BF0, 0xA9BCAE53, 0xDEBB9EC5, 0x47B2CF7F, 0x30B5FFE9, 0xBDBDF21C, 0xCABAC28A, 0x53B39330, 0x24B4A3A6, 0xBAD03605, 0xCDD70693, 0x54DE5729, 0x23D967BF, 0xB3667A2E, 0xC4614AB8, 0x5D681B02, 0x2A6F2B94, 0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D]);
});

var SHORT_TO_HEX = {};
var HEX_TO_SHORT = {};

for (var i = 0; i < 256; i++) {
  var encodedByte = i.toString(16).toLowerCase();

  if (encodedByte.length === 1) {
    encodedByte = "0" + encodedByte;
  }

  SHORT_TO_HEX[i] = encodedByte;
  HEX_TO_SHORT[encodedByte] = i;
}
/**
 * Converts a hexadecimal encoded string to a Uint8Array of bytes.
 *
 * @param encoded The hexadecimal encoded string
 */


function fromHex(encoded) {
  if (encoded.length % 2 !== 0) {
    throw new Error("Hex encoded strings must have an even number length");
  }

  var out = new Uint8Array(encoded.length / 2);

  for (var i = 0; i < encoded.length; i += 2) {
    var encodedByte = encoded.substr(i, 2).toLowerCase();

    if (encodedByte in HEX_TO_SHORT) {
      out[i / 2] = HEX_TO_SHORT[encodedByte];
    } else {
      throw new Error("Cannot decode unrecognized sequence " + encodedByte + " as hexadecimal");
    }
  }

  return out;
}
/**
 * Converts a Uint8Array of binary data to a hexadecimal encoded string.
 *
 * @param bytes The binary data to encode
 */

function toHex(bytes) {
  var out = "";

  for (var i = 0; i < bytes.byteLength; i++) {
    out += SHORT_TO_HEX[bytes[i]];
  }

  return out;
}

/**
 * A lossless representation of a signed, 64-bit integer. Instances of this
 * class may be used in arithmetic expressions as if they were numeric
 * primitives, but the binary representation will be preserved unchanged as the
 * `bytes` property of the object. The bytes should be encoded as big-endian,
 * two's complement integers.
 */

var Int64 =
/** @class */
function () {
  function Int64(bytes) {
    this.bytes = bytes;

    if (bytes.byteLength !== 8) {
      throw new Error("Int64 buffers must be exactly 8 bytes");
    }
  }

  Int64.fromNumber = function (number) {
    if (number > 9223372036854775807 || number < -9223372036854775808) {
      throw new Error(number + " is too large (or, if negative, too small) to represent as an Int64");
    }

    var bytes = new Uint8Array(8);

    for (var i = 7, remaining = Math.abs(Math.round(number)); i > -1 && remaining > 0; i--, remaining /= 256) {
      bytes[i] = remaining;
    }

    if (number < 0) {
      negate(bytes);
    }

    return new Int64(bytes);
  };
  /**
   * Called implicitly by infix arithmetic operators.
   */


  Int64.prototype.valueOf = function () {
    var bytes = this.bytes.slice(0);
    var negative = bytes[0] & 128;

    if (negative) {
      negate(bytes);
    }

    return parseInt(toHex(bytes), 16) * (negative ? -1 : 1);
  };

  Int64.prototype.toString = function () {
    return String(this.valueOf());
  };

  return Int64;
}();

function negate(bytes) {
  for (var i = 0; i < 8; i++) {
    bytes[i] ^= 0xff;
  }

  for (var i = 7; i > -1; i--) {
    bytes[i]++;
    if (bytes[i] !== 0) break;
  }
}

/**
 * @internal
 */

var HeaderMarshaller =
/** @class */
function () {
  function HeaderMarshaller(toUtf8, fromUtf8) {
    this.toUtf8 = toUtf8;
    this.fromUtf8 = fromUtf8;
  }

  HeaderMarshaller.prototype.format = function (headers) {
    var e_1, _a, e_2, _b;

    var chunks = [];

    try {
      for (var _c = __values(Object.keys(headers)), _d = _c.next(); !_d.done; _d = _c.next()) {
        var headerName = _d.value;
        var bytes = this.fromUtf8(headerName);
        chunks.push(Uint8Array.from([bytes.byteLength]), bytes, this.formatHeaderValue(headers[headerName]));
      }
    } catch (e_1_1) {
      e_1 = {
        error: e_1_1
      };
    } finally {
      try {
        if (_d && !_d.done && (_a = _c.return)) _a.call(_c);
      } finally {
        if (e_1) throw e_1.error;
      }
    }

    var out = new Uint8Array(chunks.reduce(function (carry, bytes) {
      return carry + bytes.byteLength;
    }, 0));
    var position = 0;

    try {
      for (var chunks_1 = __values(chunks), chunks_1_1 = chunks_1.next(); !chunks_1_1.done; chunks_1_1 = chunks_1.next()) {
        var chunk = chunks_1_1.value;
        out.set(chunk, position);
        position += chunk.byteLength;
      }
    } catch (e_2_1) {
      e_2 = {
        error: e_2_1
      };
    } finally {
      try {
        if (chunks_1_1 && !chunks_1_1.done && (_b = chunks_1.return)) _b.call(chunks_1);
      } finally {
        if (e_2) throw e_2.error;
      }
    }

    return out;
  };

  HeaderMarshaller.prototype.formatHeaderValue = function (header) {
    switch (header.type) {
      case "boolean":
        return Uint8Array.from([header.value ? 0
        /* boolTrue */
        : 1
        /* boolFalse */
        ]);

      case "byte":
        return Uint8Array.from([2
        /* byte */
        , header.value]);

      case "short":
        var shortView = new DataView(new ArrayBuffer(3));
        shortView.setUint8(0, 3
        /* short */
        );
        shortView.setInt16(1, header.value, false);
        return new Uint8Array(shortView.buffer);

      case "integer":
        var intView = new DataView(new ArrayBuffer(5));
        intView.setUint8(0, 4
        /* integer */
        );
        intView.setInt32(1, header.value, false);
        return new Uint8Array(intView.buffer);

      case "long":
        var longBytes = new Uint8Array(9);
        longBytes[0] = 5
        /* long */
        ;
        longBytes.set(header.value.bytes, 1);
        return longBytes;

      case "binary":
        var binView = new DataView(new ArrayBuffer(3 + header.value.byteLength));
        binView.setUint8(0, 6
        /* byteArray */
        );
        binView.setUint16(1, header.value.byteLength, false);
        var binBytes = new Uint8Array(binView.buffer);
        binBytes.set(header.value, 3);
        return binBytes;

      case "string":
        var utf8Bytes = this.fromUtf8(header.value);
        var strView = new DataView(new ArrayBuffer(3 + utf8Bytes.byteLength));
        strView.setUint8(0, 7
        /* string */
        );
        strView.setUint16(1, utf8Bytes.byteLength, false);
        var strBytes = new Uint8Array(strView.buffer);
        strBytes.set(utf8Bytes, 3);
        return strBytes;

      case "timestamp":
        var tsBytes = new Uint8Array(9);
        tsBytes[0] = 8
        /* timestamp */
        ;
        tsBytes.set(Int64.fromNumber(header.value.valueOf()).bytes, 1);
        return tsBytes;

      case "uuid":
        if (!UUID_PATTERN.test(header.value)) {
          throw new Error("Invalid UUID received: " + header.value);
        }

        var uuidBytes = new Uint8Array(17);
        uuidBytes[0] = 9
        /* uuid */
        ;
        uuidBytes.set(fromHex(header.value.replace(/\-/g, "")), 1);
        return uuidBytes;
    }
  };

  HeaderMarshaller.prototype.parse = function (headers) {
    var out = {};
    var position = 0;

    while (position < headers.byteLength) {
      var nameLength = headers.getUint8(position++);
      var name = this.toUtf8(new Uint8Array(headers.buffer, headers.byteOffset + position, nameLength));
      position += nameLength;

      switch (headers.getUint8(position++)) {
        case 0
        /* boolTrue */
        :
          out[name] = {
            type: BOOLEAN_TAG,
            value: true
          };
          break;

        case 1
        /* boolFalse */
        :
          out[name] = {
            type: BOOLEAN_TAG,
            value: false
          };
          break;

        case 2
        /* byte */
        :
          out[name] = {
            type: BYTE_TAG,
            value: headers.getInt8(position++)
          };
          break;

        case 3
        /* short */
        :
          out[name] = {
            type: SHORT_TAG,
            value: headers.getInt16(position, false)
          };
          position += 2;
          break;

        case 4
        /* integer */
        :
          out[name] = {
            type: INT_TAG,
            value: headers.getInt32(position, false)
          };
          position += 4;
          break;

        case 5
        /* long */
        :
          out[name] = {
            type: LONG_TAG,
            value: new Int64(new Uint8Array(headers.buffer, headers.byteOffset + position, 8))
          };
          position += 8;
          break;

        case 6
        /* byteArray */
        :
          var binaryLength = headers.getUint16(position, false);
          position += 2;
          out[name] = {
            type: BINARY_TAG,
            value: new Uint8Array(headers.buffer, headers.byteOffset + position, binaryLength)
          };
          position += binaryLength;
          break;

        case 7
        /* string */
        :
          var stringLength = headers.getUint16(position, false);
          position += 2;
          out[name] = {
            type: STRING_TAG,
            value: this.toUtf8(new Uint8Array(headers.buffer, headers.byteOffset + position, stringLength))
          };
          position += stringLength;
          break;

        case 8
        /* timestamp */
        :
          out[name] = {
            type: TIMESTAMP_TAG,
            value: new Date(new Int64(new Uint8Array(headers.buffer, headers.byteOffset + position, 8)).valueOf())
          };
          position += 8;
          break;

        case 9
        /* uuid */
        :
          var uuidBytes = new Uint8Array(headers.buffer, headers.byteOffset + position, 16);
          position += 16;
          out[name] = {
            type: UUID_TAG,
            value: toHex(uuidBytes.subarray(0, 4)) + "-" + toHex(uuidBytes.subarray(4, 6)) + "-" + toHex(uuidBytes.subarray(6, 8)) + "-" + toHex(uuidBytes.subarray(8, 10)) + "-" + toHex(uuidBytes.subarray(10))
          };
          break;

        default:
          throw new Error("Unrecognized header type tag");
      }
    }

    return out;
  };

  return HeaderMarshaller;
}();
var HEADER_VALUE_TYPE;

(function (HEADER_VALUE_TYPE) {
  HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["boolTrue"] = 0] = "boolTrue";
  HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["boolFalse"] = 1] = "boolFalse";
  HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["byte"] = 2] = "byte";
  HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["short"] = 3] = "short";
  HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["integer"] = 4] = "integer";
  HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["long"] = 5] = "long";
  HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["byteArray"] = 6] = "byteArray";
  HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["string"] = 7] = "string";
  HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["timestamp"] = 8] = "timestamp";
  HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["uuid"] = 9] = "uuid";
})(HEADER_VALUE_TYPE || (HEADER_VALUE_TYPE = {}));

var BOOLEAN_TAG = "boolean";
var BYTE_TAG = "byte";
var SHORT_TAG = "short";
var INT_TAG = "integer";
var LONG_TAG = "long";
var BINARY_TAG = "binary";
var STRING_TAG = "string";
var TIMESTAMP_TAG = "timestamp";
var UUID_TAG = "uuid";
var UUID_PATTERN = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;

var PRELUDE_MEMBER_LENGTH = 4; // The prelude consists of two components

var PRELUDE_LENGTH = PRELUDE_MEMBER_LENGTH * 2; // Checksums are always CRC32 hashes.

var CHECKSUM_LENGTH = 4; // Messages must include a full prelude, a prelude checksum, and a message checksum

var MINIMUM_MESSAGE_LENGTH = PRELUDE_LENGTH + CHECKSUM_LENGTH * 2;
/**
 * @internal
 */

function splitMessage(_a) {
  var byteLength = _a.byteLength,
      byteOffset = _a.byteOffset,
      buffer = _a.buffer;

  if (byteLength < MINIMUM_MESSAGE_LENGTH) {
    throw new Error("Provided message too short to accommodate event stream message overhead");
  }

  var view = new DataView(buffer, byteOffset, byteLength);
  var messageLength = view.getUint32(0, false);

  if (byteLength !== messageLength) {
    throw new Error("Reported message length does not match received message length");
  }

  var headerLength = view.getUint32(PRELUDE_MEMBER_LENGTH, false);
  var expectedPreludeChecksum = view.getUint32(PRELUDE_LENGTH, false);
  var expectedMessageChecksum = view.getUint32(byteLength - CHECKSUM_LENGTH, false);
  var checksummer = new build.Crc32().update(new Uint8Array(buffer, byteOffset, PRELUDE_LENGTH));

  if (expectedPreludeChecksum !== checksummer.digest()) {
    throw new Error("The prelude checksum specified in the message (" + expectedPreludeChecksum + ") does not match the calculated CRC32 checksum (" + checksummer.digest() + ")");
  }

  checksummer.update(new Uint8Array(buffer, byteOffset + PRELUDE_LENGTH, byteLength - (PRELUDE_LENGTH + CHECKSUM_LENGTH)));

  if (expectedMessageChecksum !== checksummer.digest()) {
    throw new Error("The message checksum (" + checksummer.digest() + ") did not match the expected value of " + expectedMessageChecksum);
  }

  return {
    headers: new DataView(buffer, byteOffset + PRELUDE_LENGTH + CHECKSUM_LENGTH, headerLength),
    body: new Uint8Array(buffer, byteOffset + PRELUDE_LENGTH + CHECKSUM_LENGTH + headerLength, messageLength - headerLength - (PRELUDE_LENGTH + CHECKSUM_LENGTH + CHECKSUM_LENGTH))
  };
}

/**
 * A marshaller that can convert binary-packed event stream messages into
 * JavaScript objects and back again into their binary format.
 */

var EventStreamMarshaller =
/** @class */
function () {
  function EventStreamMarshaller(toUtf8, fromUtf8) {
    this.headerMarshaller = new HeaderMarshaller(toUtf8, fromUtf8);
  }
  /**
   * Convert a structured JavaScript object with tagged headers into a binary
   * event stream message.
   */


  EventStreamMarshaller.prototype.marshall = function (_a) {
    var rawHeaders = _a.headers,
        body = _a.body;
    var headers = this.headerMarshaller.format(rawHeaders);
    var length = headers.byteLength + body.byteLength + 16;
    var out = new Uint8Array(length);
    var view = new DataView(out.buffer, out.byteOffset, out.byteLength);
    var checksum = new build.Crc32(); // Format message

    view.setUint32(0, length, false);
    view.setUint32(4, headers.byteLength, false);
    view.setUint32(8, checksum.update(out.subarray(0, 8)).digest(), false);
    out.set(headers, 12);
    out.set(body, headers.byteLength + 12); // Write trailing message checksum

    view.setUint32(length - 4, checksum.update(out.subarray(8, length - 4)).digest(), false);
    return out;
  };
  /**
   * Convert a binary event stream message into a JavaScript object with an
   * opaque, binary body and tagged, parsed headers.
   */


  EventStreamMarshaller.prototype.unmarshall = function (message) {
    var _a = splitMessage(message),
        headers = _a.headers,
        body = _a.body;

    return {
      headers: this.headerMarshaller.parse(headers),
      body: body
    };
  };
  /**
   * Convert a structured JavaScript object with tagged headers into a binary
   * event stream message header.
   */


  EventStreamMarshaller.prototype.formatHeaders = function (rawHeaders) {
    return this.headerMarshaller.format(rawHeaders);
  };

  return EventStreamMarshaller;
}();

function getChunkedStream(source) {
  var _a;

  var currentMessageTotalLength = 0;
  var currentMessagePendingLength = 0;
  var currentMessage = null;
  var messageLengthBuffer = null;

  var allocateMessage = function (size) {
    if (typeof size !== "number") {
      throw new Error("Attempted to allocate an event message where size was not a number: " + size);
    }

    currentMessageTotalLength = size;
    currentMessagePendingLength = 4;
    currentMessage = new Uint8Array(size);
    var currentMessageView = new DataView(currentMessage.buffer);
    currentMessageView.setUint32(0, size, false); //set big-endian Uint32 to 0~3 bytes
  };

  var iterator = function () {
    return __asyncGenerator(this, arguments, function () {
      var sourceIterator, _a, value, done, chunkLength, currentOffset, bytesRemaining, numBytesForTotal, numBytesToWrite;

      return __generator$1(this, function (_b) {
        switch (_b.label) {
          case 0:
            sourceIterator = source[Symbol.asyncIterator]();
            _b.label = 1;

          case 1:
            return [4
            /*yield*/
            , __await(sourceIterator.next())];

          case 2:
            _a = _b.sent(), value = _a.value, done = _a.done;
            if (!done) return [3
            /*break*/
            , 10];
            if (!!currentMessageTotalLength) return [3
            /*break*/
            , 4];
            return [4
            /*yield*/
            , __await(void 0)];

          case 3:
            return [2
            /*return*/
            , _b.sent()];

          case 4:
            if (!(currentMessageTotalLength === currentMessagePendingLength)) return [3
            /*break*/
            , 7];
            return [4
            /*yield*/
            , __await(currentMessage)];

          case 5:
            return [4
            /*yield*/
            , _b.sent()];

          case 6:
            _b.sent();

            return [3
            /*break*/
            , 8];

          case 7:
            throw new Error("Truncated event message received.");

          case 8:
            return [4
            /*yield*/
            , __await(void 0)];

          case 9:
            return [2
            /*return*/
            , _b.sent()];

          case 10:
            chunkLength = value.length;
            currentOffset = 0;
            _b.label = 11;

          case 11:
            if (!(currentOffset < chunkLength)) return [3
            /*break*/
            , 15]; // create new message if necessary

            if (!currentMessage) {
              bytesRemaining = chunkLength - currentOffset; // prevent edge case where total length spans 2 chunks

              if (!messageLengthBuffer) {
                messageLengthBuffer = new Uint8Array(4);
              }

              numBytesForTotal = Math.min(4 - currentMessagePendingLength, // remaining bytes to fill the messageLengthBuffer
              bytesRemaining // bytes left in chunk
              );
              messageLengthBuffer.set( // @ts-ignore error TS2532: Object is possibly 'undefined' for value
              value.slice(currentOffset, currentOffset + numBytesForTotal), currentMessagePendingLength);
              currentMessagePendingLength += numBytesForTotal;
              currentOffset += numBytesForTotal;

              if (currentMessagePendingLength < 4) {
                // not enough information to create the current message
                return [3
                /*break*/
                , 15];
              }

              allocateMessage(new DataView(messageLengthBuffer.buffer).getUint32(0, false));
              messageLengthBuffer = null;
            }

            numBytesToWrite = Math.min(currentMessageTotalLength - currentMessagePendingLength, // number of bytes left to complete message
            chunkLength - currentOffset // number of bytes left in the original chunk
            );
            currentMessage.set( // @ts-ignore error TS2532: Object is possibly 'undefined' for value
            value.slice(currentOffset, currentOffset + numBytesToWrite), currentMessagePendingLength);
            currentMessagePendingLength += numBytesToWrite;
            currentOffset += numBytesToWrite;
            if (!(currentMessageTotalLength && currentMessageTotalLength === currentMessagePendingLength)) return [3
            /*break*/
            , 14];
            return [4
            /*yield*/
            , __await(currentMessage)];

          case 12:
            // push out the message
            return [4
            /*yield*/
            , _b.sent()];

          case 13:
            // push out the message
            _b.sent(); // cleanup


            currentMessage = null;
            currentMessageTotalLength = 0;
            currentMessagePendingLength = 0;
            _b.label = 14;

          case 14:
            return [3
            /*break*/
            , 11];

          case 15:
            return [3
            /*break*/
            , 1];

          case 16:
            return [2
            /*return*/
            ];
        }
      });
    });
  };

  return _a = {}, _a[Symbol.asyncIterator] = iterator, _a;
}

function getUnmarshalledStream(source, options) {
  var _a;

  return _a = {}, _a[Symbol.asyncIterator] = function () {
    return __asyncGenerator(this, arguments, function () {
      var source_1, source_1_1, chunk, message, messageType, unmodeledError, code, exception, deserializedException, error, event, deserialized, e_1_1;

      var _a, _b;

      var e_1, _c;

      return __generator$1(this, function (_d) {
        switch (_d.label) {
          case 0:
            _d.trys.push([0, 12, 13, 18]);

            source_1 = __asyncValues(source);
            _d.label = 1;

          case 1:
            return [4
            /*yield*/
            , __await(source_1.next())];

          case 2:
            if (!(source_1_1 = _d.sent(), !source_1_1.done)) return [3
            /*break*/
            , 11];
            chunk = source_1_1.value;
            message = options.eventMarshaller.unmarshall(chunk);
            messageType = message.headers[":message-type"].value;
            if (!(messageType === "error")) return [3
            /*break*/
            , 3];
            unmodeledError = new Error(message.headers[":error-message"].value || "UnknownError");
            unmodeledError.name = message.headers[":error-code"].value;
            throw unmodeledError;

          case 3:
            if (!(messageType === "exception")) return [3
            /*break*/
            , 5];
            code = message.headers[":exception-type"].value;
            exception = (_a = {}, _a[code] = message, _a);
            return [4
            /*yield*/
            , __await(options.deserializer(exception))];

          case 4:
            deserializedException = _d.sent();

            if (deserializedException.$unknown) {
              error = new Error(options.toUtf8(message.body));
              error.name = code;
              throw error;
            }

            throw deserializedException[code];

          case 5:
            if (!(messageType === "event")) return [3
            /*break*/
            , 9];
            event = (_b = {}, _b[message.headers[":event-type"].value] = message, _b);
            return [4
            /*yield*/
            , __await(options.deserializer(event))];

          case 6:
            deserialized = _d.sent();
            if (deserialized.$unknown) return [3
            /*break*/
            , 10];
            return [4
            /*yield*/
            , __await(deserialized)];

          case 7:
            return [4
            /*yield*/
            , _d.sent()];

          case 8:
            _d.sent();

            return [3
            /*break*/
            , 10];

          case 9:
            throw Error("Unrecognizable event type: " + message.headers[":event-type"].value);

          case 10:
            return [3
            /*break*/
            , 1];

          case 11:
            return [3
            /*break*/
            , 18];

          case 12:
            e_1_1 = _d.sent();
            e_1 = {
              error: e_1_1
            };
            return [3
            /*break*/
            , 18];

          case 13:
            _d.trys.push([13,, 16, 17]);

            if (!(source_1_1 && !source_1_1.done && (_c = source_1.return))) return [3
            /*break*/
            , 15];
            return [4
            /*yield*/
            , __await(_c.call(source_1))];

          case 14:
            _d.sent();

            _d.label = 15;

          case 15:
            return [3
            /*break*/
            , 17];

          case 16:
            if (e_1) throw e_1.error;
            return [7
            /*endfinally*/
            ];

          case 17:
            return [7
            /*endfinally*/
            ];

          case 18:
            return [2
            /*return*/
            ];
        }
      });
    });
  }, _a;
}

var EventStreamMarshaller$1 =
/** @class */
function () {
  function EventStreamMarshaller$1(_a) {
    var utf8Encoder = _a.utf8Encoder,
        utf8Decoder = _a.utf8Decoder;
    this.eventMarshaller = new EventStreamMarshaller(utf8Encoder, utf8Decoder);
    this.utfEncoder = utf8Encoder;
  }

  EventStreamMarshaller$1.prototype.deserialize = function (body, deserializer) {
    var chunkedStream = getChunkedStream(body);
    var unmarshalledStream = getUnmarshalledStream(chunkedStream, {
      eventMarshaller: this.eventMarshaller,
      deserializer: deserializer,
      toUtf8: this.utfEncoder
    });
    return unmarshalledStream;
  };

  EventStreamMarshaller$1.prototype.serialize = function (input, serializer) {
    var _a; // eslint-disable-next-line @typescript-eslint/no-this-alias


    var self = this;

    var serializedIterator = function () {
      return __asyncGenerator(this, arguments, function () {
        var input_1, input_1_1, chunk, payloadBuf, e_1_1;

        var e_1, _a;

        return __generator$1(this, function (_b) {
          switch (_b.label) {
            case 0:
              _b.trys.push([0, 7, 8, 13]);

              input_1 = __asyncValues(input);
              _b.label = 1;

            case 1:
              return [4
              /*yield*/
              , __await(input_1.next())];

            case 2:
              if (!(input_1_1 = _b.sent(), !input_1_1.done)) return [3
              /*break*/
              , 6];
              chunk = input_1_1.value;
              payloadBuf = self.eventMarshaller.marshall(serializer(chunk));
              return [4
              /*yield*/
              , __await(payloadBuf)];

            case 3:
              return [4
              /*yield*/
              , _b.sent()];

            case 4:
              _b.sent();

              _b.label = 5;

            case 5:
              return [3
              /*break*/
              , 1];

            case 6:
              return [3
              /*break*/
              , 13];

            case 7:
              e_1_1 = _b.sent();
              e_1 = {
                error: e_1_1
              };
              return [3
              /*break*/
              , 13];

            case 8:
              _b.trys.push([8,, 11, 12]);

              if (!(input_1_1 && !input_1_1.done && (_a = input_1.return))) return [3
              /*break*/
              , 10];
              return [4
              /*yield*/
              , __await(_a.call(input_1))];

            case 9:
              _b.sent();

              _b.label = 10;

            case 10:
              return [3
              /*break*/
              , 12];

            case 11:
              if (e_1) throw e_1.error;
              return [7
              /*endfinally*/
              ];

            case 12:
              return [7
              /*endfinally*/
              ];

            case 13:
              return [4
              /*yield*/
              , __await(new Uint8Array(0))];

            case 14:
              // Ending frame
              return [4
              /*yield*/
              , _b.sent()];

            case 15:
              // Ending frame
              _b.sent();

              return [2
              /*return*/
              ];
          }
        });
      });
    };

    return _a = {}, _a[Symbol.asyncIterator] = serializedIterator, _a;
  };

  return EventStreamMarshaller$1;
}();

/**
 * Convert object stream piped in into an async iterable. This
 * daptor should be deprecated when Node stream iterator is stable.
 * Caveat: this adaptor won't have backpressure to inwards stream
 *
 * Reference: https://nodejs.org/docs/latest-v11.x/api/stream.html#stream_readable_symbol_asynciterator
 */

function readabletoIterable(readStream) {
  return __asyncGenerator(this, arguments, function readabletoIterable_1() {
    var streamEnded, generationEnded, records, value;
    return __generator$1(this, function (_a) {
      switch (_a.label) {
        case 0:
          streamEnded = false;
          generationEnded = false;
          records = new Array();
          readStream.on("error", function (err) {
            if (!streamEnded) {
              streamEnded = true;
            }

            if (err) {
              throw err;
            }
          });
          readStream.on("data", function (data) {
            records.push(data);
          });
          readStream.on("end", function () {
            streamEnded = true;
          });
          _a.label = 1;

        case 1:
          if (!!generationEnded) return [3
          /*break*/
          , 6];
          return [4
          /*yield*/
          , __await(new Promise(function (resolve) {
            return setTimeout(function () {
              return resolve(records.shift());
            }, 0);
          }))];

        case 2:
          value = _a.sent();
          if (!value) return [3
          /*break*/
          , 5];
          return [4
          /*yield*/
          , __await(value)];

        case 3:
          return [4
          /*yield*/
          , _a.sent()];

        case 4:
          _a.sent();

          _a.label = 5;

        case 5:
          generationEnded = streamEnded && records.length === 0;
          return [3
          /*break*/
          , 1];

        case 6:
          return [2
          /*return*/
          ];
      }
    });
  });
}

var EventStreamMarshaller$2 =
/** @class */
function () {
  function EventStreamMarshaller$2(_a) {
    var utf8Encoder = _a.utf8Encoder,
        utf8Decoder = _a.utf8Decoder;
    this.eventMarshaller = new EventStreamMarshaller(utf8Encoder, utf8Decoder);
    this.universalMarshaller = new EventStreamMarshaller$1({
      utf8Decoder: utf8Decoder,
      utf8Encoder: utf8Encoder
    });
  }

  EventStreamMarshaller$2.prototype.deserialize = function (body, deserializer) {
    //should use stream[Symbol.asyncIterable] when the api is stable
    //reference: https://nodejs.org/docs/latest-v11.x/api/stream.html#stream_readable_symbol_asynciterator
    var bodyIterable = typeof body[Symbol.asyncIterator] === "function" ? body : readabletoIterable(body);
    return this.universalMarshaller.deserialize(bodyIterable, deserializer);
  };

  EventStreamMarshaller$2.prototype.serialize = function (input, serializer) {
    var serializedIterable = this.universalMarshaller.serialize(input, serializer);

    if (typeof stream.Readable.from === "function") {
      //reference: https://nodejs.org/dist/latest-v13.x/docs/api/stream.html#stream_new_stream_readable_options
      return stream.Readable.from(serializedIterable);
    } else {
      var iterator_1 = serializedIterable[Symbol.asyncIterator]();
      var serializedStream_1 = new stream.Readable({
        autoDestroy: true,
        objectMode: true,
        read: function () {
          return __awaiter$1(this, void 0, void 0, function () {
            var _this = this;

            return __generator$1(this, function (_a) {
              iterator_1.next().then(function (_a) {
                var done = _a.done,
                    value = _a.value;

                if (done) {
                  _this.push(null);
                } else {
                  _this.push(value);
                }
              }).catch(function (err) {
                _this.destroy(err);
              });
              return [2
              /*return*/
              ];
            });
          });
        }
      }); //TODO: use 'autoDestroy' when targeting Node 11

      serializedStream_1.on("error", function () {
        serializedStream_1.destroy();
      });
      serializedStream_1.on("end", function () {
        serializedStream_1.destroy();
      });
      return serializedStream_1;
    }
  };

  return EventStreamMarshaller$2;
}();

/** NodeJS event stream utils provider */

var eventStreamSerdeProvider = function (options) {
  return new EventStreamMarshaller$2(options);
};

var isArrayBuffer$1 = function (arg) {
  return typeof ArrayBuffer === "function" && arg instanceof ArrayBuffer || Object.prototype.toString.call(arg) === "[object ArrayBuffer]";
};

var fromArrayBuffer$1 = function (input, offset, length) {
  if (offset === void 0) {
    offset = 0;
  }

  if (length === void 0) {
    length = input.byteLength - offset;
  }

  if (!isArrayBuffer$1(input)) {
    throw new TypeError("The \"input\" argument must be ArrayBuffer. Received type " + typeof input + " (" + input + ")");
  }

  return buffer.Buffer.from(input, offset, length);
};
var fromString$1 = function (input, encoding) {
  if (typeof input !== "string") {
    throw new TypeError("The \"input\" argument must be of type string. Received type " + typeof input + " (" + input + ")");
  }

  return encoding ? buffer.Buffer.from(input, encoding) : buffer.Buffer.from(input);
};

var Hash =
/** @class */
function () {
  function Hash(algorithmIdentifier, secret) {
    this.hash = secret ? crypto.createHmac(algorithmIdentifier, castSourceData(secret)) : crypto.createHash(algorithmIdentifier);
  }

  Hash.prototype.update = function (toHash, encoding) {
    this.hash.update(castSourceData(toHash, encoding));
  };

  Hash.prototype.digest = function () {
    return Promise.resolve(this.hash.digest());
  };

  return Hash;
}();

function castSourceData(toCast, encoding) {
  if (buffer.Buffer.isBuffer(toCast)) {
    return toCast;
  }

  if (typeof toCast === "string") {
    return fromString$1(toCast, encoding);
  }

  if (ArrayBuffer.isView(toCast)) {
    return fromArrayBuffer$1(toCast.buffer, toCast.byteOffset, toCast.byteLength);
  }

  return fromArrayBuffer$1(toCast);
}

var HashCalculator =
/** @class */
function (_super) {
  __extends$1(HashCalculator, _super);

  function HashCalculator(hash, options) {
    var _this = _super.call(this, options) || this;

    _this.hash = hash;
    return _this;
  }

  HashCalculator.prototype._write = function (chunk, encoding, callback) {
    try {
      this.hash.update(chunk);
    } catch (err) {
      return callback(err);
    }

    callback();
  };

  return HashCalculator;
}(stream.Writable);

var fileStreamHasher = function fileStreamHasher(hashCtor, fileStream) {
  return new Promise(function (resolve, reject) {
    if (!isReadStream(fileStream)) {
      reject(new Error("Unable to calculate hash for non-file streams."));
      return;
    }

    var fileStreamTee = require$$2.createReadStream(fileStream.path, {
      start: fileStream.start,
      end: fileStream.end
    });
    var hash = new hashCtor();
    var hashCalculator = new HashCalculator(hash);
    fileStreamTee.pipe(hashCalculator);
    fileStreamTee.on("error", function (err) {
      // if the source errors, the destination stream needs to manually end
      hashCalculator.end();
      reject(err);
    });
    hashCalculator.on("error", reject);
    hashCalculator.on("finish", function () {
      hash.digest().then(resolve).catch(reject);
    });
  });
};

function isReadStream(stream) {
  return typeof stream.path === "string";
}

var HttpResponse =
/** @class */
function () {
  function HttpResponse(options) {
    this.statusCode = options.statusCode;
    this.headers = options.headers || {};
    this.body = options.body;
  }

  HttpResponse.isInstance = function (response) {
    //determine if response is a valid HttpResponse
    if (!response) return false;
    var resp = response;
    return typeof resp.statusCode === "number" && typeof resp.headers === "object";
  };

  return HttpResponse;
}();

var HttpRequest =
/** @class */
function () {
  function HttpRequest(options) {
    this.method = options.method || "GET";
    this.hostname = options.hostname || "localhost";
    this.port = options.port;
    this.query = options.query || {};
    this.headers = options.headers || {};
    this.body = options.body;
    this.protocol = options.protocol ? options.protocol.substr(-1) !== ":" ? options.protocol + ":" : options.protocol : "https:";
    this.path = options.path ? options.path.charAt(0) !== "/" ? "/" + options.path : options.path : "/";
  }

  HttpRequest.isInstance = function (request) {
    //determine if request is a valid httpRequest
    if (!request) return false;
    var req = request;
    return "method" in req && "protocol" in req && "hostname" in req && "path" in req && typeof req["query"] === "object" && typeof req["headers"] === "object";
  };

  HttpRequest.prototype.clone = function () {
    var cloned = new HttpRequest(__assign$1(__assign$1({}, this), {
      headers: __assign$1({}, this.headers)
    }));
    if (cloned.query) cloned.query = cloneQuery(cloned.query);
    return cloned;
  };

  return HttpRequest;
}();

function cloneQuery(query) {
  return Object.keys(query).reduce(function (carry, paramName) {
    var _a;

    var param = query[paramName];
    return __assign$1(__assign$1({}, carry), (_a = {}, _a[paramName] = Array.isArray(param) ? __spread(param) : param, _a));
  }, {});
}

/**
 * Validate whether a string is an ARN.
 */

var validate = function (str) {
  return typeof str === "string" && str.indexOf("arn:") === 0 && str.split(":").length >= 6;
};
/**
 * Parse an ARN string into structure with partition, service, region, accountId and resource values
 */

var parse = function (arn) {
  var segments = arn.split(":");
  if (segments.length < 6 || segments[0] !== "arn") throw new Error("Malformed ARN");

  var _a = __read(segments),
      //Skip "arn" literal
  partition = _a[1],
      service = _a[2],
      region = _a[3],
      accountId = _a[4],
      resource = _a.slice(5);

  return {
    partition: partition,
    service: service,
    region: region,
    accountId: accountId,
    resource: resource.join(":")
  };
};

var DOMAIN_PATTERN = /^[a-z0-9][a-z0-9\.\-]{1,61}[a-z0-9]$/;
var IP_ADDRESS_PATTERN = /(\d+\.){3}\d+/;
var DOTS_PATTERN = /\.\./;
var DOT_PATTERN = /\./;
var S3_HOSTNAME_PATTERN = /^(.+\.)?s3[.-]([a-z0-9-]+)\./;
var S3_US_EAST_1_ALTNAME_PATTERN = /^s3(-external-1)?\.amazonaws\.com$/;
var AWS_PARTITION_SUFFIX = "amazonaws.com";
var isBucketNameOptions = function (options) {
  return typeof options.bucketName === "string";
};
/**
 * Get pseudo region from supplied region. For example, if supplied with `fips-us-west-2`, it returns `us-west-2`.
 * @internal
 */

var getPseudoRegion = function (region) {
  return isFipsRegion(region) ? region.replace(/fips-|-fips/, "") : region;
};
/**
 * Determines whether a given string is DNS compliant per the rules outlined by
 * S3. Length, capitaization, and leading dot restrictions are enforced by the
 * DOMAIN_PATTERN regular expression.
 * @internal
 *
 * @see https://docs.aws.amazon.com/AmazonS3/latest/dev/BucketRestrictions.html
 */

var isDnsCompatibleBucketName = function (bucketName) {
  return DOMAIN_PATTERN.test(bucketName) && !IP_ADDRESS_PATTERN.test(bucketName) && !DOTS_PATTERN.test(bucketName);
};

var getRegionalSuffix = function (hostname) {
  var parts = hostname.match(S3_HOSTNAME_PATTERN);
  return [parts[2], hostname.replace(new RegExp("^" + parts[0]), "")];
};

var getSuffix = function (hostname) {
  return S3_US_EAST_1_ALTNAME_PATTERN.test(hostname) ? ["us-east-1", AWS_PARTITION_SUFFIX] : getRegionalSuffix(hostname);
};
/**
 * Infer region and hostname suffix from a complete hostname
 * @internal
 * @param hostname - Hostname
 * @returns [Region, Hostname suffix]
 */

var getSuffixForArnEndpoint = function (hostname) {
  return S3_US_EAST_1_ALTNAME_PATTERN.test(hostname) ? [hostname.replace("." + AWS_PARTITION_SUFFIX, ""), AWS_PARTITION_SUFFIX] : getRegionalSuffix(hostname);
};
var validateArnEndpointOptions = function (options) {
  if (options.pathStyleEndpoint) {
    throw new Error("Path-style S3 endpoint is not supported when bucket is an ARN");
  }

  if (options.accelerateEndpoint) {
    throw new Error("Accelerate endpoint is not supported when bucket is an ARN");
  }

  if (!options.tlsCompatible) {
    throw new Error("HTTPS is required when bucket is an ARN");
  }
};
var validateService = function (service) {
  if (service !== "s3" && service !== "s3-outposts") {
    throw new Error("Expect 's3' or 's3-outposts' in ARN service component");
  }
};
var validateS3Service = function (service) {
  if (service !== "s3") {
    throw new Error("Expect 's3' in Accesspoint ARN service component");
  }
};
var validateOutpostService = function (service) {
  if (service !== "s3-outposts") {
    throw new Error("Expect 's3-posts' in Outpost ARN service component");
  }
};
/**
 * Validate partition inferred from ARN is the same to `options.clientPartition`.
 * @internal
 */

var validatePartition = function (partition, options) {
  if (partition !== options.clientPartition) {
    throw new Error("Partition in ARN is incompatible, got \"" + partition + "\" but expected \"" + options.clientPartition + "\"");
  }
};
/**
 * validate region value inferred from ARN. If `options.useArnRegion` is set, it validates the region is not a FIPS
 * region. If `options.useArnRegion` is unset, it validates the region is equal to `options.clientRegion` or
 * `options.clientSigningRegion`.
 * @internal
 */

var validateRegion = function (region, options) {
  if (region === "") {
    throw new Error("ARN region is empty");
  }

  if (!options.useArnRegion && !isEqualRegions(region, options.clientRegion) && !isEqualRegions(region, options.clientSigningRegion)) {
    throw new Error("Region in ARN is incompatible, got " + region + " but expected " + options.clientRegion);
  }

  if (options.useArnRegion && isFipsRegion(region)) {
    throw new Error("Endpoint does not support FIPS region");
  }
};

var isFipsRegion = function (region) {
  return region.startsWith("fips-") || region.endsWith("-fips");
};

var isEqualRegions = function (regionA, regionB) {
  return regionA === regionB || getPseudoRegion(regionA) === regionB || regionA === getPseudoRegion(regionB);
};
/**
 * Validate an account ID
 * @internal
 */


var validateAccountId = function (accountId) {
  if (!/[0-9]{12}/.exec(accountId)) {
    throw new Error("Access point ARN accountID does not match regex '[0-9]{12}'");
  }
};
/**
 * Validate a host label according to https://tools.ietf.org/html/rfc3986#section-3.2.2
 * @internal
 */

var validateDNSHostLabel = function (label, options) {
  if (options === void 0) {
    options = {
      tlsCompatible: true
    };
  } // reference: https://tools.ietf.org/html/rfc3986#section-3.2.2


  if (label.length >= 64 || !/^[a-z0-9][a-z0-9.-]+[a-z0-9]$/.test(label) || /(\d+\.){3}\d+/.test(label) || /[.-]{2}/.test(label) || (options === null || options === void 0 ? void 0 : options.tlsCompatible) && DOT_PATTERN.test(label)) {
    throw new Error("Invalid DNS label " + label);
  }
};
/**
 * Validate and parse an Access Point ARN or Outposts ARN
 * @internal
 *
 * @param resource - The resource section of an ARN
 * @returns Access Point Name and optional Outpost ID.
 */

var getArnResources = function (resource) {
  var delimiter = resource.includes(":") ? ":" : "/";

  var _a = __read(resource.split(delimiter)),
      resourceType = _a[0],
      rest = _a.slice(1);

  if (resourceType === "accesspoint") {
    // Parse accesspoint ARN
    if (rest.length !== 1 || rest[0] === "") {
      throw new Error("Access Point ARN should have one resource accesspoint" + delimiter + "{accesspointname}");
    }

    return {
      accesspointName: rest[0]
    };
  } else if (resourceType === "outpost") {
    // Parse outpost ARN
    if (!rest[0] || rest[1] !== "accesspoint" || !rest[2] || rest.length !== 3) {
      throw new Error("Outpost ARN should have resource outpost" + delimiter + "{outpostId}" + delimiter + "accesspoint" + delimiter + "{accesspointName}");
    }

    var _b = __read(rest, 3),
        outpostId = _b[0];
        _b[1];
        var accesspointName = _b[2];

    return {
      outpostId: outpostId,
      accesspointName: accesspointName
    };
  } else {
    throw new Error("ARN resource should begin with 'accesspoint" + delimiter + "' or 'outpost" + delimiter + "'");
  }
};
/**
 * Throw if dual stack configuration is set to true.
 * @internal
 */

var validateNoDualstack = function (dualstackEndpoint) {
  if (dualstackEndpoint) throw new Error("Dualstack endpoint is not supported with Outpost");
};
/**
 * Validate region is not appended or prepended with a `fips-`
 * @internal
 */

var validateNoFIPS = function (region) {
  if (isFipsRegion(region !== null && region !== void 0 ? region : "")) throw new Error("FIPS region is not supported with Outpost, got " + region);
};

var bucketHostname = function (options) {
  var isCustomEndpoint = options.isCustomEndpoint;
      options.baseHostname;
      var dualstackEndpoint = options.dualstackEndpoint,
      accelerateEndpoint = options.accelerateEndpoint;

  if (isCustomEndpoint) {
    if (dualstackEndpoint) throw new Error("Dualstack endpoint is not supported with custom endpoint");
    if (accelerateEndpoint) throw new Error("Accelerate endpoint is not supported with custom endpoint");
  }

  return isBucketNameOptions(options) ? // Construct endpoint when bucketName is a string referring to a bucket name
  getEndpointFromBucketName(__assign$1(__assign$1({}, options), {
    isCustomEndpoint: isCustomEndpoint
  })) : // Construct endpoint when bucketName is an ARN referring to an S3 resource like Access Point
  getEndpointFromArn(__assign$1(__assign$1({}, options), {
    isCustomEndpoint: isCustomEndpoint
  }));
};

var getEndpointFromArn = function (options) {
  var isCustomEndpoint = options.isCustomEndpoint,
      baseHostname = options.baseHostname;

  var _a = __read(isCustomEndpoint ? [options.clientRegion, baseHostname] : // Infer client region and hostname suffix from hostname from endpoints.json, like `s3.us-west-2.amazonaws.com`
  getSuffixForArnEndpoint(baseHostname), 2),
      clientRegion = _a[0],
      hostnameSuffix = _a[1];

  var pathStyleEndpoint = options.pathStyleEndpoint,
      _b = options.dualstackEndpoint,
      dualstackEndpoint = _b === void 0 ? false : _b,
      _c = options.accelerateEndpoint,
      accelerateEndpoint = _c === void 0 ? false : _c,
      _d = options.tlsCompatible,
      tlsCompatible = _d === void 0 ? true : _d,
      useArnRegion = options.useArnRegion,
      bucketName = options.bucketName,
      _e = options.clientPartition,
      clientPartition = _e === void 0 ? "aws" : _e,
      _f = options.clientSigningRegion,
      clientSigningRegion = _f === void 0 ? clientRegion : _f;
  validateArnEndpointOptions({
    pathStyleEndpoint: pathStyleEndpoint,
    accelerateEndpoint: accelerateEndpoint,
    tlsCompatible: tlsCompatible
  }); // Validate and parse the ARN supplied as a bucket name

  var service = bucketName.service,
      partition = bucketName.partition,
      accountId = bucketName.accountId,
      region = bucketName.region,
      resource = bucketName.resource;
  validateService(service);
  validatePartition(partition, {
    clientPartition: clientPartition
  });
  validateAccountId(accountId);
  validateRegion(region, {
    useArnRegion: useArnRegion,
    clientRegion: clientRegion,
    clientSigningRegion: clientSigningRegion
  });

  var _g = getArnResources(resource),
      accesspointName = _g.accesspointName,
      outpostId = _g.outpostId;

  validateDNSHostLabel(accesspointName + "-" + accountId, {
    tlsCompatible: tlsCompatible
  });
  var endpointRegion = useArnRegion ? region : clientRegion;
  var signingRegion = useArnRegion ? region : clientSigningRegion;

  if (outpostId) {
    // if this is an Outpost ARN
    validateOutpostService(service);
    validateDNSHostLabel(outpostId, {
      tlsCompatible: tlsCompatible
    });
    validateNoDualstack(dualstackEndpoint);
    validateNoFIPS(endpointRegion);
    var hostnamePrefix_1 = accesspointName + "-" + accountId + "." + outpostId;
    return {
      bucketEndpoint: true,
      hostname: "" + hostnamePrefix_1 + (isCustomEndpoint ? "" : ".s3-outposts." + endpointRegion) + "." + hostnameSuffix,
      signingRegion: signingRegion,
      signingService: "s3-outposts"
    };
  } // construct endpoint from Accesspoint ARN


  validateS3Service(service);
  var hostnamePrefix = accesspointName + "-" + accountId;
  return {
    bucketEndpoint: true,
    hostname: "" + hostnamePrefix + (isCustomEndpoint ? "" : ".s3-accesspoint" + (dualstackEndpoint ? ".dualstack" : "") + "." + endpointRegion) + "." + hostnameSuffix,
    signingRegion: signingRegion
  };
};

var getEndpointFromBucketName = function (_a) {
  var _b = _a.accelerateEndpoint,
      accelerateEndpoint = _b === void 0 ? false : _b,
      region = _a.clientRegion,
      baseHostname = _a.baseHostname,
      bucketName = _a.bucketName,
      _c = _a.dualstackEndpoint,
      dualstackEndpoint = _c === void 0 ? false : _c,
      _d = _a.pathStyleEndpoint,
      pathStyleEndpoint = _d === void 0 ? false : _d,
      _e = _a.tlsCompatible,
      tlsCompatible = _e === void 0 ? true : _e,
      _f = _a.isCustomEndpoint,
      isCustomEndpoint = _f === void 0 ? false : _f;

  var _g = __read(isCustomEndpoint ? [region, baseHostname] : getSuffix(baseHostname), 2),
      clientRegion = _g[0],
      hostnameSuffix = _g[1];

  if (pathStyleEndpoint || !isDnsCompatibleBucketName(bucketName) || tlsCompatible && DOT_PATTERN.test(bucketName)) {
    return {
      bucketEndpoint: false,
      hostname: dualstackEndpoint ? "s3.dualstack." + clientRegion + "." + hostnameSuffix : baseHostname
    };
  }

  if (accelerateEndpoint) {
    baseHostname = "s3-accelerate" + (dualstackEndpoint ? ".dualstack" : "") + "." + hostnameSuffix;
  } else if (dualstackEndpoint) {
    baseHostname = "s3.dualstack." + clientRegion + "." + hostnameSuffix;
  }

  return {
    bucketEndpoint: true,
    hostname: bucketName + "." + baseHostname
  };
};

var bucketEndpointMiddleware = function (options) {
  return function (next, context) {
    return function (args) {
      return __awaiter$1(void 0, void 0, void 0, function () {
        var bucketName, replaceBucketInPath, request, bucketArn, clientRegion, _a, _b, partition, _c, signingRegion, useArnRegion, _d, hostname, bucketEndpoint, modifiedSigningRegion, signingService, clientRegion, _e, _f, hostname, bucketEndpoint;

        return __generator$1(this, function (_g) {
          switch (_g.label) {
            case 0:
              bucketName = args.input.Bucket;
              replaceBucketInPath = options.bucketEndpoint;
              request = args.request;
              if (!HttpRequest.isInstance(request)) return [3
              /*break*/
              , 8];
              if (!options.bucketEndpoint) return [3
              /*break*/
              , 1];
              request.hostname = bucketName;
              return [3
              /*break*/
              , 7];

            case 1:
              if (!validate(bucketName)) return [3
              /*break*/
              , 5];
              bucketArn = parse(bucketName);
              _a = getPseudoRegion;
              return [4
              /*yield*/
              , options.region()];

            case 2:
              clientRegion = _a.apply(void 0, [_g.sent()]);
              return [4
              /*yield*/
              , options.regionInfoProvider(clientRegion)];

            case 3:
              _b = _g.sent() || {}, partition = _b.partition, _c = _b.signingRegion, signingRegion = _c === void 0 ? clientRegion : _c;
              return [4
              /*yield*/
              , options.useArnRegion()];

            case 4:
              useArnRegion = _g.sent();
              _d = bucketHostname({
                bucketName: bucketArn,
                baseHostname: request.hostname,
                accelerateEndpoint: options.useAccelerateEndpoint,
                dualstackEndpoint: options.useDualstackEndpoint,
                pathStyleEndpoint: options.forcePathStyle,
                tlsCompatible: request.protocol === "https:",
                useArnRegion: useArnRegion,
                clientPartition: partition,
                clientSigningRegion: signingRegion,
                clientRegion: clientRegion,
                isCustomEndpoint: options.isCustomEndpoint
              }), hostname = _d.hostname, bucketEndpoint = _d.bucketEndpoint, modifiedSigningRegion = _d.signingRegion, signingService = _d.signingService; // If the request needs to use a region or service name inferred from ARN that different from client region, we
              // need to set them in the handler context so the signer will use them

              if (modifiedSigningRegion && modifiedSigningRegion !== signingRegion) {
                context["signing_region"] = modifiedSigningRegion;
              }

              if (signingService && signingService !== "s3") {
                context["signing_service"] = signingService;
              }

              request.hostname = hostname;
              replaceBucketInPath = bucketEndpoint;
              return [3
              /*break*/
              , 7];

            case 5:
              _e = getPseudoRegion;
              return [4
              /*yield*/
              , options.region()];

            case 6:
              clientRegion = _e.apply(void 0, [_g.sent()]);
              _f = bucketHostname({
                bucketName: bucketName,
                clientRegion: clientRegion,
                baseHostname: request.hostname,
                accelerateEndpoint: options.useAccelerateEndpoint,
                dualstackEndpoint: options.useDualstackEndpoint,
                pathStyleEndpoint: options.forcePathStyle,
                tlsCompatible: request.protocol === "https:",
                isCustomEndpoint: options.isCustomEndpoint
              }), hostname = _f.hostname, bucketEndpoint = _f.bucketEndpoint;
              request.hostname = hostname;
              replaceBucketInPath = bucketEndpoint;
              _g.label = 7;

            case 7:
              if (replaceBucketInPath) {
                request.path = request.path.replace(/^(\/)?[^\/]+/, "");

                if (request.path === "") {
                  request.path = "/";
                }
              }

              _g.label = 8;

            case 8:
              return [2
              /*return*/
              , next(__assign$1(__assign$1({}, args), {
                request: request
              }))];
          }
        });
      });
    };
  };
};
var bucketEndpointMiddlewareOptions = {
  tags: ["BUCKET_ENDPOINT"],
  name: "bucketEndpointMiddleware",
  relation: "before",
  toMiddleware: "hostHeaderMiddleware",
  override: true
};
var getBucketEndpointPlugin = function (options) {
  return {
    applyToStack: function (clientStack) {
      clientStack.addRelativeTo(bucketEndpointMiddleware(options), bucketEndpointMiddlewareOptions);
    }
  };
};

function resolveBucketEndpointConfig(input) {
  var _a = input.bucketEndpoint,
      bucketEndpoint = _a === void 0 ? false : _a,
      _b = input.forcePathStyle,
      forcePathStyle = _b === void 0 ? false : _b,
      _c = input.useAccelerateEndpoint,
      useAccelerateEndpoint = _c === void 0 ? false : _c,
      _d = input.useDualstackEndpoint,
      useDualstackEndpoint = _d === void 0 ? false : _d,
      _e = input.useArnRegion,
      useArnRegion = _e === void 0 ? false : _e;
  return __assign$1(__assign$1({}, input), {
    bucketEndpoint: bucketEndpoint,
    forcePathStyle: forcePathStyle,
    useAccelerateEndpoint: useAccelerateEndpoint,
    useDualstackEndpoint: useDualstackEndpoint,
    useArnRegion: typeof useArnRegion === "function" ? useArnRegion : function () {
      return Promise.resolve(useArnRegion);
    }
  });
}
var NODE_USE_ARN_REGION_ENV_NAME = "AWS_S3_USE_ARN_REGION";
var NODE_USE_ARN_REGION_INI_NAME = "s3_use_arn_region";
/**
 * Config to load useArnRegion from environment variables and shared INI files
 *
 * @api private
 */

var NODE_USE_ARN_REGION_CONFIG_OPTIONS = {
  environmentVariableSelector: function (env) {
    if (!Object.prototype.hasOwnProperty.call(env, NODE_USE_ARN_REGION_ENV_NAME)) return undefined;
    if (env[NODE_USE_ARN_REGION_ENV_NAME] === "true") return true;
    if (env[NODE_USE_ARN_REGION_ENV_NAME] === "false") return false;
    throw new Error("Cannot load env " + NODE_USE_ARN_REGION_ENV_NAME + ". Expected \"true\" or \"false\", got " + env[NODE_USE_ARN_REGION_ENV_NAME] + ".");
  },
  configFileSelector: function (profile) {
    if (!Object.prototype.hasOwnProperty.call(profile, NODE_USE_ARN_REGION_INI_NAME)) return undefined;
    if (profile[NODE_USE_ARN_REGION_INI_NAME] === "true") return true;
    if (profile[NODE_USE_ARN_REGION_INI_NAME] === "false") return false;
    throw new Error("Cannot load shared config entry " + NODE_USE_ARN_REGION_INI_NAME + ". Expected \"true\" or \"false\", got " + profile[NODE_USE_ARN_REGION_INI_NAME] + ".");
  },
  default: false
};

var retryMiddleware = function (options) {
  return function (next, context) {
    return function (args) {
      return __awaiter$1(void 0, void 0, void 0, function () {
        var _a;

        return __generator$1(this, function (_b) {
          if ((_a = options === null || options === void 0 ? void 0 : options.retryStrategy) === null || _a === void 0 ? void 0 : _a.mode) context.userAgent = __spread(context.userAgent || [], [["cfg/retry-mode", options.retryStrategy.mode]]);
          return [2
          /*return*/
          , options.retryStrategy.retry(next, args)];
        });
      });
    };
  };
};
var retryMiddlewareOptions = {
  name: "retryMiddleware",
  tags: ["RETRY"],
  step: "finalizeRequest",
  priority: "high",
  override: true
};
var getRetryPlugin = function (options) {
  return {
    applyToStack: function (clientStack) {
      clientStack.add(retryMiddleware(options), retryMiddlewareOptions);
    }
  };
};

/**
 * The base number of milliseconds to use in calculating a suitable cool-down
 * time when a retryable error is encountered.
 */
var DEFAULT_RETRY_DELAY_BASE = 100;
/**
 * The maximum amount of time (in milliseconds) that will be used as a delay
 * between retry attempts.
 */

var MAXIMUM_RETRY_DELAY = 20 * 1000;
/**
 * The retry delay base (in milliseconds) to use when a throttling error is
 * encountered.
 */

var THROTTLING_RETRY_DELAY_BASE = 500;
/**
 * Initial number of retry tokens in Retry Quota
 */

var INITIAL_RETRY_TOKENS = 500;
/**
 * The total amount of retry tokens to be decremented from retry token balance.
 */

var RETRY_COST = 5;
/**
 * The total amount of retry tokens to be decremented from retry token balance
 * when a throttling error is encountered.
 */

var TIMEOUT_RETRY_COST = 10;
/**
 * The total amount of retry token to be incremented from retry token balance
 * if an SDK operation invocation succeeds without requiring a retry request.
 */

var NO_RETRY_INCREMENT = 1;
/**
 * Header name for SDK invocation ID
 */

var INVOCATION_ID_HEADER = "amz-sdk-invocation-id";
/**
 * Header name for request retry information.
 */

var REQUEST_HEADER = "amz-sdk-request";

/**
 * Errors encountered when the client clock and server clock cannot agree on the
 * current time.
 *
 * These errors are retryable, assuming the SDK has enabled clock skew
 * correction.
 */
var CLOCK_SKEW_ERROR_CODES = ["AuthFailure", "InvalidSignatureException", "RequestExpired", "RequestInTheFuture", "RequestTimeTooSkewed", "SignatureDoesNotMatch"];
/**
 * Errors that indicate the SDK is being throttled.
 *
 * These errors are always retryable.
 */

var THROTTLING_ERROR_CODES = ["BandwidthLimitExceeded", "EC2ThrottledException", "LimitExceededException", "PriorRequestNotComplete", "ProvisionedThroughputExceededException", "RequestLimitExceeded", "RequestThrottled", "RequestThrottledException", "SlowDown", "ThrottledException", "Throttling", "ThrottlingException", "TooManyRequestsException", "TransactionInProgressException"];
/**
 * Error codes that indicate transient issues
 */

var TRANSIENT_ERROR_CODES = ["AbortError", "TimeoutError", "RequestTimeout", "RequestTimeoutException"];
/**
 * Error codes that indicate transient issues
 */

var TRANSIENT_ERROR_STATUS_CODES = [500, 502, 503, 504];

var isRetryableByTrait = function (error) {
  return error.$retryable !== undefined;
};
var isClockSkewError = function (error) {
  return CLOCK_SKEW_ERROR_CODES.includes(error.name);
};
var isThrottlingError = function (error) {
  var _a, _b;

  return ((_a = error.$metadata) === null || _a === void 0 ? void 0 : _a.httpStatusCode) === 429 || THROTTLING_ERROR_CODES.includes(error.name) || ((_b = error.$retryable) === null || _b === void 0 ? void 0 : _b.throttling) == true;
};
var isTransientError = function (error) {
  var _a;

  return TRANSIENT_ERROR_CODES.includes(error.name) || TRANSIENT_ERROR_STATUS_CODES.includes(((_a = error.$metadata) === null || _a === void 0 ? void 0 : _a.httpStatusCode) || 0);
};

// this is pretty straight-forward - we use the crypto API.

var rng = function nodeRNG() {
  return crypto__default['default'].randomBytes(16);
};

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */
var byteToHex = [];

for (var i$1 = 0; i$1 < 256; ++i$1) {
  byteToHex[i$1] = (i$1 + 0x100).toString(16).substr(1);
}

function bytesToUuid(buf, offset) {
  var i = offset || 0;
  var bth = byteToHex; // join used to fix memory issue caused by concatenation: https://bugs.chromium.org/p/v8/issues/detail?id=3175#c4

  return [bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]]].join('');
}

var bytesToUuid_1 = bytesToUuid;

//
// Inspired by https://github.com/LiosK/UUID.js
// and http://docs.python.org/library/uuid.html

var _nodeId;

var _clockseq; // Previous uuid creation time


var _lastMSecs = 0;
var _lastNSecs = 0; // See https://github.com/uuidjs/uuid for API details

function v1(options, buf, offset) {
  var i = buf && offset || 0;
  var b = buf || [];
  options = options || {};
  var node = options.node || _nodeId;
  var clockseq = options.clockseq !== undefined ? options.clockseq : _clockseq; // node and clockseq need to be initialized to random values if they're not
  // specified.  We do this lazily to minimize issues related to insufficient
  // system entropy.  See #189

  if (node == null || clockseq == null) {
    var seedBytes = rng();

    if (node == null) {
      // Per 4.5, create and 48-bit node id, (47 random bits + multicast bit = 1)
      node = _nodeId = [seedBytes[0] | 0x01, seedBytes[1], seedBytes[2], seedBytes[3], seedBytes[4], seedBytes[5]];
    }

    if (clockseq == null) {
      // Per 4.2.2, randomize (14 bit) clockseq
      clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 0x3fff;
    }
  } // UUID timestamps are 100 nano-second units since the Gregorian epoch,
  // (1582-10-15 00:00).  JSNumbers aren't precise enough for this, so
  // time is handled internally as 'msecs' (integer milliseconds) and 'nsecs'
  // (100-nanoseconds offset from msecs) since unix epoch, 1970-01-01 00:00.


  var msecs = options.msecs !== undefined ? options.msecs : new Date().getTime(); // Per 4.2.1.2, use count of uuid's generated during the current clock
  // cycle to simulate higher resolution clock

  var nsecs = options.nsecs !== undefined ? options.nsecs : _lastNSecs + 1; // Time since last uuid creation (in msecs)

  var dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 10000; // Per 4.2.1.2, Bump clockseq on clock regression

  if (dt < 0 && options.clockseq === undefined) {
    clockseq = clockseq + 1 & 0x3fff;
  } // Reset nsecs if clock regresses (new clockseq) or we've moved onto a new
  // time interval


  if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === undefined) {
    nsecs = 0;
  } // Per 4.2.1.2 Throw error if too many uuids are requested


  if (nsecs >= 10000) {
    throw new Error('uuid.v1(): Can\'t create more than 10M uuids/sec');
  }

  _lastMSecs = msecs;
  _lastNSecs = nsecs;
  _clockseq = clockseq; // Per 4.1.4 - Convert from unix epoch to Gregorian epoch

  msecs += 12219292800000; // `time_low`

  var tl = ((msecs & 0xfffffff) * 10000 + nsecs) % 0x100000000;
  b[i++] = tl >>> 24 & 0xff;
  b[i++] = tl >>> 16 & 0xff;
  b[i++] = tl >>> 8 & 0xff;
  b[i++] = tl & 0xff; // `time_mid`

  var tmh = msecs / 0x100000000 * 10000 & 0xfffffff;
  b[i++] = tmh >>> 8 & 0xff;
  b[i++] = tmh & 0xff; // `time_high_and_version`

  b[i++] = tmh >>> 24 & 0xf | 0x10; // include version

  b[i++] = tmh >>> 16 & 0xff; // `clock_seq_hi_and_reserved` (Per 4.2.2 - include variant)

  b[i++] = clockseq >>> 8 | 0x80; // `clock_seq_low`

  b[i++] = clockseq & 0xff; // `node`

  for (var n = 0; n < 6; ++n) {
    b[i + n] = node[n];
  }

  return buf ? buf : bytesToUuid_1(b);
}

var v1_1 = v1;

function v4(options, buf, offset) {
  var i = buf && offset || 0;

  if (typeof options == 'string') {
    buf = options === 'binary' ? new Array(16) : null;
    options = null;
  }

  options = options || {};
  var rnds = options.random || (options.rng || rng)(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`

  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  if (buf) {
    for (var ii = 0; ii < 16; ++ii) {
      buf[i + ii] = rnds[ii];
    }
  }

  return buf || bytesToUuid_1(rnds);
}

var v4_1 = v4;

var uuid = v4_1;
uuid.v1 = v1_1;
uuid.v4 = v4_1;
var uuid_1 = uuid;

var getDefaultRetryQuota = function (initialRetryTokens) {
  var MAX_CAPACITY = initialRetryTokens;
  var availableCapacity = initialRetryTokens;

  var getCapacityAmount = function (error) {
    return error.name === "TimeoutError" ? TIMEOUT_RETRY_COST : RETRY_COST;
  };

  var hasRetryTokens = function (error) {
    return getCapacityAmount(error) <= availableCapacity;
  };

  var retrieveRetryTokens = function (error) {
    if (!hasRetryTokens(error)) {
      // retryStrategy should stop retrying, and return last error
      throw new Error("No retry token available");
    }

    var capacityAmount = getCapacityAmount(error);
    availableCapacity -= capacityAmount;
    return capacityAmount;
  };

  var releaseRetryTokens = function (capacityReleaseAmount) {
    availableCapacity += capacityReleaseAmount !== null && capacityReleaseAmount !== void 0 ? capacityReleaseAmount : NO_RETRY_INCREMENT;
    availableCapacity = Math.min(availableCapacity, MAX_CAPACITY);
  };

  return Object.freeze({
    hasRetryTokens: hasRetryTokens,
    retrieveRetryTokens: retrieveRetryTokens,
    releaseRetryTokens: releaseRetryTokens
  });
};

/**
 * Calculate a capped, fully-jittered exponential backoff time.
 */

var defaultDelayDecider = function (delayBase, attempts) {
  return Math.floor(Math.min(MAXIMUM_RETRY_DELAY, Math.random() * Math.pow(2, attempts) * delayBase));
};

var defaultRetryDecider = function (error) {
  if (!error) {
    return false;
  }

  return isRetryableByTrait(error) || isClockSkewError(error) || isThrottlingError(error) || isTransientError(error);
};

/**
 * The default value for how many HTTP requests an SDK should make for a
 * single SDK operation invocation before giving up
 */

var DEFAULT_MAX_ATTEMPTS = 3;
/**
 * The default retry algorithm to use.
 */

var DEFAULT_RETRY_MODE = "standard";

var StandardRetryStrategy =
/** @class */
function () {
  function StandardRetryStrategy(maxAttemptsProvider, options) {
    var _a, _b, _c;

    this.maxAttemptsProvider = maxAttemptsProvider;
    this.mode = DEFAULT_RETRY_MODE;
    this.retryDecider = (_a = options === null || options === void 0 ? void 0 : options.retryDecider) !== null && _a !== void 0 ? _a : defaultRetryDecider;
    this.delayDecider = (_b = options === null || options === void 0 ? void 0 : options.delayDecider) !== null && _b !== void 0 ? _b : defaultDelayDecider;
    this.retryQuota = (_c = options === null || options === void 0 ? void 0 : options.retryQuota) !== null && _c !== void 0 ? _c : getDefaultRetryQuota(INITIAL_RETRY_TOKENS);
  }

  StandardRetryStrategy.prototype.shouldRetry = function (error, attempts, maxAttempts) {
    return attempts < maxAttempts && this.retryDecider(error) && this.retryQuota.hasRetryTokens(error);
  };

  StandardRetryStrategy.prototype.getMaxAttempts = function () {
    return __awaiter$1(this, void 0, void 0, function () {
      var maxAttempts;
      return __generator$1(this, function (_a) {
        switch (_a.label) {
          case 0:
            _a.trys.push([0, 2,, 3]);

            return [4
            /*yield*/
            , this.maxAttemptsProvider()];

          case 1:
            maxAttempts = _a.sent();
            return [3
            /*break*/
            , 3];

          case 2:
            _a.sent();
            maxAttempts = DEFAULT_MAX_ATTEMPTS;
            return [3
            /*break*/
            , 3];

          case 3:
            return [2
            /*return*/
            , maxAttempts];
        }
      });
    });
  };

  StandardRetryStrategy.prototype.retry = function (next, args) {
    return __awaiter$1(this, void 0, void 0, function () {
      var retryTokenAmount, attempts, totalDelay, maxAttempts, request, _loop_1, this_1, state_1;

      return __generator$1(this, function (_a) {
        switch (_a.label) {
          case 0:
            attempts = 0;
            totalDelay = 0;
            return [4
            /*yield*/
            , this.getMaxAttempts()];

          case 1:
            maxAttempts = _a.sent();
            request = args.request;

            if (HttpRequest.isInstance(request)) {
              request.headers[INVOCATION_ID_HEADER] = uuid_1.v4();
            }

            _loop_1 = function () {
              var _a, response, output, err_1, delay_1;

              return __generator$1(this, function (_b) {
                switch (_b.label) {
                  case 0:
                    _b.trys.push([0, 2,, 5]);

                    if (HttpRequest.isInstance(request)) {
                      request.headers[REQUEST_HEADER] = "attempt=" + (attempts + 1) + "; max=" + maxAttempts;
                    }

                    return [4
                    /*yield*/
                    , next(args)];

                  case 1:
                    _a = _b.sent(), response = _a.response, output = _a.output;
                    this_1.retryQuota.releaseRetryTokens(retryTokenAmount);
                    output.$metadata.attempts = attempts + 1;
                    output.$metadata.totalRetryDelay = totalDelay;
                    return [2
                    /*return*/
                    , {
                      value: {
                        response: response,
                        output: output
                      }
                    }];

                  case 2:
                    err_1 = _b.sent();
                    attempts++;
                    if (!this_1.shouldRetry(err_1, attempts, maxAttempts)) return [3
                    /*break*/
                    , 4];
                    retryTokenAmount = this_1.retryQuota.retrieveRetryTokens(err_1);
                    delay_1 = this_1.delayDecider(isThrottlingError(err_1) ? THROTTLING_RETRY_DELAY_BASE : DEFAULT_RETRY_DELAY_BASE, attempts);
                    totalDelay += delay_1;
                    return [4
                    /*yield*/
                    , new Promise(function (resolve) {
                      return setTimeout(resolve, delay_1);
                    })];

                  case 3:
                    _b.sent();

                    return [2
                    /*return*/
                    , "continue"];

                  case 4:
                    if (!err_1.$metadata) {
                      err_1.$metadata = {};
                    }

                    err_1.$metadata.attempts = attempts;
                    err_1.$metadata.totalRetryDelay = totalDelay;
                    throw err_1;

                  case 5:
                    return [2
                    /*return*/
                    ];
                }
              });
            };

            this_1 = this;
            _a.label = 2;

          case 2:
            return [5
            /*yield**/
            , _loop_1()];

          case 3:
            state_1 = _a.sent();
            if (typeof state_1 === "object") return [2
            /*return*/
            , state_1.value];
            return [3
            /*break*/
            , 2];

          case 4:
            return [2
            /*return*/
            ];
        }
      });
    });
  };

  return StandardRetryStrategy;
}();

var ENV_MAX_ATTEMPTS = "AWS_MAX_ATTEMPTS";
var CONFIG_MAX_ATTEMPTS = "max_attempts";
var NODE_MAX_ATTEMPT_CONFIG_OPTIONS = {
  environmentVariableSelector: function (env) {
    var value = env[ENV_MAX_ATTEMPTS];
    if (!value) return undefined;
    var maxAttempt = parseInt(value);

    if (Number.isNaN(maxAttempt)) {
      throw new Error("Environment variable " + ENV_MAX_ATTEMPTS + " mast be a number, got \"" + value + "\"");
    }

    return maxAttempt;
  },
  configFileSelector: function (profile) {
    var value = profile[CONFIG_MAX_ATTEMPTS];
    if (!value) return undefined;
    var maxAttempt = parseInt(value);

    if (Number.isNaN(maxAttempt)) {
      throw new Error("Shared config file entry " + CONFIG_MAX_ATTEMPTS + " mast be a number, got \"" + value + "\"");
    }

    return maxAttempt;
  },
  default: DEFAULT_MAX_ATTEMPTS
};
var resolveRetryConfig = function (input) {
  var maxAttempts = normalizeMaxAttempts(input.maxAttempts);
  return __assign$1(__assign$1({}, input), {
    maxAttempts: maxAttempts,
    retryStrategy: input.retryStrategy || new StandardRetryStrategy(maxAttempts)
  });
};

var normalizeMaxAttempts = function (maxAttempts) {
  if (maxAttempts === void 0) {
    maxAttempts = DEFAULT_MAX_ATTEMPTS;
  }

  if (typeof maxAttempts === "number") {
    var promisified_1 = Promise.resolve(maxAttempts);
    return function () {
      return promisified_1;
    };
  }

  return maxAttempts;
};

/**
 * Get config value given the environment variable name or getter from
 * environment variable.
 */

var fromEnv$1 = function (envVarSelector) {
  return function () {
    return __awaiter$1(void 0, void 0, void 0, function () {
      var config;
      return __generator$1(this, function (_a) {
        try {
          config = envVarSelector(process.env);

          if (config === undefined) {
            throw new Error();
          }

          return [2
          /*return*/
          , config];
        } catch (e) {
          throw new ProviderError(e.message || "Cannot load config from environment variables with getter: " + envVarSelector);
        }

        return [2
        /*return*/
        ];
      });
    });
  };
};

var DEFAULT_PROFILE$1 = "default";
var ENV_PROFILE$1 = "AWS_PROFILE";
/**
 * Get config value from the shared config files with inferred profile name.
 */

var fromSharedConfigFiles = function (configSelector, _a) {
  if (_a === void 0) {
    _a = {};
  }

  var _b = _a.preferredFile,
      preferredFile = _b === void 0 ? "config" : _b,
      init = __rest(_a, ["preferredFile"]);

  return function () {
    return __awaiter$1(void 0, void 0, void 0, function () {
      var _a, loadedConfig, _b, profile, _c, configFile, credentialsFile, profileFromCredentials, profileFromConfig, mergedProfile, configValue;

      return __generator$1(this, function (_d) {
        switch (_d.label) {
          case 0:
            _a = init.loadedConfig, loadedConfig = _a === void 0 ? loadSharedConfigFiles(init) : _a, _b = init.profile, profile = _b === void 0 ? process.env[ENV_PROFILE$1] || DEFAULT_PROFILE$1 : _b;
            return [4
            /*yield*/
            , loadedConfig];

          case 1:
            _c = _d.sent(), configFile = _c.configFile, credentialsFile = _c.credentialsFile;
            profileFromCredentials = credentialsFile[profile] || {};
            profileFromConfig = configFile[profile] || {};
            mergedProfile = preferredFile === "config" ? __assign$1(__assign$1({}, profileFromCredentials), profileFromConfig) : __assign$1(__assign$1({}, profileFromConfig), profileFromCredentials);

            try {
              configValue = configSelector(mergedProfile);

              if (configValue === undefined) {
                throw new Error();
              }

              return [2
              /*return*/
              , configValue];
            } catch (e) {
              throw new ProviderError(e.message || "Cannot load config for profile " + profile + " in SDK configuration files with getter: " + configSelector);
            }

            return [2
            /*return*/
            ];
        }
      });
    });
  };
};

var isFunction = function (func) {
  return typeof func === "function";
};

var fromStatic$1 = function (defaultValue) {
  return isFunction(defaultValue) ? function () {
    return __awaiter$1(void 0, void 0, void 0, function () {
      return __generator$1(this, function (_a) {
        return [2
        /*return*/
        , defaultValue()];
      });
    });
  } : fromStatic(defaultValue);
};

var loadConfig = function (_a, configuration) {
  var environmentVariableSelector = _a.environmentVariableSelector,
      configFileSelector = _a.configFileSelector,
      defaultValue = _a.default;

  if (configuration === void 0) {
    configuration = {};
  }

  return memoize(chain(fromEnv$1(environmentVariableSelector), fromSharedConfigFiles(configFileSelector, configuration), fromStatic$1(defaultValue)));
};

var escapeUri = function (uri) {
  // AWS percent-encodes some extra non-standard characters in a URI
  return encodeURIComponent(uri).replace(/[!'()*]/g, hexEncode);
};

var hexEncode = function (c) {
  return "%" + c.charCodeAt(0).toString(16).toUpperCase();
};

function buildQueryString(query) {
  var e_1, _a;

  var parts = [];

  try {
    for (var _b = __values(Object.keys(query).sort()), _c = _b.next(); !_c.done; _c = _b.next()) {
      var key = _c.value;
      var value = query[key];
      key = escapeUri(key);

      if (Array.isArray(value)) {
        for (var i = 0, iLen = value.length; i < iLen; i++) {
          parts.push(key + "=" + escapeUri(value[i]));
        }
      } else {
        var qsEntry = key;

        if (value || typeof value === "string") {
          qsEntry += "=" + escapeUri(value);
        }

        parts.push(qsEntry);
      }
    }
  } catch (e_1_1) {
    e_1 = {
      error: e_1_1
    };
  } finally {
    try {
      if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
    } finally {
      if (e_1) throw e_1.error;
    }
  }

  return parts.join("&");
}

/**
 * Node.js system error codes that indicate timeout.
 */
var NODEJS_TIMEOUT_ERROR_CODES = ["ECONNRESET", "EPIPE", "ETIMEDOUT"];

var getTransformedHeaders = function (headers) {
  var e_1, _a;

  var transformedHeaders = {};

  try {
    for (var _b = __values(Object.keys(headers)), _c = _b.next(); !_c.done; _c = _b.next()) {
      var name = _c.value;
      var headerValues = headers[name];
      transformedHeaders[name] = Array.isArray(headerValues) ? headerValues.join(",") : headerValues;
    }
  } catch (e_1_1) {
    e_1 = {
      error: e_1_1
    };
  } finally {
    try {
      if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
    } finally {
      if (e_1) throw e_1.error;
    }
  }

  return transformedHeaders;
};

var setConnectionTimeout = function (request, reject, timeoutInMs) {
  if (timeoutInMs === void 0) {
    timeoutInMs = 0;
  }

  if (!timeoutInMs) {
    return;
  }

  request.on("socket", function (socket) {
    if (socket.connecting) {
      // Throw a connecting timeout error unless a connection is made within x time.
      var timeoutId_1 = setTimeout(function () {
        // destroy the request.
        request.destroy();
        reject(Object.assign(new Error("Socket timed out without establishing a connection within " + timeoutInMs + " ms"), {
          name: "TimeoutError"
        }));
      }, timeoutInMs); // if the connection was established, cancel the timeout.

      socket.on("connect", function () {
        clearTimeout(timeoutId_1);
      });
    }
  });
};

var setSocketTimeout = function (request, reject, timeoutInMs) {
  if (timeoutInMs === void 0) {
    timeoutInMs = 0;
  }

  request.setTimeout(timeoutInMs, function () {
    // destroy the request
    request.destroy();
    reject(Object.assign(new Error("Connection timed out after " + timeoutInMs + " ms"), {
      name: "TimeoutError"
    }));
  });
};

function writeRequestBody(httpRequest, request) {
  var expect = request.headers["Expect"] || request.headers["expect"];

  if (expect === "100-continue") {
    httpRequest.on("continue", function () {
      writeBody(httpRequest, request.body);
    });
  } else {
    writeBody(httpRequest, request.body);
  }
}

function writeBody(httpRequest, body) {
  if (body instanceof stream.Readable) {
    // pipe automatically handles end
    body.pipe(httpRequest);
  } else if (body) {
    httpRequest.end(Buffer.from(body));
  } else {
    httpRequest.end();
  }
}

var NodeHttpHandler =
/** @class */
function () {
  function NodeHttpHandler(_a) {
    var _b = _a === void 0 ? {} : _a,
        connectionTimeout = _b.connectionTimeout,
        socketTimeout = _b.socketTimeout,
        httpAgent = _b.httpAgent,
        httpsAgent = _b.httpsAgent; // Node http handler is hard-coded to http/1.1: https://github.com/nodejs/node/blob/ff5664b83b89c55e4ab5d5f60068fb457f1f5872/lib/_http_server.js#L286


    this.metadata = {
      handlerProtocol: "http/1.1"
    };
    this.connectionTimeout = connectionTimeout;
    this.socketTimeout = socketTimeout;
    var keepAlive = true;
    var maxSockets = 50;
    this.httpAgent = httpAgent || new http.Agent({
      keepAlive: keepAlive,
      maxSockets: maxSockets
    });
    this.httpsAgent = httpsAgent || new https.Agent({
      keepAlive: keepAlive,
      maxSockets: maxSockets
    });
  }

  NodeHttpHandler.prototype.destroy = function () {
    this.httpAgent.destroy();
    this.httpsAgent.destroy();
  };

  NodeHttpHandler.prototype.handle = function (request, _a) {
    var _this = this;

    var _b = _a === void 0 ? {} : _a,
        abortSignal = _b.abortSignal;

    return new Promise(function (resolve, reject) {
      // if the request was already aborted, prevent doing extra work
      if (abortSignal === null || abortSignal === void 0 ? void 0 : abortSignal.aborted) {
        var abortError = new Error("Request aborted");
        abortError.name = "AbortError";
        reject(abortError);
        return;
      } // determine which http(s) client to use


      var isSSL = request.protocol === "https:";
      var queryString = buildQueryString(request.query || {});
      var nodeHttpsOptions = {
        headers: request.headers,
        host: request.hostname,
        method: request.method,
        path: queryString ? request.path + "?" + queryString : request.path,
        port: request.port,
        agent: isSSL ? _this.httpsAgent : _this.httpAgent
      }; // create the http request

      var requestFunc = isSSL ? https.request : http.request;
      var req = requestFunc(nodeHttpsOptions, function (res) {
        var httpResponse = new HttpResponse({
          statusCode: res.statusCode || -1,
          headers: getTransformedHeaders(res.headers),
          body: res
        });
        resolve({
          response: httpResponse
        });
      });
      req.on("error", function (err) {
        if (NODEJS_TIMEOUT_ERROR_CODES.includes(err.code)) {
          reject(Object.assign(err, {
            name: "TimeoutError"
          }));
        } else {
          reject(err);
        }
      }); // wire-up any timeout logic

      setConnectionTimeout(req, reject, _this.connectionTimeout);
      setSocketTimeout(req, reject, _this.socketTimeout); // wire-up abort logic

      if (abortSignal) {
        abortSignal.onabort = function () {
          // ensure request is destroyed
          req.abort();
          var abortError = new Error("Request aborted");
          abortError.name = "AbortError";
          reject(abortError);
        };
      }

      writeRequestBody(req, request);
    });
  };

  return NodeHttpHandler;
}();

var Collector =
/** @class */
function (_super) {
  __extends$1(Collector, _super);

  function Collector() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.bufferedBytes = [];
    return _this;
  }

  Collector.prototype._write = function (chunk, encoding, callback) {
    this.bufferedBytes.push(chunk);
    callback();
  };

  return Collector;
}(stream.Writable);

var streamCollector = function (stream) {
  return new Promise(function (resolve, reject) {
    var collector = new Collector();
    stream.pipe(collector);
    stream.on("error", function (err) {
      // if the source errors, the destination stream needs to manually end
      collector.end();
      reject(err);
    });
    collector.on("error", reject);
    collector.on("finish", function () {
      var bytes = new Uint8Array(Buffer.concat(this.bufferedBytes));
      resolve(bytes);
    });
  });
};

/**
 * Converts a base-64 encoded string to a Uint8Array of bytes using Node.JS's
 * `buffer` module.
 *
 * @param input The base-64 encoded string
 */

function fromBase64(input) {
  var buffer = fromString$1(input, "base64");
  return new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength);
}
/**
 * Converts a Uint8Array of binary data to a base-64 encoded string using
 * Node.JS's `buffer` module.
 *
 * @param input The binary data to encode
 */

function toBase64(input) {
  return fromArrayBuffer$1(input.buffer, input.byteOffset, input.byteLength).toString("base64");
}

function calculateBodyLength(body) {
  if (!body) {
    return 0;
  }

  if (typeof body === "string") {
    return Buffer.from(body).length;
  } else if (typeof body.byteLength === "number") {
    // handles Uint8Array, ArrayBuffer, Buffer, and ArrayBufferView
    return body.byteLength;
  } else if (typeof body.size === "number") {
    return body.size;
  } else if (typeof body.path === "string") {
    // handles fs readable streams
    return require$$2.lstatSync(body.path).size;
  }
}

var UA_APP_ID_ENV_NAME = "AWS_SDK_UA_APP_ID";
var UA_APP_ID_INI_NAME = "sdk-ua-app-id";
/**
 * Collect metrics from runtime to put into user agent.
 */

var defaultUserAgent = function (_a) {
  var serviceId = _a.serviceId,
      clientVersion = _a.clientVersion;
  return function () {
    return __awaiter$1(void 0, void 0, void 0, function () {
      var sections, appId;
      return __generator$1(this, function (_a) {
        switch (_a.label) {
          case 0:
            sections = [// sdk-metadata
            ["aws-sdk-js", clientVersion], // os-metadata
            ["os/" + os.platform(), os.release()], // language-metadata
            // ECMAScript edition doesn't matter in JS, so no version needed.
            ["lang/js"], ["md/nodejs", "" + process$1.versions.node]];

            if (serviceId) {
              // api-metadata
              // service Id may not appear in non-AWS clients
              sections.push(["api/" + serviceId, clientVersion]);
            }

            if (process$1.env.AWS_EXECUTION_ENV) {
              // env-metadata
              sections.push(["exec-env/" + process$1.env.AWS_EXECUTION_ENV]);
            }

            return [4
            /*yield*/
            , loadConfig({
              environmentVariableSelector: function (env) {
                return env[UA_APP_ID_ENV_NAME];
              },
              configFileSelector: function (profile) {
                return profile[UA_APP_ID_INI_NAME];
              },
              default: undefined
            })()];

          case 1:
            appId = _a.sent();

            if (appId) {
              sections.push(["app/" + appId]);
            }

            return [2
            /*return*/
            , sections];
        }
      });
    });
  };
};

var fromUtf8 = function (input) {
  var buf = fromString$1(input, "utf8");
  return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength / Uint8Array.BYTES_PER_ELEMENT);
};
var toUtf8 = function (input) {
  return fromArrayBuffer$1(input.buffer, input.byteOffset, input.byteLength).toString("utf8");
};

var AWS_TEMPLATE = "s3.{region}.amazonaws.com";
var AWS_CN_TEMPLATE = "s3.{region}.amazonaws.com.cn";
var AWS_ISO_TEMPLATE = "s3.{region}.c2s.ic.gov";
var AWS_ISO_B_TEMPLATE = "s3.{region}.sc2s.sgov.gov";
var AWS_US_GOV_TEMPLATE = "s3.{region}.amazonaws.com"; // Partition regions

var AWS_REGIONS = new Set(["af-south-1", "ap-east-1", "ap-northeast-1", "ap-northeast-2", "ap-south-1", "ap-southeast-1", "ap-southeast-2", "ca-central-1", "eu-central-1", "eu-north-1", "eu-south-1", "eu-west-1", "eu-west-2", "eu-west-3", "me-south-1", "sa-east-1", "us-east-1", "us-east-2", "us-west-1", "us-west-2"]);
var AWS_CN_REGIONS = new Set(["cn-north-1", "cn-northwest-1"]);
var AWS_ISO_REGIONS = new Set(["us-iso-east-1"]);
var AWS_ISO_B_REGIONS = new Set(["us-isob-east-1"]);
var AWS_US_GOV_REGIONS = new Set(["us-gov-east-1", "us-gov-west-1"]);
var defaultRegionInfoProvider = function (region, options) {
  var regionInfo = undefined;

  switch (region) {
    // First, try to match exact region names.
    case "af-south-1":
      regionInfo = {
        hostname: "s3.af-south-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "ap-east-1":
      regionInfo = {
        hostname: "s3.ap-east-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "ap-northeast-1":
      regionInfo = {
        hostname: "s3.ap-northeast-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "ap-northeast-2":
      regionInfo = {
        hostname: "s3.ap-northeast-2.amazonaws.com",
        partition: "aws"
      };
      break;

    case "ap-south-1":
      regionInfo = {
        hostname: "s3.ap-south-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "ap-southeast-1":
      regionInfo = {
        hostname: "s3.ap-southeast-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "ap-southeast-2":
      regionInfo = {
        hostname: "s3.ap-southeast-2.amazonaws.com",
        partition: "aws"
      };
      break;

    case "aws-global":
      regionInfo = {
        hostname: "s3.amazonaws.com",
        partition: "aws",
        signingRegion: "us-east-1"
      };
      break;

    case "ca-central-1":
      regionInfo = {
        hostname: "s3.ca-central-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "cn-north-1":
      regionInfo = {
        hostname: "s3.cn-north-1.amazonaws.com.cn",
        partition: "aws-cn"
      };
      break;

    case "cn-northwest-1":
      regionInfo = {
        hostname: "s3.cn-northwest-1.amazonaws.com.cn",
        partition: "aws-cn"
      };
      break;

    case "eu-central-1":
      regionInfo = {
        hostname: "s3.eu-central-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "eu-north-1":
      regionInfo = {
        hostname: "s3.eu-north-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "eu-south-1":
      regionInfo = {
        hostname: "s3.eu-south-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "eu-west-1":
      regionInfo = {
        hostname: "s3.eu-west-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "eu-west-2":
      regionInfo = {
        hostname: "s3.eu-west-2.amazonaws.com",
        partition: "aws"
      };
      break;

    case "eu-west-3":
      regionInfo = {
        hostname: "s3.eu-west-3.amazonaws.com",
        partition: "aws"
      };
      break;

    case "fips-us-gov-west-1":
      regionInfo = {
        hostname: "s3-fips.us-gov-west-1.amazonaws.com",
        partition: "aws-us-gov",
        signingRegion: "us-gov-west-1"
      };
      break;

    case "me-south-1":
      regionInfo = {
        hostname: "s3.me-south-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "s3-external-1":
      regionInfo = {
        hostname: "s3-external-1.amazonaws.com",
        partition: "aws",
        signingRegion: "us-east-1"
      };
      break;

    case "sa-east-1":
      regionInfo = {
        hostname: "s3.sa-east-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "us-east-1":
      regionInfo = {
        hostname: "s3.us-east-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "us-east-2":
      regionInfo = {
        hostname: "s3.us-east-2.amazonaws.com",
        partition: "aws"
      };
      break;

    case "us-gov-east-1":
      regionInfo = {
        hostname: "s3.us-gov-east-1.amazonaws.com",
        partition: "aws-us-gov"
      };
      break;

    case "us-gov-west-1":
      regionInfo = {
        hostname: "s3.us-gov-west-1.amazonaws.com",
        partition: "aws-us-gov"
      };
      break;

    case "us-iso-east-1":
      regionInfo = {
        hostname: "s3.us-iso-east-1.c2s.ic.gov",
        partition: "aws-iso"
      };
      break;

    case "us-isob-east-1":
      regionInfo = {
        hostname: "s3.us-isob-east-1.sc2s.sgov.gov",
        partition: "aws-iso-b"
      };
      break;

    case "us-west-1":
      regionInfo = {
        hostname: "s3.us-west-1.amazonaws.com",
        partition: "aws"
      };
      break;

    case "us-west-2":
      regionInfo = {
        hostname: "s3.us-west-2.amazonaws.com",
        partition: "aws"
      };
      break;
    // Next, try to match partition endpoints.

    default:
      if (AWS_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_TEMPLATE.replace("{region}", region),
          partition: "aws"
        };
      }

      if (AWS_CN_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_CN_TEMPLATE.replace("{region}", region),
          partition: "aws-cn"
        };
      }

      if (AWS_ISO_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_ISO_TEMPLATE.replace("{region}", region),
          partition: "aws-iso"
        };
      }

      if (AWS_ISO_B_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_ISO_B_TEMPLATE.replace("{region}", region),
          partition: "aws-iso-b"
        };
      }

      if (AWS_US_GOV_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_US_GOV_TEMPLATE.replace("{region}", region),
          partition: "aws-us-gov"
        };
      } // Finally, assume it's an AWS partition endpoint.


      if (regionInfo === undefined) {
        regionInfo = {
          hostname: AWS_TEMPLATE.replace("{region}", region),
          partition: "aws"
        };
      }

  }

  return Promise.resolve(__assign({
    signingService: "s3"
  }, regionInfo));
};

function parseQueryString(querystring) {
  var e_1, _a;

  var query = {};
  querystring = querystring.replace(/^\?/, "");

  if (querystring) {
    try {
      for (var _b = __values(querystring.split("&")), _c = _b.next(); !_c.done; _c = _b.next()) {
        var pair = _c.value;

        var _d = __read(pair.split("="), 2),
            key = _d[0],
            _e = _d[1],
            value = _e === void 0 ? null : _e;

        key = decodeURIComponent(key);

        if (value) {
          value = decodeURIComponent(value);
        }

        if (!(key in query)) {
          query[key] = value;
        } else if (Array.isArray(query[key])) {
          query[key].push(value);
        } else {
          query[key] = [query[key], value];
        }
      }
    } catch (e_1_1) {
      e_1 = {
        error: e_1_1
      };
    } finally {
      try {
        if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
      } finally {
        if (e_1) throw e_1.error;
      }
    }
  }

  return query;
}

var parseUrl = function (url) {
  var _a = new URL(url),
      hostname = _a.hostname,
      pathname = _a.pathname,
      port = _a.port,
      protocol = _a.protocol,
      search = _a.search;

  var query;

  if (search) {
    query = parseQueryString(search);
  }

  return {
    hostname: hostname,
    port: port ? parseInt(port) : undefined,
    protocol: protocol,
    path: pathname,
    query: query
  };
};

/**
 * @internal
 */

var ClientSharedValues = {
  apiVersion: "2006-03-01",
  disableHostPrefix: false,
  logger: {},
  regionInfoProvider: defaultRegionInfoProvider,
  serviceId: "S3",
  signingEscapePath: false,
  urlParser: parseUrl,
  useArnRegion: false
};

/**
 * @internal
 */

var ClientDefaultValues = __assign(__assign({}, ClientSharedValues), {
  runtime: "node",
  base64Decoder: fromBase64,
  base64Encoder: toBase64,
  bodyLengthChecker: calculateBodyLength,
  credentialDefaultProvider: defaultProvider,
  defaultUserAgentProvider: defaultUserAgent({
    serviceId: ClientSharedValues.serviceId,
    clientVersion: packageInfo.version
  }),
  eventStreamSerdeProvider: eventStreamSerdeProvider,
  maxAttempts: loadConfig(NODE_MAX_ATTEMPT_CONFIG_OPTIONS),
  md5: Hash.bind(null, "md5"),
  region: loadConfig(NODE_REGION_CONFIG_OPTIONS, NODE_REGION_CONFIG_FILE_OPTIONS),
  requestHandler: new NodeHttpHandler(),
  sha256: Hash.bind(null, "sha256"),
  streamCollector: streamCollector,
  streamHasher: fileStreamHasher,
  useArnRegion: loadConfig(NODE_USE_ARN_REGION_CONFIG_OPTIONS),
  utf8Decoder: fromUtf8,
  utf8Encoder: toUtf8
});

var resolveEventStreamSerdeConfig = function (input) {
  return __assign$1(__assign$1({}, input), {
    eventStreamMarshaller: input.eventStreamSerdeProvider(input)
  });
};

var CONTENT_LENGTH_HEADER = "content-length";
function contentLengthMiddleware(bodyLengthChecker) {
  var _this = this;

  return function (next) {
    return function (args) {
      return __awaiter$1(_this, void 0, void 0, function () {
        var request, body, headers, length;

        var _a;

        return __generator$1(this, function (_b) {
          request = args.request;

          if (HttpRequest.isInstance(request)) {
            body = request.body, headers = request.headers;

            if (body && Object.keys(headers).map(function (str) {
              return str.toLowerCase();
            }).indexOf(CONTENT_LENGTH_HEADER) === -1) {
              length = bodyLengthChecker(body);

              if (length !== undefined) {
                request.headers = __assign$1(__assign$1({}, request.headers), (_a = {}, _a[CONTENT_LENGTH_HEADER] = String(length), _a));
              }
            }
          }

          return [2
          /*return*/
          , next(__assign$1(__assign$1({}, args), {
            request: request
          }))];
        });
      });
    };
  };
}
var contentLengthMiddlewareOptions = {
  step: "build",
  tags: ["SET_CONTENT_LENGTH", "CONTENT_LENGTH"],
  name: "contentLengthMiddleware",
  override: true
};
var getContentLengthPlugin = function (options) {
  return {
    applyToStack: function (clientStack) {
      clientStack.add(contentLengthMiddleware(options.bodyLengthChecker), contentLengthMiddlewareOptions);
    }
  };
};

function addExpectContinueMiddleware(options) {
  var _this = this;

  return function (next) {
    return function (args) {
      return __awaiter$1(_this, void 0, void 0, function () {
        var request;
        return __generator$1(this, function (_a) {
          request = args.request;

          if (HttpRequest.isInstance(request) && request.body && options.runtime === "node") {
            request.headers = __assign$1(__assign$1({}, request.headers), {
              Expect: "100-continue"
            });
          }

          return [2
          /*return*/
          , next(__assign$1(__assign$1({}, args), {
            request: request
          }))];
        });
      });
    };
  };
}
var addExpectContinueMiddlewareOptions = {
  step: "build",
  tags: ["SET_EXPECT_HEADER", "EXPECT_HEADER"],
  name: "addExpectContinueMiddleware",
  override: true
};
var getAddExpectContinuePlugin = function (options) {
  return {
    applyToStack: function (clientStack) {
      clientStack.add(addExpectContinueMiddleware(options), addExpectContinueMiddlewareOptions);
    }
  };
};

function resolveHostHeaderConfig(input) {
  return input;
}
var hostHeaderMiddleware = function (options) {
  return function (next) {
    return function (args) {
      return __awaiter$1(void 0, void 0, void 0, function () {
        var request, _a, handlerProtocol;

        return __generator$1(this, function (_b) {
          if (!HttpRequest.isInstance(args.request)) return [2
          /*return*/
          , next(args)];
          request = args.request;
          _a = (options.requestHandler.metadata || {}).handlerProtocol, handlerProtocol = _a === void 0 ? "" : _a; //For H2 request, remove 'host' header and use ':authority' header instead
          //reference: https://nodejs.org/dist/latest-v13.x/docs/api/errors.html#ERR_HTTP2_INVALID_CONNECTION_HEADERS

          if (handlerProtocol.indexOf("h2") >= 0 && !request.headers[":authority"]) {
            delete request.headers["host"];
            request.headers[":authority"] = ""; //non-H2 request and 'host' header is not set, set the 'host' header to request's hostname.
          } else if (!request.headers["host"]) {
            request.headers["host"] = request.hostname;
          }

          return [2
          /*return*/
          , next(args)];
        });
      });
    };
  };
};
var hostHeaderMiddlewareOptions = {
  name: "hostHeaderMiddleware",
  step: "build",
  priority: "low",
  tags: ["HOST"],
  override: true
};
var getHostHeaderPlugin = function (options) {
  return {
    applyToStack: function (clientStack) {
      clientStack.add(hostHeaderMiddleware(options), hostHeaderMiddlewareOptions);
    }
  };
};

var loggerMiddleware = function () {
  return function (next, context) {
    return function (args) {
      return __awaiter$1(void 0, void 0, void 0, function () {
        var clientName, commandName, inputFilterSensitiveLog, logger, outputFilterSensitiveLog, response, _a, $metadata, outputWithoutMetadata;

        return __generator$1(this, function (_b) {
          switch (_b.label) {
            case 0:
              clientName = context.clientName, commandName = context.commandName, inputFilterSensitiveLog = context.inputFilterSensitiveLog, logger = context.logger, outputFilterSensitiveLog = context.outputFilterSensitiveLog;
              return [4
              /*yield*/
              , next(args)];

            case 1:
              response = _b.sent();

              if (!logger) {
                return [2
                /*return*/
                , response];
              }

              if (typeof logger.info === "function") {
                _a = response.output, $metadata = _a.$metadata, outputWithoutMetadata = __rest(_a, ["$metadata"]);
                logger.info({
                  clientName: clientName,
                  commandName: commandName,
                  input: inputFilterSensitiveLog(args.input),
                  output: outputFilterSensitiveLog(outputWithoutMetadata),
                  metadata: $metadata
                });
              }

              return [2
              /*return*/
              , response];
          }
        });
      });
    };
  };
};
var loggerMiddlewareOptions = {
  name: "loggerMiddleware",
  tags: ["LOGGER"],
  step: "initialize",
  override: true
}; // eslint-disable-next-line @typescript-eslint/no-unused-vars

var getLoggerPlugin = function (options) {
  return {
    applyToStack: function (clientStack) {
      clientStack.add(loggerMiddleware(), loggerMiddlewareOptions);
    }
  };
};

/**
 * @internal
 */

function validateBucketNameMiddleware() {
  var _this = this;

  return function (next) {
    return function (args) {
      return __awaiter$1(_this, void 0, void 0, function () {
        var Bucket, err;
        return __generator$1(this, function (_a) {
          Bucket = args.input.Bucket;

          if (typeof Bucket === "string" && !validate(Bucket) && Bucket.indexOf("/") >= 0) {
            err = new Error("Bucket name shouldn't contain '/', received '" + Bucket + "'");
            err.name = "InvalidBucketName";
            throw err;
          }

          return [2
          /*return*/
          , next(__assign$1({}, args))];
        });
      });
    };
  };
}
/**
 * @internal
 */

var validateBucketNameMiddlewareOptions = {
  step: "initialize",
  tags: ["VALIDATE_BUCKET_NAME"],
  name: "validateBucketNameMiddleware",
  override: true
};
/**
 * @internal
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars

var getValidateBucketNamePlugin = function (unused) {
  return {
    applyToStack: function (clientStack) {
      clientStack.add(validateBucketNameMiddleware(), validateBucketNameMiddlewareOptions);
    }
  };
};

/**
 * @internal
 */

var useRegionalEndpointMiddleware = function (config) {
  return function (next) {
    return function (args) {
      return __awaiter$1(void 0, void 0, void 0, function () {
        var request, _a;

        return __generator$1(this, function (_b) {
          switch (_b.label) {
            case 0:
              request = args.request;
              if (!HttpRequest.isInstance(request) || config.isCustomEndpoint) return [2
              /*return*/
              , next(__assign$1({}, args))];
              if (!(request.hostname === "s3.amazonaws.com")) return [3
              /*break*/
              , 1];
              request.hostname = "s3.us-east-1.amazonaws.com";
              return [3
              /*break*/
              , 3];

            case 1:
              _a = "aws-global";
              return [4
              /*yield*/
              , config.region()];

            case 2:
              if (_a === _b.sent()) {
                request.hostname = "s3.amazonaws.com";
              }

              _b.label = 3;

            case 3:
              return [2
              /*return*/
              , next(__assign$1({}, args))];
          }
        });
      });
    };
  };
};
/**
 * @internal
 */

var useRegionalEndpointMiddlewareOptions = {
  step: "build",
  tags: ["USE_REGIONAL_ENDPOINT", "S3"],
  name: "useRegionalEndpointMiddleware",
  override: true
};
/**
 * @internal
 */

var getUseRegionalEndpointPlugin = function (config) {
  return {
    applyToStack: function (clientStack) {
      clientStack.add(useRegionalEndpointMiddleware(config), useRegionalEndpointMiddlewareOptions);
    }
  };
};

var ALGORITHM_QUERY_PARAM = "X-Amz-Algorithm";
var CREDENTIAL_QUERY_PARAM = "X-Amz-Credential";
var AMZ_DATE_QUERY_PARAM = "X-Amz-Date";
var SIGNED_HEADERS_QUERY_PARAM = "X-Amz-SignedHeaders";
var EXPIRES_QUERY_PARAM = "X-Amz-Expires";
var SIGNATURE_QUERY_PARAM = "X-Amz-Signature";
var TOKEN_QUERY_PARAM = "X-Amz-Security-Token";
var AUTH_HEADER = "authorization";
var AMZ_DATE_HEADER = AMZ_DATE_QUERY_PARAM.toLowerCase();
var DATE_HEADER = "date";
var GENERATED_HEADERS = [AUTH_HEADER, AMZ_DATE_HEADER, DATE_HEADER];
var SIGNATURE_HEADER = SIGNATURE_QUERY_PARAM.toLowerCase();
var SHA256_HEADER = "x-amz-content-sha256";
var TOKEN_HEADER = TOKEN_QUERY_PARAM.toLowerCase();
var ALWAYS_UNSIGNABLE_HEADERS = {
  authorization: true,
  "cache-control": true,
  connection: true,
  expect: true,
  from: true,
  "keep-alive": true,
  "max-forwards": true,
  pragma: true,
  referer: true,
  te: true,
  trailer: true,
  "transfer-encoding": true,
  upgrade: true,
  "user-agent": true,
  "x-amzn-trace-id": true
};
var PROXY_HEADER_PATTERN = /^proxy-/;
var SEC_HEADER_PATTERN = /^sec-/;
var ALGORITHM_IDENTIFIER = "AWS4-HMAC-SHA256";
var EVENT_ALGORITHM_IDENTIFIER = "AWS4-HMAC-SHA256-PAYLOAD";
var UNSIGNED_PAYLOAD = "UNSIGNED-PAYLOAD";
var MAX_CACHE_SIZE = 50;
var KEY_TYPE_IDENTIFIER = "aws4_request";
var MAX_PRESIGNED_TTL = 60 * 60 * 24 * 7;

var signingKeyCache = {};
var cacheQueue = [];
/**
 * Create a string describing the scope of credentials used to sign a request.
 *
 * @param shortDate The current calendar date in the form YYYYMMDD.
 * @param region    The AWS region in which the service resides.
 * @param service   The service to which the signed request is being sent.
 */

function createScope(shortDate, region, service) {
  return shortDate + "/" + region + "/" + service + "/" + KEY_TYPE_IDENTIFIER;
}
/**
 * Derive a signing key from its composite parts
 *
 * @param sha256Constructor A constructor function that can instantiate SHA-256
 *                          hash objects.
 * @param credentials       The credentials with which the request will be
 *                          signed.
 * @param shortDate         The current calendar date in the form YYYYMMDD.
 * @param region            The AWS region in which the service resides.
 * @param service           The service to which the signed request is being
 *                          sent.
 */

var getSigningKey = function (sha256Constructor, credentials, shortDate, region, service) {
  return __awaiter$1(void 0, void 0, void 0, function () {
    var credsHash, cacheKey, key, _a, _b, signable, e_1_1;

    var e_1, _c;

    return __generator$1(this, function (_d) {
      switch (_d.label) {
        case 0:
          return [4
          /*yield*/
          , hmac(sha256Constructor, credentials.secretAccessKey, credentials.accessKeyId)];

        case 1:
          credsHash = _d.sent();
          cacheKey = shortDate + ":" + region + ":" + service + ":" + toHex(credsHash) + ":" + credentials.sessionToken;

          if (cacheKey in signingKeyCache) {
            return [2
            /*return*/
            , signingKeyCache[cacheKey]];
          }

          cacheQueue.push(cacheKey);

          while (cacheQueue.length > MAX_CACHE_SIZE) {
            delete signingKeyCache[cacheQueue.shift()];
          }

          key = "AWS4" + credentials.secretAccessKey;
          _d.label = 2;

        case 2:
          _d.trys.push([2, 7, 8, 9]);

          _a = __values([shortDate, region, service, KEY_TYPE_IDENTIFIER]), _b = _a.next();
          _d.label = 3;

        case 3:
          if (!!_b.done) return [3
          /*break*/
          , 6];
          signable = _b.value;
          return [4
          /*yield*/
          , hmac(sha256Constructor, key, signable)];

        case 4:
          key = _d.sent();
          _d.label = 5;

        case 5:
          _b = _a.next();
          return [3
          /*break*/
          , 3];

        case 6:
          return [3
          /*break*/
          , 9];

        case 7:
          e_1_1 = _d.sent();
          e_1 = {
            error: e_1_1
          };
          return [3
          /*break*/
          , 9];

        case 8:
          try {
            if (_b && !_b.done && (_c = _a.return)) _c.call(_a);
          } finally {
            if (e_1) throw e_1.error;
          }

          return [7
          /*endfinally*/
          ];

        case 9:
          return [2
          /*return*/
          , signingKeyCache[cacheKey] = key];
      }
    });
  });
};

function hmac(ctor, secret, data) {
  var hash = new ctor(secret);
  hash.update(data);
  return hash.digest();
}

/**
 * @internal
 */

function getCanonicalHeaders(_a, unsignableHeaders, signableHeaders) {
  var e_1, _b;

  var headers = _a.headers;
  var canonical = {};

  try {
    for (var _c = __values(Object.keys(headers).sort()), _d = _c.next(); !_d.done; _d = _c.next()) {
      var headerName = _d.value;
      var canonicalHeaderName = headerName.toLowerCase();

      if (canonicalHeaderName in ALWAYS_UNSIGNABLE_HEADERS || (unsignableHeaders === null || unsignableHeaders === void 0 ? void 0 : unsignableHeaders.has(canonicalHeaderName)) || PROXY_HEADER_PATTERN.test(canonicalHeaderName) || SEC_HEADER_PATTERN.test(canonicalHeaderName)) {
        if (!signableHeaders || signableHeaders && !signableHeaders.has(canonicalHeaderName)) {
          continue;
        }
      }

      canonical[canonicalHeaderName] = headers[headerName].trim().replace(/\s+/g, " ");
    }
  } catch (e_1_1) {
    e_1 = {
      error: e_1_1
    };
  } finally {
    try {
      if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
    } finally {
      if (e_1) throw e_1.error;
    }
  }

  return canonical;
}

/**
 * @internal
 */

function getCanonicalQuery(_a) {
  var e_1, _b;

  var _c = _a.query,
      query = _c === void 0 ? {} : _c;
  var keys = [];
  var serialized = {};

  var _loop_1 = function (key) {
    if (key.toLowerCase() === SIGNATURE_HEADER) {
      return "continue";
    }

    keys.push(key);
    var value = query[key];

    if (typeof value === "string") {
      serialized[key] = escapeUri(key) + "=" + escapeUri(value);
    } else if (Array.isArray(value)) {
      serialized[key] = value.slice(0).sort().reduce(function (encoded, value) {
        return encoded.concat([escapeUri(key) + "=" + escapeUri(value)]);
      }, []).join("&");
    }
  };

  try {
    for (var _d = __values(Object.keys(query).sort()), _e = _d.next(); !_e.done; _e = _d.next()) {
      var key = _e.value;

      _loop_1(key);
    }
  } catch (e_1_1) {
    e_1 = {
      error: e_1_1
    };
  } finally {
    try {
      if (_e && !_e.done && (_b = _d.return)) _b.call(_d);
    } finally {
      if (e_1) throw e_1.error;
    }
  }

  return keys.map(function (key) {
    return serialized[key];
  }).filter(function (serialized) {
    return serialized;
  }) // omit any falsy values
  .join("&");
}

/**
 * @internal
 */

function getPayloadHash(_a, hashConstructor) {
  var headers = _a.headers,
      body = _a.body;
  return __awaiter$1(this, void 0, void 0, function () {
    var _b, _c, headerName, hashCtor, _d;

    var e_1, _e;

    return __generator$1(this, function (_f) {
      switch (_f.label) {
        case 0:
          try {
            for (_b = __values(Object.keys(headers)), _c = _b.next(); !_c.done; _c = _b.next()) {
              headerName = _c.value;

              if (headerName.toLowerCase() === SHA256_HEADER) {
                return [2
                /*return*/
                , headers[headerName]];
              }
            }
          } catch (e_1_1) {
            e_1 = {
              error: e_1_1
            };
          } finally {
            try {
              if (_c && !_c.done && (_e = _b.return)) _e.call(_b);
            } finally {
              if (e_1) throw e_1.error;
            }
          }

          if (!(body == undefined)) return [3
          /*break*/
          , 1];
          return [2
          /*return*/
          , "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"];

        case 1:
          if (!(typeof body === "string" || ArrayBuffer.isView(body) || isArrayBuffer$1(body))) return [3
          /*break*/
          , 3];
          hashCtor = new hashConstructor();
          hashCtor.update(body);
          _d = toHex;
          return [4
          /*yield*/
          , hashCtor.digest()];

        case 2:
          return [2
          /*return*/
          , _d.apply(void 0, [_f.sent()])];

        case 3:
          // As any defined body that is not a string or binary data is a stream, this
          // body is unsignable. Attempt to send the request with an unsigned payload,
          // which may or may not be accepted by the service.
          return [2
          /*return*/
          , UNSIGNED_PAYLOAD];
      }
    });
  });
}

function hasHeader(soughtHeader, headers) {
  var e_1, _a;

  soughtHeader = soughtHeader.toLowerCase();

  try {
    for (var _b = __values(Object.keys(headers)), _c = _b.next(); !_c.done; _c = _b.next()) {
      var headerName = _c.value;

      if (soughtHeader === headerName.toLowerCase()) {
        return true;
      }
    }
  } catch (e_1_1) {
    e_1 = {
      error: e_1_1
    };
  } finally {
    try {
      if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
    } finally {
      if (e_1) throw e_1.error;
    }
  }

  return false;
}

/**
 * @internal
 */

function cloneRequest(_a) {
  var headers = _a.headers,
      query = _a.query,
      rest = __rest(_a, ["headers", "query"]);

  return __assign$1(__assign$1({}, rest), {
    headers: __assign$1({}, headers),
    query: query ? cloneQuery$1(query) : undefined
  });
}

function cloneQuery$1(query) {
  return Object.keys(query).reduce(function (carry, paramName) {
    var _a;

    var param = query[paramName];
    return __assign$1(__assign$1({}, carry), (_a = {}, _a[paramName] = Array.isArray(param) ? __spread(param) : param, _a));
  }, {});
}

/**
 * @internal
 */

function moveHeadersToQuery(request, options) {
  var e_1, _a;

  var _b;

  if (options === void 0) {
    options = {};
  }

  var _c = typeof request.clone === "function" ? request.clone() : cloneRequest(request),
      headers = _c.headers,
      _d = _c.query,
      query = _d === void 0 ? {} : _d;

  try {
    for (var _e = __values(Object.keys(headers)), _f = _e.next(); !_f.done; _f = _e.next()) {
      var name = _f.value;
      var lname = name.toLowerCase();

      if (lname.substr(0, 6) === "x-amz-" && !((_b = options.unhoistableHeaders) === null || _b === void 0 ? void 0 : _b.has(lname))) {
        query[name] = headers[name];
        delete headers[name];
      }
    }
  } catch (e_1_1) {
    e_1 = {
      error: e_1_1
    };
  } finally {
    try {
      if (_f && !_f.done && (_a = _e.return)) _a.call(_e);
    } finally {
      if (e_1) throw e_1.error;
    }
  }

  return __assign$1(__assign$1({}, request), {
    headers: headers,
    query: query
  });
}

/**
 * @internal
 */

function prepareRequest(request) {
  var e_1, _a; // Create a clone of the request object that does not clone the body


  request = typeof request.clone === "function" ? request.clone() : cloneRequest(request);

  try {
    for (var _b = __values(Object.keys(request.headers)), _c = _b.next(); !_c.done; _c = _b.next()) {
      var headerName = _c.value;

      if (GENERATED_HEADERS.indexOf(headerName.toLowerCase()) > -1) {
        delete request.headers[headerName];
      }
    }
  } catch (e_1_1) {
    e_1 = {
      error: e_1_1
    };
  } finally {
    try {
      if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
    } finally {
      if (e_1) throw e_1.error;
    }
  }

  return request;
}

function iso8601(time) {
  return toDate(time).toISOString().replace(/\.\d{3}Z$/, "Z");
}
function toDate(time) {
  if (typeof time === "number") {
    return new Date(time * 1000);
  }

  if (typeof time === "string") {
    if (Number(time)) {
      return new Date(Number(time) * 1000);
    }

    return new Date(time);
  }

  return time;
}

var SignatureV4 =
/** @class */
function () {
  function SignatureV4(_a) {
    var applyChecksum = _a.applyChecksum,
        credentials = _a.credentials,
        region = _a.region,
        service = _a.service,
        sha256 = _a.sha256,
        _b = _a.uriEscapePath,
        uriEscapePath = _b === void 0 ? true : _b;
    this.service = service;
    this.sha256 = sha256;
    this.uriEscapePath = uriEscapePath; // default to true if applyChecksum isn't set

    this.applyChecksum = typeof applyChecksum === "boolean" ? applyChecksum : true;
    this.regionProvider = normalizeRegionProvider(region);
    this.credentialProvider = normalizeCredentialsProvider(credentials);
  }

  SignatureV4.prototype.presign = function (originalRequest, options) {
    if (options === void 0) {
      options = {};
    }

    return __awaiter$1(this, void 0, void 0, function () {
      var _a, signingDate, _b, expiresIn, unsignableHeaders, unhoistableHeaders, signableHeaders, signingRegion, signingService, credentials, region, _c, _d, longDate, shortDate, scope, request, canonicalHeaders, _e, _f, _g, _h, _j, _k;

      return __generator$1(this, function (_l) {
        switch (_l.label) {
          case 0:
            _a = options.signingDate, signingDate = _a === void 0 ? new Date() : _a, _b = options.expiresIn, expiresIn = _b === void 0 ? 3600 : _b, unsignableHeaders = options.unsignableHeaders, unhoistableHeaders = options.unhoistableHeaders, signableHeaders = options.signableHeaders, signingRegion = options.signingRegion, signingService = options.signingService;
            return [4
            /*yield*/
            , this.credentialProvider()];

          case 1:
            credentials = _l.sent();
            if (!(signingRegion !== null && signingRegion !== void 0)) return [3
            /*break*/
            , 2];
            _c = signingRegion;
            return [3
            /*break*/
            , 4];

          case 2:
            return [4
            /*yield*/
            , this.regionProvider()];

          case 3:
            _c = _l.sent();
            _l.label = 4;

          case 4:
            region = _c;
            _d = formatDate(signingDate), longDate = _d.longDate, shortDate = _d.shortDate;

            if (expiresIn > MAX_PRESIGNED_TTL) {
              return [2
              /*return*/
              , Promise.reject("Signature version 4 presigned URLs" + " must have an expiration date less than one week in" + " the future")];
            }

            scope = createScope(shortDate, region, signingService !== null && signingService !== void 0 ? signingService : this.service);
            request = moveHeadersToQuery(prepareRequest(originalRequest), {
              unhoistableHeaders: unhoistableHeaders
            });

            if (credentials.sessionToken) {
              request.query[TOKEN_QUERY_PARAM] = credentials.sessionToken;
            }

            request.query[ALGORITHM_QUERY_PARAM] = ALGORITHM_IDENTIFIER;
            request.query[CREDENTIAL_QUERY_PARAM] = credentials.accessKeyId + "/" + scope;
            request.query[AMZ_DATE_QUERY_PARAM] = longDate;
            request.query[EXPIRES_QUERY_PARAM] = expiresIn.toString(10);
            canonicalHeaders = getCanonicalHeaders(request, unsignableHeaders, signableHeaders);
            request.query[SIGNED_HEADERS_QUERY_PARAM] = getCanonicalHeaderList(canonicalHeaders);
            _e = request.query;
            _f = SIGNATURE_QUERY_PARAM;
            _g = this.getSignature;
            _h = [longDate, scope, this.getSigningKey(credentials, region, shortDate, signingService)];
            _j = this.createCanonicalRequest;
            _k = [request, canonicalHeaders];
            return [4
            /*yield*/
            , getPayloadHash(originalRequest, this.sha256)];

          case 5:
            return [4
            /*yield*/
            , _g.apply(this, _h.concat([_j.apply(this, _k.concat([_l.sent()]))]))];

          case 6:
            _e[_f] = _l.sent();
            return [2
            /*return*/
            , request];
        }
      });
    });
  };

  SignatureV4.prototype.sign = function (toSign, options) {
    return __awaiter$1(this, void 0, void 0, function () {
      return __generator$1(this, function (_a) {
        if (typeof toSign === "string") {
          return [2
          /*return*/
          , this.signString(toSign, options)];
        } else if (toSign.headers && toSign.payload) {
          return [2
          /*return*/
          , this.signEvent(toSign, options)];
        } else {
          return [2
          /*return*/
          , this.signRequest(toSign, options)];
        }
      });
    });
  };

  SignatureV4.prototype.signEvent = function (_a, _b) {
    var headers = _a.headers,
        payload = _a.payload;
    var _c = _b.signingDate,
        signingDate = _c === void 0 ? new Date() : _c,
        priorSignature = _b.priorSignature,
        signingRegion = _b.signingRegion,
        signingService = _b.signingService;
    return __awaiter$1(this, void 0, void 0, function () {
      var region, _d, _e, shortDate, longDate, scope, hashedPayload, hash, hashedHeaders, _f, stringToSign;

      return __generator$1(this, function (_g) {
        switch (_g.label) {
          case 0:
            if (!(signingRegion !== null && signingRegion !== void 0)) return [3
            /*break*/
            , 1];
            _d = signingRegion;
            return [3
            /*break*/
            , 3];

          case 1:
            return [4
            /*yield*/
            , this.regionProvider()];

          case 2:
            _d = _g.sent();
            _g.label = 3;

          case 3:
            region = _d;
            _e = formatDate(signingDate), shortDate = _e.shortDate, longDate = _e.longDate;
            scope = createScope(shortDate, region, signingService !== null && signingService !== void 0 ? signingService : this.service);
            return [4
            /*yield*/
            , getPayloadHash({
              headers: {},
              body: payload
            }, this.sha256)];

          case 4:
            hashedPayload = _g.sent();
            hash = new this.sha256();
            hash.update(headers);
            _f = toHex;
            return [4
            /*yield*/
            , hash.digest()];

          case 5:
            hashedHeaders = _f.apply(void 0, [_g.sent()]);
            stringToSign = [EVENT_ALGORITHM_IDENTIFIER, longDate, scope, priorSignature, hashedHeaders, hashedPayload].join("\n");
            return [2
            /*return*/
            , this.signString(stringToSign, {
              signingDate: signingDate,
              signingRegion: region,
              signingService: signingService
            })];
        }
      });
    });
  };

  SignatureV4.prototype.signString = function (stringToSign, _a) {
    var _b = _a === void 0 ? {} : _a,
        _c = _b.signingDate,
        signingDate = _c === void 0 ? new Date() : _c,
        signingRegion = _b.signingRegion,
        signingService = _b.signingService;

    return __awaiter$1(this, void 0, void 0, function () {
      var credentials, region, _d, shortDate, hash, _e, _f, _g;

      return __generator$1(this, function (_h) {
        switch (_h.label) {
          case 0:
            return [4
            /*yield*/
            , this.credentialProvider()];

          case 1:
            credentials = _h.sent();
            if (!(signingRegion !== null && signingRegion !== void 0)) return [3
            /*break*/
            , 2];
            _d = signingRegion;
            return [3
            /*break*/
            , 4];

          case 2:
            return [4
            /*yield*/
            , this.regionProvider()];

          case 3:
            _d = _h.sent();
            _h.label = 4;

          case 4:
            region = _d;
            shortDate = formatDate(signingDate).shortDate;
            _f = (_e = this.sha256).bind;
            return [4
            /*yield*/
            , this.getSigningKey(credentials, region, shortDate, signingService)];

          case 5:
            hash = new (_f.apply(_e, [void 0, _h.sent()]))();
            hash.update(stringToSign);
            _g = toHex;
            return [4
            /*yield*/
            , hash.digest()];

          case 6:
            return [2
            /*return*/
            , _g.apply(void 0, [_h.sent()])];
        }
      });
    });
  };

  SignatureV4.prototype.signRequest = function (requestToSign, _a) {
    var _b = _a === void 0 ? {} : _a,
        _c = _b.signingDate,
        signingDate = _c === void 0 ? new Date() : _c,
        signableHeaders = _b.signableHeaders,
        unsignableHeaders = _b.unsignableHeaders,
        signingRegion = _b.signingRegion,
        signingService = _b.signingService;

    return __awaiter$1(this, void 0, void 0, function () {
      var credentials, region, _d, request, _e, longDate, shortDate, scope, payloadHash, canonicalHeaders, signature;

      return __generator$1(this, function (_f) {
        switch (_f.label) {
          case 0:
            return [4
            /*yield*/
            , this.credentialProvider()];

          case 1:
            credentials = _f.sent();
            if (!(signingRegion !== null && signingRegion !== void 0)) return [3
            /*break*/
            , 2];
            _d = signingRegion;
            return [3
            /*break*/
            , 4];

          case 2:
            return [4
            /*yield*/
            , this.regionProvider()];

          case 3:
            _d = _f.sent();
            _f.label = 4;

          case 4:
            region = _d;
            request = prepareRequest(requestToSign);
            _e = formatDate(signingDate), longDate = _e.longDate, shortDate = _e.shortDate;
            scope = createScope(shortDate, region, signingService !== null && signingService !== void 0 ? signingService : this.service);
            request.headers[AMZ_DATE_HEADER] = longDate;

            if (credentials.sessionToken) {
              request.headers[TOKEN_HEADER] = credentials.sessionToken;
            }

            return [4
            /*yield*/
            , getPayloadHash(request, this.sha256)];

          case 5:
            payloadHash = _f.sent();

            if (!hasHeader(SHA256_HEADER, request.headers) && this.applyChecksum) {
              request.headers[SHA256_HEADER] = payloadHash;
            }

            canonicalHeaders = getCanonicalHeaders(request, unsignableHeaders, signableHeaders);
            return [4
            /*yield*/
            , this.getSignature(longDate, scope, this.getSigningKey(credentials, region, shortDate, signingService), this.createCanonicalRequest(request, canonicalHeaders, payloadHash))];

          case 6:
            signature = _f.sent();
            request.headers[AUTH_HEADER] = ALGORITHM_IDENTIFIER + " " + ("Credential=" + credentials.accessKeyId + "/" + scope + ", ") + ("SignedHeaders=" + getCanonicalHeaderList(canonicalHeaders) + ", ") + ("Signature=" + signature);
            return [2
            /*return*/
            , request];
        }
      });
    });
  };

  SignatureV4.prototype.createCanonicalRequest = function (request, canonicalHeaders, payloadHash) {
    var sortedHeaders = Object.keys(canonicalHeaders).sort();
    return request.method + "\n" + this.getCanonicalPath(request) + "\n" + getCanonicalQuery(request) + "\n" + sortedHeaders.map(function (name) {
      return name + ":" + canonicalHeaders[name];
    }).join("\n") + "\n\n" + sortedHeaders.join(";") + "\n" + payloadHash;
  };

  SignatureV4.prototype.createStringToSign = function (longDate, credentialScope, canonicalRequest) {
    return __awaiter$1(this, void 0, void 0, function () {
      var hash, hashedRequest;
      return __generator$1(this, function (_a) {
        switch (_a.label) {
          case 0:
            hash = new this.sha256();
            hash.update(canonicalRequest);
            return [4
            /*yield*/
            , hash.digest()];

          case 1:
            hashedRequest = _a.sent();
            return [2
            /*return*/
            , ALGORITHM_IDENTIFIER + "\n" + longDate + "\n" + credentialScope + "\n" + toHex(hashedRequest)];
        }
      });
    });
  };

  SignatureV4.prototype.getCanonicalPath = function (_a) {
    var path = _a.path;

    if (this.uriEscapePath) {
      var doubleEncoded = encodeURIComponent(path.replace(/^\//, ""));
      return "/" + doubleEncoded.replace(/%2F/g, "/");
    }

    return path;
  };

  SignatureV4.prototype.getSignature = function (longDate, credentialScope, keyPromise, canonicalRequest) {
    return __awaiter$1(this, void 0, void 0, function () {
      var stringToSign, hash, _a, _b, _c;

      return __generator$1(this, function (_d) {
        switch (_d.label) {
          case 0:
            return [4
            /*yield*/
            , this.createStringToSign(longDate, credentialScope, canonicalRequest)];

          case 1:
            stringToSign = _d.sent();
            _b = (_a = this.sha256).bind;
            return [4
            /*yield*/
            , keyPromise];

          case 2:
            hash = new (_b.apply(_a, [void 0, _d.sent()]))();
            hash.update(stringToSign);
            _c = toHex;
            return [4
            /*yield*/
            , hash.digest()];

          case 3:
            return [2
            /*return*/
            , _c.apply(void 0, [_d.sent()])];
        }
      });
    });
  };

  SignatureV4.prototype.getSigningKey = function (credentials, region, shortDate, service) {
    return getSigningKey(this.sha256, credentials, shortDate, region, service || this.service);
  };

  return SignatureV4;
}();

var formatDate = function (now) {
  var longDate = iso8601(now).replace(/[\-:]/g, "");
  return {
    longDate: longDate,
    shortDate: longDate.substr(0, 8)
  };
};

var getCanonicalHeaderList = function (headers) {
  return Object.keys(headers).sort().join(";");
};

var normalizeRegionProvider = function (region) {
  if (typeof region === "string") {
    var promisified_1 = Promise.resolve(region);
    return function () {
      return promisified_1;
    };
  } else {
    return region;
  }
};

var normalizeCredentialsProvider = function (credentials) {
  if (typeof credentials === "object") {
    var promisified_2 = Promise.resolve(credentials);
    return function () {
      return promisified_2;
    };
  } else {
    return credentials;
  }
};

function resolveAwsAuthConfig(input) {
  var _this = this;

  var credentials = input.credentials || input.credentialDefaultProvider(input);
  var normalizedCreds = normalizeProvider(credentials);
  var _a = input.signingEscapePath,
      signingEscapePath = _a === void 0 ? true : _a,
      _b = input.systemClockOffset,
      systemClockOffset = _b === void 0 ? input.systemClockOffset || 0 : _b,
      sha256 = input.sha256;
  var signer;

  if (input.signer) {
    //if signer is supplied by user, normalize it to a function returning a promise for signer.
    signer = normalizeProvider(input.signer);
  } else {
    //construct a provider inferring signing from region.
    signer = function () {
      return normalizeProvider(input.region)().then(function (region) {
        return __awaiter$1(_this, void 0, void 0, function () {
          return __generator$1(this, function (_a) {
            switch (_a.label) {
              case 0:
                return [4
                /*yield*/
                , input.regionInfoProvider(region)];

              case 1:
                return [2
                /*return*/
                , [_a.sent() || {}, region]];
            }
          });
        });
      }).then(function (_a) {
        var _b = __read(_a, 2),
            regionInfo = _b[0],
            region = _b[1];

        var signingRegion = regionInfo.signingRegion,
            signingService = regionInfo.signingService; //update client's singing region and signing service config if they are resolved.
        //signing region resolving order: user supplied signingRegion -> endpoints.json inferred region -> client region

        input.signingRegion = input.signingRegion || signingRegion || region; //signing name resolving order:
        //user supplied signingName -> endpoints.json inferred (credential scope -> model arnNamespace) -> model service id

        input.signingName = input.signingName || signingService || input.serviceId;
        return new SignatureV4({
          credentials: normalizedCreds,
          region: input.signingRegion,
          service: input.signingName,
          sha256: sha256,
          uriEscapePath: signingEscapePath
        });
      });
    };
  }

  return __assign$1(__assign$1({}, input), {
    systemClockOffset: systemClockOffset,
    signingEscapePath: signingEscapePath,
    credentials: normalizedCreds,
    signer: signer
  });
}

function normalizeProvider(input) {
  if (typeof input === "object") {
    var promisified_1 = Promise.resolve(input);
    return function () {
      return promisified_1;
    };
  }

  return input;
}

var isClockSkewed = function (newServerTime, systemClockOffset) {
  return Math.abs(getSkewCorrectedDate(systemClockOffset).getTime() - newServerTime) >= 300000;
};

var getSkewCorrectedDate = function (systemClockOffset) {
  return new Date(Date.now() + systemClockOffset);
};

function awsAuthMiddleware(options) {
  return function (next, context) {
    return function (args) {
      return __awaiter$1(this, void 0, void 0, function () {
        var signer, _a, output, _b, _c, headers, dateHeader, serverTime;

        var _d;

        return __generator$1(this, function (_e) {
          switch (_e.label) {
            case 0:
              if (!HttpRequest.isInstance(args.request)) return [2
              /*return*/
              , next(args)];
              if (!(typeof options.signer === "function")) return [3
              /*break*/
              , 2];
              return [4
              /*yield*/
              , options.signer()];

            case 1:
              _a = _e.sent();
              return [3
              /*break*/
              , 3];

            case 2:
              _a = options.signer;
              _e.label = 3;

            case 3:
              signer = _a;
              _b = next;
              _c = [__assign$1({}, args)];
              _d = {};
              return [4
              /*yield*/
              , signer.sign(args.request, {
                signingDate: new Date(Date.now() + options.systemClockOffset),
                signingRegion: context["signing_region"],
                signingService: context["signing_service"]
              })];

            case 4:
              return [4
              /*yield*/
              , _b.apply(void 0, [__assign$1.apply(void 0, _c.concat([(_d.request = _e.sent(), _d)]))])];

            case 5:
              output = _e.sent();
              headers = output.response.headers;
              dateHeader = headers && (headers.date || headers.Date);

              if (dateHeader) {
                serverTime = Date.parse(dateHeader);

                if (isClockSkewed(serverTime, options.systemClockOffset)) {
                  options.systemClockOffset = serverTime - Date.now();
                }
              }

              return [2
              /*return*/
              , output];
          }
        });
      });
    };
  };
}
var awsAuthMiddlewareOptions = {
  name: "awsAuthMiddleware",
  tags: ["SIGNATURE", "AWSAUTH"],
  relation: "after",
  toMiddleware: "retryMiddleware",
  override: true
};
var getAwsAuthPlugin = function (options) {
  return {
    applyToStack: function (clientStack) {
      clientStack.addRelativeTo(awsAuthMiddleware(options), awsAuthMiddlewareOptions);
    }
  };
};

function resolveUserAgentConfig(input) {
  return __assign$1(__assign$1({}, input), {
    customUserAgent: typeof input.customUserAgent === "string" ? [[input.customUserAgent]] : input.customUserAgent
  });
}

var USER_AGENT = "user-agent";
var X_AMZ_USER_AGENT = "x-amz-user-agent";
var SPACE = " ";
var UA_ESCAPE_REGEX = /[^\!\#\$\%\&\'\*\+\-\.\^\_\`\|\~\d\w]/g;

/**
 * Build user agent header sections from:
 * 1. runtime-specific default user agent provider;
 * 2. custom user agent from `customUserAgent` client config;
 * 3. handler execution context set by internal SDK components;
 * The built user agent will be set to `x-amz-user-agent` header for ALL the
 * runtimes.
 * Please note that any override to the `user-agent` or `x-amz-user-agent` header
 * in the HTTP request is discouraged. Please use `customUserAgent` client
 * config or middleware setting the `userAgent` context to generate desired user
 * agent.
 */

var userAgentMiddleware = function (options) {
  return function (next, context) {
    return function (args) {
      return __awaiter$1(void 0, void 0, void 0, function () {
        var request, headers, userAgent, defaultUserAgent, customUserAgent, normalUAValue;

        var _a, _b;

        return __generator$1(this, function (_c) {
          switch (_c.label) {
            case 0:
              request = args.request;
              if (!HttpRequest.isInstance(request)) return [2
              /*return*/
              , next(args)];
              headers = request.headers;
              userAgent = ((_a = context === null || context === void 0 ? void 0 : context.userAgent) === null || _a === void 0 ? void 0 : _a.map(escapeUserAgent)) || [];
              return [4
              /*yield*/
              , options.defaultUserAgentProvider()];

            case 1:
              defaultUserAgent = _c.sent().map(escapeUserAgent);
              customUserAgent = ((_b = options === null || options === void 0 ? void 0 : options.customUserAgent) === null || _b === void 0 ? void 0 : _b.map(escapeUserAgent)) || []; // Set value to AWS-specific user agent header

              headers[X_AMZ_USER_AGENT] = __spread(defaultUserAgent, userAgent, customUserAgent).join(SPACE);
              normalUAValue = __spread(defaultUserAgent.filter(function (section) {
                return section.startsWith("aws-sdk-");
              }), customUserAgent).join(SPACE);

              if (options.runtime !== "browser" && normalUAValue) {
                headers[USER_AGENT] = headers[USER_AGENT] ? headers[USER_AGENT] + " " + normalUAValue : normalUAValue;
              }

              return [2
              /*return*/
              , next(__assign$1(__assign$1({}, args), {
                request: request
              }))];
          }
        });
      });
    };
  };
};
/**
 * Escape the each pair according to https://tools.ietf.org/html/rfc5234 and join the pair with pattern `name/version`.
 * User agent name may include prefix like `md/`, `api/`, `os/` etc., we should not escape the `/` after the prefix.
 * @private
 */

var escapeUserAgent = function (_a) {
  var _b = __read(_a, 2),
      name = _b[0],
      version = _b[1];

  var prefixSeparatorIndex = name.indexOf("/");
  var prefix = name.substring(0, prefixSeparatorIndex); // If no prefix, prefix is just ""

  var uaName = name.substring(prefixSeparatorIndex + 1);

  if (prefix === "api") {
    uaName = uaName.toLowerCase();
  }

  return [prefix, uaName, version].filter(function (item) {
    return item && item.length > 0;
  }).map(function (item) {
    return item === null || item === void 0 ? void 0 : item.replace(UA_ESCAPE_REGEX, "_");
  }).join("/");
};

var getUserAgentMiddlewareOptions = {
  name: "getUserAgentMiddleware",
  step: "build",
  priority: "low",
  tags: ["SET_USER_AGENT", "USER_AGENT"],
  override: true
};
var getUserAgentPlugin = function (config) {
  return {
    applyToStack: function (clientStack) {
      clientStack.add(userAgentMiddleware(config), getUserAgentMiddlewareOptions);
    }
  };
};

var constructStack = function () {
  var absoluteEntries = [];
  var relativeEntries = [];
  var entriesNameSet = new Set();

  var sort = function (entries) {
    return entries.sort(function (a, b) {
      return stepWeights[b.step] - stepWeights[a.step] || priorityWeights[b.priority || "normal"] - priorityWeights[a.priority || "normal"];
    });
  };

  var removeByName = function (toRemove) {
    var isRemoved = false;

    var filterCb = function (entry) {
      if (entry.name && entry.name === toRemove) {
        isRemoved = true;
        entriesNameSet.delete(toRemove);
        return false;
      }

      return true;
    };

    absoluteEntries = absoluteEntries.filter(filterCb);
    relativeEntries = relativeEntries.filter(filterCb);
    return isRemoved;
  };

  var removeByReference = function (toRemove) {
    var isRemoved = false;

    var filterCb = function (entry) {
      if (entry.middleware === toRemove) {
        isRemoved = true;
        if (entry.name) entriesNameSet.delete(entry.name);
        return false;
      }

      return true;
    };

    absoluteEntries = absoluteEntries.filter(filterCb);
    relativeEntries = relativeEntries.filter(filterCb);
    return isRemoved;
  };

  var cloneTo = function (toStack) {
    absoluteEntries.forEach(function (entry) {
      //@ts-ignore
      toStack.add(entry.middleware, __assign$1({}, entry));
    });
    relativeEntries.forEach(function (entry) {
      //@ts-ignore
      toStack.addRelativeTo(entry.middleware, __assign$1({}, entry));
    });
    return toStack;
  };

  var expandRelativeMiddlewareList = function (from) {
    var expandedMiddlewareList = [];
    from.before.forEach(function (entry) {
      if (entry.before.length === 0 && entry.after.length === 0) {
        expandedMiddlewareList.push(entry);
      } else {
        expandedMiddlewareList.push.apply(expandedMiddlewareList, __spread(expandRelativeMiddlewareList(entry)));
      }
    });
    expandedMiddlewareList.push(from);
    from.after.reverse().forEach(function (entry) {
      if (entry.before.length === 0 && entry.after.length === 0) {
        expandedMiddlewareList.push(entry);
      } else {
        expandedMiddlewareList.push.apply(expandedMiddlewareList, __spread(expandRelativeMiddlewareList(entry)));
      }
    });
    return expandedMiddlewareList;
  };
  /**
   * Get a final list of middleware in the order of being executed in the resolved handler.
   */


  var getMiddlewareList = function () {
    var normalizedAbsoluteEntries = [];
    var normalizedRelativeEntries = [];
    var normalizedEntriesNameMap = {};
    absoluteEntries.forEach(function (entry) {
      var normalizedEntry = __assign$1(__assign$1({}, entry), {
        before: [],
        after: []
      });

      if (normalizedEntry.name) normalizedEntriesNameMap[normalizedEntry.name] = normalizedEntry;
      normalizedAbsoluteEntries.push(normalizedEntry);
    });
    relativeEntries.forEach(function (entry) {
      var normalizedEntry = __assign$1(__assign$1({}, entry), {
        before: [],
        after: []
      });

      if (normalizedEntry.name) normalizedEntriesNameMap[normalizedEntry.name] = normalizedEntry;
      normalizedRelativeEntries.push(normalizedEntry);
    });
    normalizedRelativeEntries.forEach(function (entry) {
      if (entry.toMiddleware) {
        var toMiddleware = normalizedEntriesNameMap[entry.toMiddleware];

        if (toMiddleware === undefined) {
          throw new Error(entry.toMiddleware + " is not found when adding " + (entry.name || "anonymous") + " middleware " + entry.relation + " " + entry.toMiddleware);
        }

        if (entry.relation === "after") {
          toMiddleware.after.push(entry);
        }

        if (entry.relation === "before") {
          toMiddleware.before.push(entry);
        }
      }
    });
    var mainChain = sort(normalizedAbsoluteEntries).map(expandRelativeMiddlewareList).reduce(function (wholeList, expendedMiddlewareList) {
      // TODO: Replace it with Array.flat();
      wholeList.push.apply(wholeList, __spread(expendedMiddlewareList));
      return wholeList;
    }, []);
    return mainChain.map(function (entry) {
      return entry.middleware;
    });
  };

  var stack = {
    add: function (middleware, options) {
      if (options === void 0) {
        options = {};
      }

      var name = options.name,
          override = options.override;

      var entry = __assign$1({
        step: "initialize",
        priority: "normal",
        middleware: middleware
      }, options);

      if (name) {
        if (entriesNameSet.has(name)) {
          if (!override) throw new Error("Duplicate middleware name '" + name + "'");
          var toOverrideIndex = absoluteEntries.findIndex(function (entry) {
            return entry.name === name;
          });
          var toOverride = absoluteEntries[toOverrideIndex];

          if (toOverride.step !== entry.step || toOverride.priority !== entry.priority) {
            throw new Error("\"" + name + "\" middleware with " + toOverride.priority + " priority in " + toOverride.step + " step cannot be " + ("overridden by same-name middleware with " + entry.priority + " priority in " + entry.step + " step."));
          }

          absoluteEntries.splice(toOverrideIndex, 1);
        }

        entriesNameSet.add(name);
      }

      absoluteEntries.push(entry);
    },
    addRelativeTo: function (middleware, options) {
      var name = options.name,
          override = options.override;

      var entry = __assign$1({
        middleware: middleware
      }, options);

      if (name) {
        if (entriesNameSet.has(name)) {
          if (!override) throw new Error("Duplicate middleware name '" + name + "'");
          var toOverrideIndex = relativeEntries.findIndex(function (entry) {
            return entry.name === name;
          });
          var toOverride = relativeEntries[toOverrideIndex];

          if (toOverride.toMiddleware !== entry.toMiddleware || toOverride.relation !== entry.relation) {
            throw new Error("\"" + name + "\" middleware " + toOverride.relation + " \"" + toOverride.toMiddleware + "\" middleware cannot be overridden " + ("by same-name middleware " + entry.relation + " \"" + entry.toMiddleware + "\" middleware."));
          }

          relativeEntries.splice(toOverrideIndex, 1);
        }

        entriesNameSet.add(name);
      }

      relativeEntries.push(entry);
    },
    clone: function () {
      return cloneTo(constructStack());
    },
    use: function (plugin) {
      plugin.applyToStack(stack);
    },
    remove: function (toRemove) {
      if (typeof toRemove === "string") return removeByName(toRemove);else return removeByReference(toRemove);
    },
    removeByTag: function (toRemove) {
      var isRemoved = false;

      var filterCb = function (entry) {
        var tags = entry.tags,
            name = entry.name;

        if (tags && tags.includes(toRemove)) {
          if (name) entriesNameSet.delete(name);
          isRemoved = true;
          return false;
        }

        return true;
      };

      absoluteEntries = absoluteEntries.filter(filterCb);
      relativeEntries = relativeEntries.filter(filterCb);
      return isRemoved;
    },
    concat: function (from) {
      var cloned = cloneTo(constructStack());
      cloned.use(from);
      return cloned;
    },
    applyToStack: cloneTo,
    resolve: function (handler, context) {
      var e_1, _a;

      try {
        for (var _b = __values(getMiddlewareList().reverse()), _c = _b.next(); !_c.done; _c = _b.next()) {
          var middleware = _c.value;
          handler = middleware(handler, context);
        }
      } catch (e_1_1) {
        e_1 = {
          error: e_1_1
        };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        } finally {
          if (e_1) throw e_1.error;
        }
      }

      return handler;
    }
  };
  return stack;
};
var stepWeights = {
  initialize: 5,
  serialize: 4,
  build: 3,
  finalizeRequest: 2,
  deserialize: 1
};
var priorityWeights = {
  high: 3,
  normal: 2,
  low: 1
};

var Client =
/** @class */
function () {
  function Client(config) {
    this.middlewareStack = constructStack();
    this.config = config;
  }

  Client.prototype.send = function (command, optionsOrCb, cb) {
    var options = typeof optionsOrCb !== "function" ? optionsOrCb : undefined;
    var callback = typeof optionsOrCb === "function" ? optionsOrCb : cb;
    var handler = command.resolveMiddleware(this.middlewareStack, this.config, options);

    if (callback) {
      handler(command).then(function (result) {
        return callback(null, result.output);
      }, function (err) {
        return callback(err);
      }).catch( // prevent any errors thrown in the callback from triggering an
      // unhandled promise rejection
      function () {});
    } else {
      return handler(command).then(function (result) {
        return result.output;
      });
    }
  };

  Client.prototype.destroy = function () {
    if (this.config.requestHandler.destroy) this.config.requestHandler.destroy();
  };

  return Client;
}();

var Command =
/** @class */
function () {
  function Command() {
    this.middlewareStack = constructStack();
  }

  return Command;
}();

/**
 * Function that wraps encodeURIComponent to encode additional characters
 * to fully adhere to RFC 3986.
 */
function extendedEncodeURIComponent(str) {
  return encodeURIComponent(str).replace(/[!'()*]/g, function (c) {
    return "%" + c.charCodeAt(0).toString(16);
  });
}

/**
 * Recursively parses object and populates value is node from
 * "#text" key if it's available
 */
var getValueFromTextNode = function (obj) {
  var textNodeName = "#text";

  for (var key in obj) {
    if (obj.hasOwnProperty(key) && obj[key][textNodeName] !== undefined) {
      obj[key] = obj[key][textNodeName];
    } else if (typeof obj[key] === "object" && obj[key] !== null) {
      obj[key] = getValueFromTextNode(obj[key]);
    }
  }

  return obj;
};

/**
 * Lazy String holder for JSON typed contents.
 */
/**
 * Because of https://github.com/microsoft/tslib/issues/95,
 * TS 'extends' shim doesn't support extending native types like String.
 * So here we create StringWrapper that duplicate everything from String
 * class including its prototype chain. So we can extend from here.
 */
// @ts-ignore StringWrapper implementation is not a simple constructor

var StringWrapper = function () {
  //@ts-ignore 'this' cannot be assigned to any, but Object.getPrototypeOf accepts any
  var Class = Object.getPrototypeOf(this).constructor;
  var Constructor = Function.bind.apply(String, __spread([null], arguments)); //@ts-ignore Call wrapped String constructor directly, don't bother typing it.

  var instance = new Constructor();
  Object.setPrototypeOf(instance, Class.prototype);
  return instance;
};
StringWrapper.prototype = Object.create(String.prototype, {
  constructor: {
    value: StringWrapper,
    enumerable: false,
    writable: true,
    configurable: true
  }
});
Object.setPrototypeOf(StringWrapper, String);

/** @class */
(function (_super) {
  __extends$1(LazyJsonString, _super);

  function LazyJsonString() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  LazyJsonString.prototype.deserializeJSON = function () {
    return JSON.parse(_super.prototype.toString.call(this));
  };

  LazyJsonString.prototype.toJSON = function () {
    return _super.prototype.toString.call(this);
  };

  LazyJsonString.fromObject = function (object) {
    if (object instanceof LazyJsonString) {
      return object;
    } else if (object instanceof String || typeof object === "string") {
      return new LazyJsonString(object);
    }

    return new LazyJsonString(JSON.stringify(object));
  };

  return LazyJsonString;
})(StringWrapper);

/**
 * Builds a proper UTC HttpDate timestamp from a Date object
 * since not all environments will have this as the expected
 * format.
 *
 * See: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/toUTCString
 * > Prior to ECMAScript 2018, the format of the return value
 * > varied according to the platform. The most common return
 * > value was an RFC-1123 formatted date stamp, which is a
 * > slightly updated version of RFC-822 date stamps.
 */
// Build indexes outside so we allocate them once.
var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]; // prettier-ignore

var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function dateToUtcString(date) {
  var year = date.getUTCFullYear();
  var month = date.getUTCMonth();
  var dayOfWeek = date.getUTCDay();
  var dayOfMonthInt = date.getUTCDate();
  var hoursInt = date.getUTCHours();
  var minutesInt = date.getUTCMinutes();
  var secondsInt = date.getUTCSeconds(); // Build 0 prefixed strings for contents that need to be
  // two digits and where we get an integer back.

  var dayOfMonthString = dayOfMonthInt < 10 ? "0" + dayOfMonthInt : "" + dayOfMonthInt;
  var hoursString = hoursInt < 10 ? "0" + hoursInt : "" + hoursInt;
  var minutesString = minutesInt < 10 ? "0" + minutesInt : "" + minutesInt;
  var secondsString = secondsInt < 10 ? "0" + secondsInt : "" + secondsInt;
  return days[dayOfWeek] + ", " + dayOfMonthString + " " + months[month] + " " + year + " " + hoursString + ":" + minutesString + ":" + secondsString + " GMT";
}

var SENSITIVE_STRING = "***SensitiveInformation***";

/**
 * <p></p>
 */

var S3Client =
/** @class */
function (_super) {
  __extends(S3Client, _super);

  function S3Client(configuration) {
    var _this = this;

    var _config_0 = __assign(__assign({}, ClientDefaultValues), configuration);

    var _config_1 = resolveRegionConfig(_config_0);

    var _config_2 = resolveEndpointsConfig(_config_1);

    var _config_3 = resolveAwsAuthConfig(_config_2);

    var _config_4 = resolveRetryConfig(_config_3);

    var _config_5 = resolveHostHeaderConfig(_config_4);

    var _config_6 = resolveBucketEndpointConfig(_config_5);

    var _config_7 = resolveUserAgentConfig(_config_6);

    var _config_8 = resolveEventStreamSerdeConfig(_config_7);

    _this = _super.call(this, _config_8) || this;
    _this.config = _config_8;

    _this.middlewareStack.use(getAwsAuthPlugin(_this.config));

    _this.middlewareStack.use(getRetryPlugin(_this.config));

    _this.middlewareStack.use(getContentLengthPlugin(_this.config));

    _this.middlewareStack.use(getHostHeaderPlugin(_this.config));

    _this.middlewareStack.use(getLoggerPlugin(_this.config));

    _this.middlewareStack.use(getValidateBucketNamePlugin(_this.config));

    _this.middlewareStack.use(getUseRegionalEndpointPlugin(_this.config));

    _this.middlewareStack.use(getAddExpectContinuePlugin(_this.config));

    _this.middlewareStack.use(getUserAgentPlugin(_this.config));

    return _this;
  }

  S3Client.prototype.destroy = function () {
    _super.prototype.destroy.call(this);
  };

  return S3Client;
}(Client);

var AbortIncompleteMultipartUpload;

(function (AbortIncompleteMultipartUpload) {
  AbortIncompleteMultipartUpload.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(AbortIncompleteMultipartUpload || (AbortIncompleteMultipartUpload = {}));

var AbortMultipartUploadOutput;

(function (AbortMultipartUploadOutput) {
  AbortMultipartUploadOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(AbortMultipartUploadOutput || (AbortMultipartUploadOutput = {}));

var AbortMultipartUploadRequest;

(function (AbortMultipartUploadRequest) {
  AbortMultipartUploadRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(AbortMultipartUploadRequest || (AbortMultipartUploadRequest = {}));

var NoSuchUpload;

(function (NoSuchUpload) {
  NoSuchUpload.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(NoSuchUpload || (NoSuchUpload = {}));

var AccelerateConfiguration;

(function (AccelerateConfiguration) {
  AccelerateConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(AccelerateConfiguration || (AccelerateConfiguration = {}));

var Grantee;

(function (Grantee) {
  Grantee.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Grantee || (Grantee = {}));

var Grant;

(function (Grant) {
  Grant.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Grant || (Grant = {}));

var Owner;

(function (Owner) {
  Owner.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Owner || (Owner = {}));

var AccessControlPolicy;

(function (AccessControlPolicy) {
  AccessControlPolicy.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(AccessControlPolicy || (AccessControlPolicy = {}));

var AccessControlTranslation;

(function (AccessControlTranslation) {
  AccessControlTranslation.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(AccessControlTranslation || (AccessControlTranslation = {}));

var CompleteMultipartUploadOutput;

(function (CompleteMultipartUploadOutput) {
  CompleteMultipartUploadOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.SSEKMSKeyId && {
      SSEKMSKeyId: SENSITIVE_STRING
    });
  };
})(CompleteMultipartUploadOutput || (CompleteMultipartUploadOutput = {}));

var CompletedPart;

(function (CompletedPart) {
  CompletedPart.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(CompletedPart || (CompletedPart = {}));

var CompletedMultipartUpload;

(function (CompletedMultipartUpload) {
  CompletedMultipartUpload.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(CompletedMultipartUpload || (CompletedMultipartUpload = {}));

var CompleteMultipartUploadRequest;

(function (CompleteMultipartUploadRequest) {
  CompleteMultipartUploadRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(CompleteMultipartUploadRequest || (CompleteMultipartUploadRequest = {}));

var CopyObjectResult;

(function (CopyObjectResult) {
  CopyObjectResult.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(CopyObjectResult || (CopyObjectResult = {}));

var CopyObjectOutput;

(function (CopyObjectOutput) {
  CopyObjectOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign(__assign({}, obj), obj.SSEKMSKeyId && {
      SSEKMSKeyId: SENSITIVE_STRING
    }), obj.SSEKMSEncryptionContext && {
      SSEKMSEncryptionContext: SENSITIVE_STRING
    });
  };
})(CopyObjectOutput || (CopyObjectOutput = {}));

var CopyObjectRequest;

(function (CopyObjectRequest) {
  CopyObjectRequest.filterSensitiveLog = function (obj) {
    return __assign(__assign(__assign(__assign(__assign({}, obj), obj.SSECustomerKey && {
      SSECustomerKey: SENSITIVE_STRING
    }), obj.SSEKMSKeyId && {
      SSEKMSKeyId: SENSITIVE_STRING
    }), obj.SSEKMSEncryptionContext && {
      SSEKMSEncryptionContext: SENSITIVE_STRING
    }), obj.CopySourceSSECustomerKey && {
      CopySourceSSECustomerKey: SENSITIVE_STRING
    });
  };
})(CopyObjectRequest || (CopyObjectRequest = {}));

var ObjectNotInActiveTierError;

(function (ObjectNotInActiveTierError) {
  ObjectNotInActiveTierError.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ObjectNotInActiveTierError || (ObjectNotInActiveTierError = {}));

var BucketAlreadyExists;

(function (BucketAlreadyExists) {
  BucketAlreadyExists.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(BucketAlreadyExists || (BucketAlreadyExists = {}));

var BucketAlreadyOwnedByYou;

(function (BucketAlreadyOwnedByYou) {
  BucketAlreadyOwnedByYou.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(BucketAlreadyOwnedByYou || (BucketAlreadyOwnedByYou = {}));

var CreateBucketOutput;

(function (CreateBucketOutput) {
  CreateBucketOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(CreateBucketOutput || (CreateBucketOutput = {}));

var CreateBucketConfiguration;

(function (CreateBucketConfiguration) {
  CreateBucketConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(CreateBucketConfiguration || (CreateBucketConfiguration = {}));

var CreateBucketRequest;

(function (CreateBucketRequest) {
  CreateBucketRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(CreateBucketRequest || (CreateBucketRequest = {}));

var CreateMultipartUploadOutput;

(function (CreateMultipartUploadOutput) {
  CreateMultipartUploadOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign(__assign({}, obj), obj.SSEKMSKeyId && {
      SSEKMSKeyId: SENSITIVE_STRING
    }), obj.SSEKMSEncryptionContext && {
      SSEKMSEncryptionContext: SENSITIVE_STRING
    });
  };
})(CreateMultipartUploadOutput || (CreateMultipartUploadOutput = {}));

var CreateMultipartUploadRequest;

(function (CreateMultipartUploadRequest) {
  CreateMultipartUploadRequest.filterSensitiveLog = function (obj) {
    return __assign(__assign(__assign(__assign({}, obj), obj.SSECustomerKey && {
      SSECustomerKey: SENSITIVE_STRING
    }), obj.SSEKMSKeyId && {
      SSEKMSKeyId: SENSITIVE_STRING
    }), obj.SSEKMSEncryptionContext && {
      SSEKMSEncryptionContext: SENSITIVE_STRING
    });
  };
})(CreateMultipartUploadRequest || (CreateMultipartUploadRequest = {}));

var DeleteBucketRequest;

(function (DeleteBucketRequest) {
  DeleteBucketRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketRequest || (DeleteBucketRequest = {}));

var DeleteBucketAnalyticsConfigurationRequest;

(function (DeleteBucketAnalyticsConfigurationRequest) {
  DeleteBucketAnalyticsConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketAnalyticsConfigurationRequest || (DeleteBucketAnalyticsConfigurationRequest = {}));

var DeleteBucketCorsRequest;

(function (DeleteBucketCorsRequest) {
  DeleteBucketCorsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketCorsRequest || (DeleteBucketCorsRequest = {}));

var DeleteBucketEncryptionRequest;

(function (DeleteBucketEncryptionRequest) {
  DeleteBucketEncryptionRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketEncryptionRequest || (DeleteBucketEncryptionRequest = {}));

var DeleteBucketIntelligentTieringConfigurationRequest;

(function (DeleteBucketIntelligentTieringConfigurationRequest) {
  DeleteBucketIntelligentTieringConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketIntelligentTieringConfigurationRequest || (DeleteBucketIntelligentTieringConfigurationRequest = {}));

var DeleteBucketInventoryConfigurationRequest;

(function (DeleteBucketInventoryConfigurationRequest) {
  DeleteBucketInventoryConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketInventoryConfigurationRequest || (DeleteBucketInventoryConfigurationRequest = {}));

var DeleteBucketLifecycleRequest;

(function (DeleteBucketLifecycleRequest) {
  DeleteBucketLifecycleRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketLifecycleRequest || (DeleteBucketLifecycleRequest = {}));

var DeleteBucketMetricsConfigurationRequest;

(function (DeleteBucketMetricsConfigurationRequest) {
  DeleteBucketMetricsConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketMetricsConfigurationRequest || (DeleteBucketMetricsConfigurationRequest = {}));

var DeleteBucketOwnershipControlsRequest;

(function (DeleteBucketOwnershipControlsRequest) {
  DeleteBucketOwnershipControlsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketOwnershipControlsRequest || (DeleteBucketOwnershipControlsRequest = {}));

var DeleteBucketPolicyRequest;

(function (DeleteBucketPolicyRequest) {
  DeleteBucketPolicyRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketPolicyRequest || (DeleteBucketPolicyRequest = {}));

var DeleteBucketReplicationRequest;

(function (DeleteBucketReplicationRequest) {
  DeleteBucketReplicationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketReplicationRequest || (DeleteBucketReplicationRequest = {}));

var DeleteBucketTaggingRequest;

(function (DeleteBucketTaggingRequest) {
  DeleteBucketTaggingRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketTaggingRequest || (DeleteBucketTaggingRequest = {}));

var DeleteBucketWebsiteRequest;

(function (DeleteBucketWebsiteRequest) {
  DeleteBucketWebsiteRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteBucketWebsiteRequest || (DeleteBucketWebsiteRequest = {}));

var DeleteObjectOutput;

(function (DeleteObjectOutput) {
  DeleteObjectOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteObjectOutput || (DeleteObjectOutput = {}));

var DeleteObjectRequest;

(function (DeleteObjectRequest) {
  DeleteObjectRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteObjectRequest || (DeleteObjectRequest = {}));

var DeletedObject;

(function (DeletedObject) {
  DeletedObject.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeletedObject || (DeletedObject = {}));

var _Error;

(function (_Error) {
  _Error.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(_Error || (_Error = {}));

var DeleteObjectsOutput;

(function (DeleteObjectsOutput) {
  DeleteObjectsOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteObjectsOutput || (DeleteObjectsOutput = {}));

var ObjectIdentifier;

(function (ObjectIdentifier) {
  ObjectIdentifier.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ObjectIdentifier || (ObjectIdentifier = {}));

var Delete;

(function (Delete) {
  Delete.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Delete || (Delete = {}));

var DeleteObjectsRequest;

(function (DeleteObjectsRequest) {
  DeleteObjectsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteObjectsRequest || (DeleteObjectsRequest = {}));

var DeleteObjectTaggingOutput;

(function (DeleteObjectTaggingOutput) {
  DeleteObjectTaggingOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteObjectTaggingOutput || (DeleteObjectTaggingOutput = {}));

var DeleteObjectTaggingRequest;

(function (DeleteObjectTaggingRequest) {
  DeleteObjectTaggingRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteObjectTaggingRequest || (DeleteObjectTaggingRequest = {}));

var DeletePublicAccessBlockRequest;

(function (DeletePublicAccessBlockRequest) {
  DeletePublicAccessBlockRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeletePublicAccessBlockRequest || (DeletePublicAccessBlockRequest = {}));

var GetBucketAccelerateConfigurationOutput;

(function (GetBucketAccelerateConfigurationOutput) {
  GetBucketAccelerateConfigurationOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketAccelerateConfigurationOutput || (GetBucketAccelerateConfigurationOutput = {}));

var GetBucketAccelerateConfigurationRequest;

(function (GetBucketAccelerateConfigurationRequest) {
  GetBucketAccelerateConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketAccelerateConfigurationRequest || (GetBucketAccelerateConfigurationRequest = {}));

var GetBucketAclOutput;

(function (GetBucketAclOutput) {
  GetBucketAclOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketAclOutput || (GetBucketAclOutput = {}));

var GetBucketAclRequest;

(function (GetBucketAclRequest) {
  GetBucketAclRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketAclRequest || (GetBucketAclRequest = {}));

var Tag;

(function (Tag) {
  Tag.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Tag || (Tag = {}));

var AnalyticsAndOperator;

(function (AnalyticsAndOperator) {
  AnalyticsAndOperator.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(AnalyticsAndOperator || (AnalyticsAndOperator = {}));

var AnalyticsFilter;

(function (AnalyticsFilter) {
  AnalyticsFilter.visit = function (value, visitor) {
    if (value.Prefix !== undefined) return visitor.Prefix(value.Prefix);
    if (value.Tag !== undefined) return visitor.Tag(value.Tag);
    if (value.And !== undefined) return visitor.And(value.And);
    return visitor._(value.$unknown[0], value.$unknown[1]);
  };

  AnalyticsFilter.filterSensitiveLog = function (obj) {
    var _a;

    if (obj.Prefix !== undefined) return {
      Prefix: obj.Prefix
    };
    if (obj.Tag !== undefined) return {
      Tag: Tag.filterSensitiveLog(obj.Tag)
    };
    if (obj.And !== undefined) return {
      And: AnalyticsAndOperator.filterSensitiveLog(obj.And)
    };
    if (obj.$unknown !== undefined) return _a = {}, _a[obj.$unknown[0]] = "UNKNOWN", _a;
  };
})(AnalyticsFilter || (AnalyticsFilter = {}));

var AnalyticsS3BucketDestination;

(function (AnalyticsS3BucketDestination) {
  AnalyticsS3BucketDestination.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(AnalyticsS3BucketDestination || (AnalyticsS3BucketDestination = {}));

var AnalyticsExportDestination;

(function (AnalyticsExportDestination) {
  AnalyticsExportDestination.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(AnalyticsExportDestination || (AnalyticsExportDestination = {}));

var StorageClassAnalysisDataExport;

(function (StorageClassAnalysisDataExport) {
  StorageClassAnalysisDataExport.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(StorageClassAnalysisDataExport || (StorageClassAnalysisDataExport = {}));

var StorageClassAnalysis;

(function (StorageClassAnalysis) {
  StorageClassAnalysis.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(StorageClassAnalysis || (StorageClassAnalysis = {}));

var AnalyticsConfiguration;

(function (AnalyticsConfiguration) {
  AnalyticsConfiguration.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.Filter && {
      Filter: AnalyticsFilter.filterSensitiveLog(obj.Filter)
    });
  };
})(AnalyticsConfiguration || (AnalyticsConfiguration = {}));

var GetBucketAnalyticsConfigurationOutput;

(function (GetBucketAnalyticsConfigurationOutput) {
  GetBucketAnalyticsConfigurationOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.AnalyticsConfiguration && {
      AnalyticsConfiguration: AnalyticsConfiguration.filterSensitiveLog(obj.AnalyticsConfiguration)
    });
  };
})(GetBucketAnalyticsConfigurationOutput || (GetBucketAnalyticsConfigurationOutput = {}));

var GetBucketAnalyticsConfigurationRequest;

(function (GetBucketAnalyticsConfigurationRequest) {
  GetBucketAnalyticsConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketAnalyticsConfigurationRequest || (GetBucketAnalyticsConfigurationRequest = {}));

var CORSRule;

(function (CORSRule) {
  CORSRule.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(CORSRule || (CORSRule = {}));

var GetBucketCorsOutput;

(function (GetBucketCorsOutput) {
  GetBucketCorsOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketCorsOutput || (GetBucketCorsOutput = {}));

var GetBucketCorsRequest;

(function (GetBucketCorsRequest) {
  GetBucketCorsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketCorsRequest || (GetBucketCorsRequest = {}));

var ServerSideEncryptionByDefault;

(function (ServerSideEncryptionByDefault) {
  ServerSideEncryptionByDefault.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.KMSMasterKeyID && {
      KMSMasterKeyID: SENSITIVE_STRING
    });
  };
})(ServerSideEncryptionByDefault || (ServerSideEncryptionByDefault = {}));

var ServerSideEncryptionRule;

(function (ServerSideEncryptionRule) {
  ServerSideEncryptionRule.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.ApplyServerSideEncryptionByDefault && {
      ApplyServerSideEncryptionByDefault: ServerSideEncryptionByDefault.filterSensitiveLog(obj.ApplyServerSideEncryptionByDefault)
    });
  };
})(ServerSideEncryptionRule || (ServerSideEncryptionRule = {}));

var ServerSideEncryptionConfiguration;

(function (ServerSideEncryptionConfiguration) {
  ServerSideEncryptionConfiguration.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.Rules && {
      Rules: obj.Rules.map(function (item) {
        return ServerSideEncryptionRule.filterSensitiveLog(item);
      })
    });
  };
})(ServerSideEncryptionConfiguration || (ServerSideEncryptionConfiguration = {}));

var GetBucketEncryptionOutput;

(function (GetBucketEncryptionOutput) {
  GetBucketEncryptionOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.ServerSideEncryptionConfiguration && {
      ServerSideEncryptionConfiguration: ServerSideEncryptionConfiguration.filterSensitiveLog(obj.ServerSideEncryptionConfiguration)
    });
  };
})(GetBucketEncryptionOutput || (GetBucketEncryptionOutput = {}));

var GetBucketEncryptionRequest;

(function (GetBucketEncryptionRequest) {
  GetBucketEncryptionRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketEncryptionRequest || (GetBucketEncryptionRequest = {}));

var IntelligentTieringAndOperator;

(function (IntelligentTieringAndOperator) {
  IntelligentTieringAndOperator.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(IntelligentTieringAndOperator || (IntelligentTieringAndOperator = {}));

var IntelligentTieringFilter;

(function (IntelligentTieringFilter) {
  IntelligentTieringFilter.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(IntelligentTieringFilter || (IntelligentTieringFilter = {}));

var Tiering;

(function (Tiering) {
  Tiering.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Tiering || (Tiering = {}));

var IntelligentTieringConfiguration;

(function (IntelligentTieringConfiguration) {
  IntelligentTieringConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(IntelligentTieringConfiguration || (IntelligentTieringConfiguration = {}));

var GetBucketIntelligentTieringConfigurationOutput;

(function (GetBucketIntelligentTieringConfigurationOutput) {
  GetBucketIntelligentTieringConfigurationOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketIntelligentTieringConfigurationOutput || (GetBucketIntelligentTieringConfigurationOutput = {}));

var GetBucketIntelligentTieringConfigurationRequest;

(function (GetBucketIntelligentTieringConfigurationRequest) {
  GetBucketIntelligentTieringConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketIntelligentTieringConfigurationRequest || (GetBucketIntelligentTieringConfigurationRequest = {}));

var SSEKMS;

(function (SSEKMS) {
  SSEKMS.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.KeyId && {
      KeyId: SENSITIVE_STRING
    });
  };
})(SSEKMS || (SSEKMS = {}));

var SSES3;

(function (SSES3) {
  SSES3.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(SSES3 || (SSES3 = {}));

var InventoryEncryption;

(function (InventoryEncryption) {
  InventoryEncryption.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.SSEKMS && {
      SSEKMS: SSEKMS.filterSensitiveLog(obj.SSEKMS)
    });
  };
})(InventoryEncryption || (InventoryEncryption = {}));

var InventoryS3BucketDestination;

(function (InventoryS3BucketDestination) {
  InventoryS3BucketDestination.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.Encryption && {
      Encryption: InventoryEncryption.filterSensitiveLog(obj.Encryption)
    });
  };
})(InventoryS3BucketDestination || (InventoryS3BucketDestination = {}));

var InventoryDestination;

(function (InventoryDestination) {
  InventoryDestination.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.S3BucketDestination && {
      S3BucketDestination: InventoryS3BucketDestination.filterSensitiveLog(obj.S3BucketDestination)
    });
  };
})(InventoryDestination || (InventoryDestination = {}));

var InventoryFilter;

(function (InventoryFilter) {
  InventoryFilter.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(InventoryFilter || (InventoryFilter = {}));

var InventorySchedule;

(function (InventorySchedule) {
  InventorySchedule.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(InventorySchedule || (InventorySchedule = {}));

var InventoryConfiguration;

(function (InventoryConfiguration) {
  InventoryConfiguration.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.Destination && {
      Destination: InventoryDestination.filterSensitiveLog(obj.Destination)
    });
  };
})(InventoryConfiguration || (InventoryConfiguration = {}));

var GetBucketInventoryConfigurationOutput;

(function (GetBucketInventoryConfigurationOutput) {
  GetBucketInventoryConfigurationOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.InventoryConfiguration && {
      InventoryConfiguration: InventoryConfiguration.filterSensitiveLog(obj.InventoryConfiguration)
    });
  };
})(GetBucketInventoryConfigurationOutput || (GetBucketInventoryConfigurationOutput = {}));

var GetBucketInventoryConfigurationRequest;

(function (GetBucketInventoryConfigurationRequest) {
  GetBucketInventoryConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketInventoryConfigurationRequest || (GetBucketInventoryConfigurationRequest = {}));

var LifecycleExpiration;

(function (LifecycleExpiration) {
  LifecycleExpiration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(LifecycleExpiration || (LifecycleExpiration = {}));

var LifecycleRuleAndOperator;

(function (LifecycleRuleAndOperator) {
  LifecycleRuleAndOperator.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(LifecycleRuleAndOperator || (LifecycleRuleAndOperator = {}));

var LifecycleRuleFilter;

(function (LifecycleRuleFilter) {
  LifecycleRuleFilter.visit = function (value, visitor) {
    if (value.Prefix !== undefined) return visitor.Prefix(value.Prefix);
    if (value.Tag !== undefined) return visitor.Tag(value.Tag);
    if (value.And !== undefined) return visitor.And(value.And);
    return visitor._(value.$unknown[0], value.$unknown[1]);
  };

  LifecycleRuleFilter.filterSensitiveLog = function (obj) {
    var _a;

    if (obj.Prefix !== undefined) return {
      Prefix: obj.Prefix
    };
    if (obj.Tag !== undefined) return {
      Tag: Tag.filterSensitiveLog(obj.Tag)
    };
    if (obj.And !== undefined) return {
      And: LifecycleRuleAndOperator.filterSensitiveLog(obj.And)
    };
    if (obj.$unknown !== undefined) return _a = {}, _a[obj.$unknown[0]] = "UNKNOWN", _a;
  };
})(LifecycleRuleFilter || (LifecycleRuleFilter = {}));

var NoncurrentVersionExpiration;

(function (NoncurrentVersionExpiration) {
  NoncurrentVersionExpiration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(NoncurrentVersionExpiration || (NoncurrentVersionExpiration = {}));

var NoncurrentVersionTransition;

(function (NoncurrentVersionTransition) {
  NoncurrentVersionTransition.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(NoncurrentVersionTransition || (NoncurrentVersionTransition = {}));

var Transition;

(function (Transition) {
  Transition.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Transition || (Transition = {}));

var LifecycleRule;

(function (LifecycleRule) {
  LifecycleRule.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.Filter && {
      Filter: LifecycleRuleFilter.filterSensitiveLog(obj.Filter)
    });
  };
})(LifecycleRule || (LifecycleRule = {}));

var GetBucketLifecycleConfigurationOutput;

(function (GetBucketLifecycleConfigurationOutput) {
  GetBucketLifecycleConfigurationOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.Rules && {
      Rules: obj.Rules.map(function (item) {
        return LifecycleRule.filterSensitiveLog(item);
      })
    });
  };
})(GetBucketLifecycleConfigurationOutput || (GetBucketLifecycleConfigurationOutput = {}));

var GetBucketLifecycleConfigurationRequest;

(function (GetBucketLifecycleConfigurationRequest) {
  GetBucketLifecycleConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketLifecycleConfigurationRequest || (GetBucketLifecycleConfigurationRequest = {}));

var GetBucketLocationOutput;

(function (GetBucketLocationOutput) {
  GetBucketLocationOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketLocationOutput || (GetBucketLocationOutput = {}));

var GetBucketLocationRequest;

(function (GetBucketLocationRequest) {
  GetBucketLocationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketLocationRequest || (GetBucketLocationRequest = {}));

var TargetGrant;

(function (TargetGrant) {
  TargetGrant.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(TargetGrant || (TargetGrant = {}));

var LoggingEnabled;

(function (LoggingEnabled) {
  LoggingEnabled.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(LoggingEnabled || (LoggingEnabled = {}));

var GetBucketLoggingOutput;

(function (GetBucketLoggingOutput) {
  GetBucketLoggingOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketLoggingOutput || (GetBucketLoggingOutput = {}));

var GetBucketLoggingRequest;

(function (GetBucketLoggingRequest) {
  GetBucketLoggingRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketLoggingRequest || (GetBucketLoggingRequest = {}));

var MetricsAndOperator;

(function (MetricsAndOperator) {
  MetricsAndOperator.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(MetricsAndOperator || (MetricsAndOperator = {}));

var MetricsFilter;

(function (MetricsFilter) {
  MetricsFilter.visit = function (value, visitor) {
    if (value.Prefix !== undefined) return visitor.Prefix(value.Prefix);
    if (value.Tag !== undefined) return visitor.Tag(value.Tag);
    if (value.And !== undefined) return visitor.And(value.And);
    return visitor._(value.$unknown[0], value.$unknown[1]);
  };

  MetricsFilter.filterSensitiveLog = function (obj) {
    var _a;

    if (obj.Prefix !== undefined) return {
      Prefix: obj.Prefix
    };
    if (obj.Tag !== undefined) return {
      Tag: Tag.filterSensitiveLog(obj.Tag)
    };
    if (obj.And !== undefined) return {
      And: MetricsAndOperator.filterSensitiveLog(obj.And)
    };
    if (obj.$unknown !== undefined) return _a = {}, _a[obj.$unknown[0]] = "UNKNOWN", _a;
  };
})(MetricsFilter || (MetricsFilter = {}));

var MetricsConfiguration;

(function (MetricsConfiguration) {
  MetricsConfiguration.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.Filter && {
      Filter: MetricsFilter.filterSensitiveLog(obj.Filter)
    });
  };
})(MetricsConfiguration || (MetricsConfiguration = {}));

var GetBucketMetricsConfigurationOutput;

(function (GetBucketMetricsConfigurationOutput) {
  GetBucketMetricsConfigurationOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.MetricsConfiguration && {
      MetricsConfiguration: MetricsConfiguration.filterSensitiveLog(obj.MetricsConfiguration)
    });
  };
})(GetBucketMetricsConfigurationOutput || (GetBucketMetricsConfigurationOutput = {}));

var GetBucketMetricsConfigurationRequest;

(function (GetBucketMetricsConfigurationRequest) {
  GetBucketMetricsConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketMetricsConfigurationRequest || (GetBucketMetricsConfigurationRequest = {}));

var GetBucketNotificationConfigurationRequest;

(function (GetBucketNotificationConfigurationRequest) {
  GetBucketNotificationConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketNotificationConfigurationRequest || (GetBucketNotificationConfigurationRequest = {}));

var FilterRule;

(function (FilterRule) {
  FilterRule.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(FilterRule || (FilterRule = {}));

var S3KeyFilter;

(function (S3KeyFilter) {
  S3KeyFilter.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(S3KeyFilter || (S3KeyFilter = {}));

var NotificationConfigurationFilter;

(function (NotificationConfigurationFilter) {
  NotificationConfigurationFilter.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(NotificationConfigurationFilter || (NotificationConfigurationFilter = {}));

var LambdaFunctionConfiguration;

(function (LambdaFunctionConfiguration) {
  LambdaFunctionConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(LambdaFunctionConfiguration || (LambdaFunctionConfiguration = {}));

var QueueConfiguration;

(function (QueueConfiguration) {
  QueueConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(QueueConfiguration || (QueueConfiguration = {}));

var TopicConfiguration;

(function (TopicConfiguration) {
  TopicConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(TopicConfiguration || (TopicConfiguration = {}));

var NotificationConfiguration;

(function (NotificationConfiguration) {
  NotificationConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(NotificationConfiguration || (NotificationConfiguration = {}));

var OwnershipControlsRule;

(function (OwnershipControlsRule) {
  OwnershipControlsRule.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(OwnershipControlsRule || (OwnershipControlsRule = {}));

var OwnershipControls;

(function (OwnershipControls) {
  OwnershipControls.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(OwnershipControls || (OwnershipControls = {}));

var GetBucketOwnershipControlsOutput;

(function (GetBucketOwnershipControlsOutput) {
  GetBucketOwnershipControlsOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketOwnershipControlsOutput || (GetBucketOwnershipControlsOutput = {}));

var GetBucketOwnershipControlsRequest;

(function (GetBucketOwnershipControlsRequest) {
  GetBucketOwnershipControlsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketOwnershipControlsRequest || (GetBucketOwnershipControlsRequest = {}));

var GetBucketPolicyOutput;

(function (GetBucketPolicyOutput) {
  GetBucketPolicyOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketPolicyOutput || (GetBucketPolicyOutput = {}));

var GetBucketPolicyRequest;

(function (GetBucketPolicyRequest) {
  GetBucketPolicyRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketPolicyRequest || (GetBucketPolicyRequest = {}));

var PolicyStatus;

(function (PolicyStatus) {
  PolicyStatus.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PolicyStatus || (PolicyStatus = {}));

var GetBucketPolicyStatusOutput;

(function (GetBucketPolicyStatusOutput) {
  GetBucketPolicyStatusOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketPolicyStatusOutput || (GetBucketPolicyStatusOutput = {}));

var GetBucketPolicyStatusRequest;

(function (GetBucketPolicyStatusRequest) {
  GetBucketPolicyStatusRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketPolicyStatusRequest || (GetBucketPolicyStatusRequest = {}));

var DeleteMarkerReplication;

(function (DeleteMarkerReplication) {
  DeleteMarkerReplication.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteMarkerReplication || (DeleteMarkerReplication = {}));

var EncryptionConfiguration;

(function (EncryptionConfiguration) {
  EncryptionConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(EncryptionConfiguration || (EncryptionConfiguration = {}));

var ReplicationTimeValue;

(function (ReplicationTimeValue) {
  ReplicationTimeValue.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ReplicationTimeValue || (ReplicationTimeValue = {}));

var Metrics;

(function (Metrics) {
  Metrics.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Metrics || (Metrics = {}));

var ReplicationTime;

(function (ReplicationTime) {
  ReplicationTime.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ReplicationTime || (ReplicationTime = {}));

var Destination;

(function (Destination) {
  Destination.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Destination || (Destination = {}));

var ExistingObjectReplication;

(function (ExistingObjectReplication) {
  ExistingObjectReplication.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ExistingObjectReplication || (ExistingObjectReplication = {}));

var ReplicationRuleAndOperator;

(function (ReplicationRuleAndOperator) {
  ReplicationRuleAndOperator.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ReplicationRuleAndOperator || (ReplicationRuleAndOperator = {}));

var ReplicationRuleFilter;

(function (ReplicationRuleFilter) {
  ReplicationRuleFilter.visit = function (value, visitor) {
    if (value.Prefix !== undefined) return visitor.Prefix(value.Prefix);
    if (value.Tag !== undefined) return visitor.Tag(value.Tag);
    if (value.And !== undefined) return visitor.And(value.And);
    return visitor._(value.$unknown[0], value.$unknown[1]);
  };

  ReplicationRuleFilter.filterSensitiveLog = function (obj) {
    var _a;

    if (obj.Prefix !== undefined) return {
      Prefix: obj.Prefix
    };
    if (obj.Tag !== undefined) return {
      Tag: Tag.filterSensitiveLog(obj.Tag)
    };
    if (obj.And !== undefined) return {
      And: ReplicationRuleAndOperator.filterSensitiveLog(obj.And)
    };
    if (obj.$unknown !== undefined) return _a = {}, _a[obj.$unknown[0]] = "UNKNOWN", _a;
  };
})(ReplicationRuleFilter || (ReplicationRuleFilter = {}));

var ReplicaModifications;

(function (ReplicaModifications) {
  ReplicaModifications.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ReplicaModifications || (ReplicaModifications = {}));

var SseKmsEncryptedObjects;

(function (SseKmsEncryptedObjects) {
  SseKmsEncryptedObjects.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(SseKmsEncryptedObjects || (SseKmsEncryptedObjects = {}));

var SourceSelectionCriteria;

(function (SourceSelectionCriteria) {
  SourceSelectionCriteria.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(SourceSelectionCriteria || (SourceSelectionCriteria = {}));

var ReplicationRule;

(function (ReplicationRule) {
  ReplicationRule.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.Filter && {
      Filter: ReplicationRuleFilter.filterSensitiveLog(obj.Filter)
    });
  };
})(ReplicationRule || (ReplicationRule = {}));

var ReplicationConfiguration;

(function (ReplicationConfiguration) {
  ReplicationConfiguration.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.Rules && {
      Rules: obj.Rules.map(function (item) {
        return ReplicationRule.filterSensitiveLog(item);
      })
    });
  };
})(ReplicationConfiguration || (ReplicationConfiguration = {}));

var GetBucketReplicationOutput;

(function (GetBucketReplicationOutput) {
  GetBucketReplicationOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.ReplicationConfiguration && {
      ReplicationConfiguration: ReplicationConfiguration.filterSensitiveLog(obj.ReplicationConfiguration)
    });
  };
})(GetBucketReplicationOutput || (GetBucketReplicationOutput = {}));

var GetBucketReplicationRequest;

(function (GetBucketReplicationRequest) {
  GetBucketReplicationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketReplicationRequest || (GetBucketReplicationRequest = {}));

var GetBucketRequestPaymentOutput;

(function (GetBucketRequestPaymentOutput) {
  GetBucketRequestPaymentOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketRequestPaymentOutput || (GetBucketRequestPaymentOutput = {}));

var GetBucketRequestPaymentRequest;

(function (GetBucketRequestPaymentRequest) {
  GetBucketRequestPaymentRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketRequestPaymentRequest || (GetBucketRequestPaymentRequest = {}));

var GetBucketTaggingOutput;

(function (GetBucketTaggingOutput) {
  GetBucketTaggingOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketTaggingOutput || (GetBucketTaggingOutput = {}));

var GetBucketTaggingRequest;

(function (GetBucketTaggingRequest) {
  GetBucketTaggingRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketTaggingRequest || (GetBucketTaggingRequest = {}));

var GetBucketVersioningOutput;

(function (GetBucketVersioningOutput) {
  GetBucketVersioningOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketVersioningOutput || (GetBucketVersioningOutput = {}));

var GetBucketVersioningRequest;

(function (GetBucketVersioningRequest) {
  GetBucketVersioningRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketVersioningRequest || (GetBucketVersioningRequest = {}));

var ErrorDocument;

(function (ErrorDocument) {
  ErrorDocument.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ErrorDocument || (ErrorDocument = {}));

var IndexDocument;

(function (IndexDocument) {
  IndexDocument.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(IndexDocument || (IndexDocument = {}));

var RedirectAllRequestsTo;

(function (RedirectAllRequestsTo) {
  RedirectAllRequestsTo.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(RedirectAllRequestsTo || (RedirectAllRequestsTo = {}));

var Condition;

(function (Condition) {
  Condition.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Condition || (Condition = {}));

var Redirect;

(function (Redirect) {
  Redirect.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Redirect || (Redirect = {}));

var RoutingRule;

(function (RoutingRule) {
  RoutingRule.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(RoutingRule || (RoutingRule = {}));

var GetBucketWebsiteOutput;

(function (GetBucketWebsiteOutput) {
  GetBucketWebsiteOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketWebsiteOutput || (GetBucketWebsiteOutput = {}));

var GetBucketWebsiteRequest;

(function (GetBucketWebsiteRequest) {
  GetBucketWebsiteRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetBucketWebsiteRequest || (GetBucketWebsiteRequest = {}));

var GetObjectOutput;

(function (GetObjectOutput) {
  GetObjectOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.SSEKMSKeyId && {
      SSEKMSKeyId: SENSITIVE_STRING
    });
  };
})(GetObjectOutput || (GetObjectOutput = {}));

var GetObjectRequest;

(function (GetObjectRequest) {
  GetObjectRequest.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.SSECustomerKey && {
      SSECustomerKey: SENSITIVE_STRING
    });
  };
})(GetObjectRequest || (GetObjectRequest = {}));

var InvalidObjectState;

(function (InvalidObjectState) {
  InvalidObjectState.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(InvalidObjectState || (InvalidObjectState = {}));

var NoSuchKey;

(function (NoSuchKey) {
  NoSuchKey.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(NoSuchKey || (NoSuchKey = {}));

var GetObjectAclOutput;

(function (GetObjectAclOutput) {
  GetObjectAclOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetObjectAclOutput || (GetObjectAclOutput = {}));

var GetObjectAclRequest;

(function (GetObjectAclRequest) {
  GetObjectAclRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetObjectAclRequest || (GetObjectAclRequest = {}));

var ObjectLockLegalHold;

(function (ObjectLockLegalHold) {
  ObjectLockLegalHold.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ObjectLockLegalHold || (ObjectLockLegalHold = {}));

var GetObjectLegalHoldOutput;

(function (GetObjectLegalHoldOutput) {
  GetObjectLegalHoldOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetObjectLegalHoldOutput || (GetObjectLegalHoldOutput = {}));

var GetObjectLegalHoldRequest;

(function (GetObjectLegalHoldRequest) {
  GetObjectLegalHoldRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetObjectLegalHoldRequest || (GetObjectLegalHoldRequest = {}));

var DefaultRetention;

(function (DefaultRetention) {
  DefaultRetention.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DefaultRetention || (DefaultRetention = {}));

var ObjectLockRule;

(function (ObjectLockRule) {
  ObjectLockRule.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ObjectLockRule || (ObjectLockRule = {}));

var ObjectLockConfiguration;

(function (ObjectLockConfiguration) {
  ObjectLockConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ObjectLockConfiguration || (ObjectLockConfiguration = {}));

var GetObjectLockConfigurationOutput;

(function (GetObjectLockConfigurationOutput) {
  GetObjectLockConfigurationOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetObjectLockConfigurationOutput || (GetObjectLockConfigurationOutput = {}));

var GetObjectLockConfigurationRequest;

(function (GetObjectLockConfigurationRequest) {
  GetObjectLockConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetObjectLockConfigurationRequest || (GetObjectLockConfigurationRequest = {}));

var ObjectLockRetention;

(function (ObjectLockRetention) {
  ObjectLockRetention.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ObjectLockRetention || (ObjectLockRetention = {}));

var GetObjectRetentionOutput;

(function (GetObjectRetentionOutput) {
  GetObjectRetentionOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetObjectRetentionOutput || (GetObjectRetentionOutput = {}));

var GetObjectRetentionRequest;

(function (GetObjectRetentionRequest) {
  GetObjectRetentionRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetObjectRetentionRequest || (GetObjectRetentionRequest = {}));

var GetObjectTaggingOutput;

(function (GetObjectTaggingOutput) {
  GetObjectTaggingOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetObjectTaggingOutput || (GetObjectTaggingOutput = {}));

var GetObjectTaggingRequest;

(function (GetObjectTaggingRequest) {
  GetObjectTaggingRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetObjectTaggingRequest || (GetObjectTaggingRequest = {}));

var GetObjectTorrentOutput;

(function (GetObjectTorrentOutput) {
  GetObjectTorrentOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetObjectTorrentOutput || (GetObjectTorrentOutput = {}));

var GetObjectTorrentRequest;

(function (GetObjectTorrentRequest) {
  GetObjectTorrentRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetObjectTorrentRequest || (GetObjectTorrentRequest = {}));

var PublicAccessBlockConfiguration;

(function (PublicAccessBlockConfiguration) {
  PublicAccessBlockConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PublicAccessBlockConfiguration || (PublicAccessBlockConfiguration = {}));

var GetPublicAccessBlockOutput;

(function (GetPublicAccessBlockOutput) {
  GetPublicAccessBlockOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetPublicAccessBlockOutput || (GetPublicAccessBlockOutput = {}));

var GetPublicAccessBlockRequest;

(function (GetPublicAccessBlockRequest) {
  GetPublicAccessBlockRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GetPublicAccessBlockRequest || (GetPublicAccessBlockRequest = {}));

var HeadBucketRequest;

(function (HeadBucketRequest) {
  HeadBucketRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(HeadBucketRequest || (HeadBucketRequest = {}));

var NoSuchBucket;

(function (NoSuchBucket) {
  NoSuchBucket.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(NoSuchBucket || (NoSuchBucket = {}));

var HeadObjectOutput;

(function (HeadObjectOutput) {
  HeadObjectOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.SSEKMSKeyId && {
      SSEKMSKeyId: SENSITIVE_STRING
    });
  };
})(HeadObjectOutput || (HeadObjectOutput = {}));

var HeadObjectRequest;

(function (HeadObjectRequest) {
  HeadObjectRequest.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.SSECustomerKey && {
      SSECustomerKey: SENSITIVE_STRING
    });
  };
})(HeadObjectRequest || (HeadObjectRequest = {}));

var ListBucketAnalyticsConfigurationsOutput;

(function (ListBucketAnalyticsConfigurationsOutput) {
  ListBucketAnalyticsConfigurationsOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.AnalyticsConfigurationList && {
      AnalyticsConfigurationList: obj.AnalyticsConfigurationList.map(function (item) {
        return AnalyticsConfiguration.filterSensitiveLog(item);
      })
    });
  };
})(ListBucketAnalyticsConfigurationsOutput || (ListBucketAnalyticsConfigurationsOutput = {}));

var ListBucketAnalyticsConfigurationsRequest;

(function (ListBucketAnalyticsConfigurationsRequest) {
  ListBucketAnalyticsConfigurationsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListBucketAnalyticsConfigurationsRequest || (ListBucketAnalyticsConfigurationsRequest = {}));

var ListBucketIntelligentTieringConfigurationsOutput;

(function (ListBucketIntelligentTieringConfigurationsOutput) {
  ListBucketIntelligentTieringConfigurationsOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListBucketIntelligentTieringConfigurationsOutput || (ListBucketIntelligentTieringConfigurationsOutput = {}));

var ListBucketIntelligentTieringConfigurationsRequest;

(function (ListBucketIntelligentTieringConfigurationsRequest) {
  ListBucketIntelligentTieringConfigurationsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListBucketIntelligentTieringConfigurationsRequest || (ListBucketIntelligentTieringConfigurationsRequest = {}));

var ListBucketInventoryConfigurationsOutput;

(function (ListBucketInventoryConfigurationsOutput) {
  ListBucketInventoryConfigurationsOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.InventoryConfigurationList && {
      InventoryConfigurationList: obj.InventoryConfigurationList.map(function (item) {
        return InventoryConfiguration.filterSensitiveLog(item);
      })
    });
  };
})(ListBucketInventoryConfigurationsOutput || (ListBucketInventoryConfigurationsOutput = {}));

var ListBucketInventoryConfigurationsRequest;

(function (ListBucketInventoryConfigurationsRequest) {
  ListBucketInventoryConfigurationsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListBucketInventoryConfigurationsRequest || (ListBucketInventoryConfigurationsRequest = {}));

var ListBucketMetricsConfigurationsOutput;

(function (ListBucketMetricsConfigurationsOutput) {
  ListBucketMetricsConfigurationsOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.MetricsConfigurationList && {
      MetricsConfigurationList: obj.MetricsConfigurationList.map(function (item) {
        return MetricsConfiguration.filterSensitiveLog(item);
      })
    });
  };
})(ListBucketMetricsConfigurationsOutput || (ListBucketMetricsConfigurationsOutput = {}));

var ListBucketMetricsConfigurationsRequest;

(function (ListBucketMetricsConfigurationsRequest) {
  ListBucketMetricsConfigurationsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListBucketMetricsConfigurationsRequest || (ListBucketMetricsConfigurationsRequest = {}));

var Bucket;

(function (Bucket) {
  Bucket.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Bucket || (Bucket = {}));

var ListBucketsOutput;

(function (ListBucketsOutput) {
  ListBucketsOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListBucketsOutput || (ListBucketsOutput = {}));

var CommonPrefix;

(function (CommonPrefix) {
  CommonPrefix.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(CommonPrefix || (CommonPrefix = {}));

var Initiator;

(function (Initiator) {
  Initiator.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Initiator || (Initiator = {}));

var MultipartUpload;

(function (MultipartUpload) {
  MultipartUpload.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(MultipartUpload || (MultipartUpload = {}));

var ListMultipartUploadsOutput;

(function (ListMultipartUploadsOutput) {
  ListMultipartUploadsOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListMultipartUploadsOutput || (ListMultipartUploadsOutput = {}));

var ListMultipartUploadsRequest;

(function (ListMultipartUploadsRequest) {
  ListMultipartUploadsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListMultipartUploadsRequest || (ListMultipartUploadsRequest = {}));

var _Object;

(function (_Object) {
  _Object.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(_Object || (_Object = {}));

var ListObjectsOutput;

(function (ListObjectsOutput) {
  ListObjectsOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListObjectsOutput || (ListObjectsOutput = {}));

var ListObjectsRequest;

(function (ListObjectsRequest) {
  ListObjectsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListObjectsRequest || (ListObjectsRequest = {}));

var ListObjectsV2Output;

(function (ListObjectsV2Output) {
  ListObjectsV2Output.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListObjectsV2Output || (ListObjectsV2Output = {}));

var ListObjectsV2Request;

(function (ListObjectsV2Request) {
  ListObjectsV2Request.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListObjectsV2Request || (ListObjectsV2Request = {}));

var DeleteMarkerEntry;

(function (DeleteMarkerEntry) {
  DeleteMarkerEntry.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(DeleteMarkerEntry || (DeleteMarkerEntry = {}));

var ObjectVersion;

(function (ObjectVersion) {
  ObjectVersion.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ObjectVersion || (ObjectVersion = {}));

var ListObjectVersionsOutput;

(function (ListObjectVersionsOutput) {
  ListObjectVersionsOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListObjectVersionsOutput || (ListObjectVersionsOutput = {}));

var ListObjectVersionsRequest;

(function (ListObjectVersionsRequest) {
  ListObjectVersionsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListObjectVersionsRequest || (ListObjectVersionsRequest = {}));

var Part;

(function (Part) {
  Part.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Part || (Part = {}));

var ListPartsOutput;

(function (ListPartsOutput) {
  ListPartsOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListPartsOutput || (ListPartsOutput = {}));

var ListPartsRequest;

(function (ListPartsRequest) {
  ListPartsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ListPartsRequest || (ListPartsRequest = {}));

var PutBucketAccelerateConfigurationRequest;

(function (PutBucketAccelerateConfigurationRequest) {
  PutBucketAccelerateConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutBucketAccelerateConfigurationRequest || (PutBucketAccelerateConfigurationRequest = {}));

var PutBucketAclRequest;

(function (PutBucketAclRequest) {
  PutBucketAclRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutBucketAclRequest || (PutBucketAclRequest = {}));

var PutBucketAnalyticsConfigurationRequest;

(function (PutBucketAnalyticsConfigurationRequest) {
  PutBucketAnalyticsConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.AnalyticsConfiguration && {
      AnalyticsConfiguration: AnalyticsConfiguration.filterSensitiveLog(obj.AnalyticsConfiguration)
    });
  };
})(PutBucketAnalyticsConfigurationRequest || (PutBucketAnalyticsConfigurationRequest = {}));

var CORSConfiguration;

(function (CORSConfiguration) {
  CORSConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(CORSConfiguration || (CORSConfiguration = {}));

var PutBucketCorsRequest;

(function (PutBucketCorsRequest) {
  PutBucketCorsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutBucketCorsRequest || (PutBucketCorsRequest = {}));

var PutBucketEncryptionRequest;

(function (PutBucketEncryptionRequest) {
  PutBucketEncryptionRequest.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.ServerSideEncryptionConfiguration && {
      ServerSideEncryptionConfiguration: ServerSideEncryptionConfiguration.filterSensitiveLog(obj.ServerSideEncryptionConfiguration)
    });
  };
})(PutBucketEncryptionRequest || (PutBucketEncryptionRequest = {}));

var PutBucketIntelligentTieringConfigurationRequest;

(function (PutBucketIntelligentTieringConfigurationRequest) {
  PutBucketIntelligentTieringConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutBucketIntelligentTieringConfigurationRequest || (PutBucketIntelligentTieringConfigurationRequest = {}));

var PutBucketInventoryConfigurationRequest;

(function (PutBucketInventoryConfigurationRequest) {
  PutBucketInventoryConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.InventoryConfiguration && {
      InventoryConfiguration: InventoryConfiguration.filterSensitiveLog(obj.InventoryConfiguration)
    });
  };
})(PutBucketInventoryConfigurationRequest || (PutBucketInventoryConfigurationRequest = {}));

var BucketLifecycleConfiguration;

(function (BucketLifecycleConfiguration) {
  BucketLifecycleConfiguration.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.Rules && {
      Rules: obj.Rules.map(function (item) {
        return LifecycleRule.filterSensitiveLog(item);
      })
    });
  };
})(BucketLifecycleConfiguration || (BucketLifecycleConfiguration = {}));

var PutBucketLifecycleConfigurationRequest;

(function (PutBucketLifecycleConfigurationRequest) {
  PutBucketLifecycleConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.LifecycleConfiguration && {
      LifecycleConfiguration: BucketLifecycleConfiguration.filterSensitiveLog(obj.LifecycleConfiguration)
    });
  };
})(PutBucketLifecycleConfigurationRequest || (PutBucketLifecycleConfigurationRequest = {}));

var BucketLoggingStatus;

(function (BucketLoggingStatus) {
  BucketLoggingStatus.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(BucketLoggingStatus || (BucketLoggingStatus = {}));

var PutBucketLoggingRequest;

(function (PutBucketLoggingRequest) {
  PutBucketLoggingRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutBucketLoggingRequest || (PutBucketLoggingRequest = {}));

var PutBucketMetricsConfigurationRequest;

(function (PutBucketMetricsConfigurationRequest) {
  PutBucketMetricsConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.MetricsConfiguration && {
      MetricsConfiguration: MetricsConfiguration.filterSensitiveLog(obj.MetricsConfiguration)
    });
  };
})(PutBucketMetricsConfigurationRequest || (PutBucketMetricsConfigurationRequest = {}));

var PutBucketNotificationConfigurationRequest;

(function (PutBucketNotificationConfigurationRequest) {
  PutBucketNotificationConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutBucketNotificationConfigurationRequest || (PutBucketNotificationConfigurationRequest = {}));

var PutBucketOwnershipControlsRequest;

(function (PutBucketOwnershipControlsRequest) {
  PutBucketOwnershipControlsRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutBucketOwnershipControlsRequest || (PutBucketOwnershipControlsRequest = {}));

var PutBucketPolicyRequest;

(function (PutBucketPolicyRequest) {
  PutBucketPolicyRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutBucketPolicyRequest || (PutBucketPolicyRequest = {}));

var PutBucketReplicationRequest;

(function (PutBucketReplicationRequest) {
  PutBucketReplicationRequest.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.ReplicationConfiguration && {
      ReplicationConfiguration: ReplicationConfiguration.filterSensitiveLog(obj.ReplicationConfiguration)
    });
  };
})(PutBucketReplicationRequest || (PutBucketReplicationRequest = {}));

var RequestPaymentConfiguration;

(function (RequestPaymentConfiguration) {
  RequestPaymentConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(RequestPaymentConfiguration || (RequestPaymentConfiguration = {}));

var PutBucketRequestPaymentRequest;

(function (PutBucketRequestPaymentRequest) {
  PutBucketRequestPaymentRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutBucketRequestPaymentRequest || (PutBucketRequestPaymentRequest = {}));

var Tagging;

(function (Tagging) {
  Tagging.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(Tagging || (Tagging = {}));

var PutBucketTaggingRequest;

(function (PutBucketTaggingRequest) {
  PutBucketTaggingRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutBucketTaggingRequest || (PutBucketTaggingRequest = {}));

var VersioningConfiguration;

(function (VersioningConfiguration) {
  VersioningConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(VersioningConfiguration || (VersioningConfiguration = {}));

var PutBucketVersioningRequest;

(function (PutBucketVersioningRequest) {
  PutBucketVersioningRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutBucketVersioningRequest || (PutBucketVersioningRequest = {}));

var WebsiteConfiguration;

(function (WebsiteConfiguration) {
  WebsiteConfiguration.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(WebsiteConfiguration || (WebsiteConfiguration = {}));

var PutBucketWebsiteRequest;

(function (PutBucketWebsiteRequest) {
  PutBucketWebsiteRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutBucketWebsiteRequest || (PutBucketWebsiteRequest = {}));

var PutObjectOutput;

(function (PutObjectOutput) {
  PutObjectOutput.filterSensitiveLog = function (obj) {
    return __assign(__assign(__assign({}, obj), obj.SSEKMSKeyId && {
      SSEKMSKeyId: SENSITIVE_STRING
    }), obj.SSEKMSEncryptionContext && {
      SSEKMSEncryptionContext: SENSITIVE_STRING
    });
  };
})(PutObjectOutput || (PutObjectOutput = {}));

var PutObjectRequest;

(function (PutObjectRequest) {
  PutObjectRequest.filterSensitiveLog = function (obj) {
    return __assign(__assign(__assign(__assign({}, obj), obj.SSECustomerKey && {
      SSECustomerKey: SENSITIVE_STRING
    }), obj.SSEKMSKeyId && {
      SSEKMSKeyId: SENSITIVE_STRING
    }), obj.SSEKMSEncryptionContext && {
      SSEKMSEncryptionContext: SENSITIVE_STRING
    });
  };
})(PutObjectRequest || (PutObjectRequest = {}));

var PutObjectAclOutput;

(function (PutObjectAclOutput) {
  PutObjectAclOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutObjectAclOutput || (PutObjectAclOutput = {}));

var PutObjectAclRequest;

(function (PutObjectAclRequest) {
  PutObjectAclRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutObjectAclRequest || (PutObjectAclRequest = {}));

var PutObjectLegalHoldOutput;

(function (PutObjectLegalHoldOutput) {
  PutObjectLegalHoldOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutObjectLegalHoldOutput || (PutObjectLegalHoldOutput = {}));

var PutObjectLegalHoldRequest;

(function (PutObjectLegalHoldRequest) {
  PutObjectLegalHoldRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutObjectLegalHoldRequest || (PutObjectLegalHoldRequest = {}));

var PutObjectLockConfigurationOutput;

(function (PutObjectLockConfigurationOutput) {
  PutObjectLockConfigurationOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutObjectLockConfigurationOutput || (PutObjectLockConfigurationOutput = {}));

var PutObjectLockConfigurationRequest;

(function (PutObjectLockConfigurationRequest) {
  PutObjectLockConfigurationRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutObjectLockConfigurationRequest || (PutObjectLockConfigurationRequest = {}));

var PutObjectRetentionOutput;

(function (PutObjectRetentionOutput) {
  PutObjectRetentionOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutObjectRetentionOutput || (PutObjectRetentionOutput = {}));

var PutObjectRetentionRequest;

(function (PutObjectRetentionRequest) {
  PutObjectRetentionRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutObjectRetentionRequest || (PutObjectRetentionRequest = {}));

var PutObjectTaggingOutput;

(function (PutObjectTaggingOutput) {
  PutObjectTaggingOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutObjectTaggingOutput || (PutObjectTaggingOutput = {}));

var PutObjectTaggingRequest;

(function (PutObjectTaggingRequest) {
  PutObjectTaggingRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutObjectTaggingRequest || (PutObjectTaggingRequest = {}));

var PutPublicAccessBlockRequest;

(function (PutPublicAccessBlockRequest) {
  PutPublicAccessBlockRequest.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(PutPublicAccessBlockRequest || (PutPublicAccessBlockRequest = {}));

var ObjectAlreadyInActiveTierError;

(function (ObjectAlreadyInActiveTierError) {
  ObjectAlreadyInActiveTierError.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(ObjectAlreadyInActiveTierError || (ObjectAlreadyInActiveTierError = {}));

var RestoreObjectOutput;

(function (RestoreObjectOutput) {
  RestoreObjectOutput.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(RestoreObjectOutput || (RestoreObjectOutput = {}));

var GlacierJobParameters;

(function (GlacierJobParameters) {
  GlacierJobParameters.filterSensitiveLog = function (obj) {
    return __assign({}, obj);
  };
})(GlacierJobParameters || (GlacierJobParameters = {}));

var Encryption;

(function (Encryption) {
  Encryption.filterSensitiveLog = function (obj) {
    return __assign(__assign({}, obj), obj.KMSKeyId && {
      KMSKeyId: SENSITIVE_STRING
    });
  };
})(Encryption || (Encryption = {}));

var util$1 = createCommonjsModule(function (module, exports) {

  const nameStartChar = ':A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD';
  const nameChar = nameStartChar + '\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040';
  const nameRegexp = '[' + nameStartChar + '][' + nameChar + ']*';
  const regexName = new RegExp('^' + nameRegexp + '$');

  const getAllMatches = function (string, regex) {
    const matches = [];
    let match = regex.exec(string);

    while (match) {
      const allmatches = [];
      const len = match.length;

      for (let index = 0; index < len; index++) {
        allmatches.push(match[index]);
      }

      matches.push(allmatches);
      match = regex.exec(string);
    }

    return matches;
  };

  const isName = function (string) {
    const match = regexName.exec(string);
    return !(match === null || typeof match === 'undefined');
  };

  exports.isExist = function (v) {
    return typeof v !== 'undefined';
  };

  exports.isEmptyObject = function (obj) {
    return Object.keys(obj).length === 0;
  };
  /**
   * Copy all the properties of a into b.
   * @param {*} target
   * @param {*} a
   */


  exports.merge = function (target, a, arrayMode) {
    if (a) {
      const keys = Object.keys(a); // will return an array of own properties

      const len = keys.length; //don't make it inline

      for (let i = 0; i < len; i++) {
        if (arrayMode === 'strict') {
          target[keys[i]] = [a[keys[i]]];
        } else {
          target[keys[i]] = a[keys[i]];
        }
      }
    }
  };
  /* exports.merge =function (b,a){
    return Object.assign(b,a);
  } */


  exports.getValue = function (v) {
    if (exports.isExist(v)) {
      return v;
    } else {
      return '';
    }
  }; // const fakeCall = function(a) {return a;};
  // const fakeCallNoReturn = function() {};


  exports.buildOptions = function (options, defaultOptions, props) {
    var newOptions = {};

    if (!options) {
      return defaultOptions; //if there are not options
    }

    for (let i = 0; i < props.length; i++) {
      if (options[props[i]] !== undefined) {
        newOptions[props[i]] = options[props[i]];
      } else {
        newOptions[props[i]] = defaultOptions[props[i]];
      }
    }

    return newOptions;
  };
  /**
   * Check if a tag name should be treated as array
   *
   * @param tagName the node tagname
   * @param arrayMode the array mode option
   * @param parentTagName the parent tag name
   * @returns {boolean} true if node should be parsed as array
   */


  exports.isTagNameInArrayMode = function (tagName, arrayMode, parentTagName) {
    if (arrayMode === false) {
      return false;
    } else if (arrayMode instanceof RegExp) {
      return arrayMode.test(tagName);
    } else if (typeof arrayMode === 'function') {
      return !!arrayMode(tagName, parentTagName);
    }

    return arrayMode === "strict";
  };

  exports.isName = isName;
  exports.getAllMatches = getAllMatches;
  exports.nameRegexp = nameRegexp;
});

const convertToJson = function (node, options, parentTagName) {
  const jObj = {}; // when no child node or attr is present

  if ((!node.child || util$1.isEmptyObject(node.child)) && (!node.attrsMap || util$1.isEmptyObject(node.attrsMap))) {
    return util$1.isExist(node.val) ? node.val : '';
  } // otherwise create a textnode if node has some text


  if (util$1.isExist(node.val) && !(typeof node.val === 'string' && (node.val === '' || node.val === options.cdataPositionChar))) {
    const asArray = util$1.isTagNameInArrayMode(node.tagname, options.arrayMode, parentTagName);
    jObj[options.textNodeName] = asArray ? [node.val] : node.val;
  }

  util$1.merge(jObj, node.attrsMap, options.arrayMode);
  const keys = Object.keys(node.child);

  for (let index = 0; index < keys.length; index++) {
    const tagName = keys[index];

    if (node.child[tagName] && node.child[tagName].length > 1) {
      jObj[tagName] = [];

      for (let tag in node.child[tagName]) {
        if (node.child[tagName].hasOwnProperty(tag)) {
          jObj[tagName].push(convertToJson(node.child[tagName][tag], options, tagName));
        }
      }
    } else {
      const result = convertToJson(node.child[tagName][0], options, tagName);
      const asArray = options.arrayMode === true && typeof result === 'object' || util$1.isTagNameInArrayMode(tagName, options.arrayMode, parentTagName);
      jObj[tagName] = asArray ? [result] : result;
    }
  } //add value


  return jObj;
};

var convertToJson_1 = convertToJson;
var node2json = {
  convertToJson: convertToJson_1
};

var xmlNode = function (tagname, parent, val) {
  this.tagname = tagname;
  this.parent = parent;
  this.child = {}; //child tags

  this.attrsMap = {}; //attributes map

  this.val = val; //text only

  this.addChild = function (child) {
    if (Array.isArray(this.child[child.tagname])) {
      //already presents
      this.child[child.tagname].push(child);
    } else {
      this.child[child.tagname] = [child];
    }
  };
};

const buildOptions = util$1.buildOptions;
'<((!\\[CDATA\\[([\\s\\S]*?)(]]>))|((NAME:)?(NAME))([^>]*)>|((\\/)(NAME)\\s*>))([^<]*)'.replace(/NAME/g, util$1.nameRegexp); //const tagsRegx = new RegExp("<(\\/?[\\w:\\-\._]+)([^>]*)>(\\s*"+cdataRegx+")*([^<]+)?","g");
//const tagsRegx = new RegExp("<(\\/?)((\\w*:)?([\\w:\\-\._]+))([^>]*)>([^<]*)("+cdataRegx+"([^<]*))*([^<]+)?","g");
//polyfill

if (!Number.parseInt && window.parseInt) {
  Number.parseInt = window.parseInt;
}

if (!Number.parseFloat && window.parseFloat) {
  Number.parseFloat = window.parseFloat;
}

const defaultOptions = {
  attributeNamePrefix: '@_',
  attrNodeName: false,
  textNodeName: '#text',
  ignoreAttributes: true,
  ignoreNameSpace: false,
  allowBooleanAttributes: false,
  //a tag can have attributes without any value
  //ignoreRootElement : false,
  parseNodeValue: true,
  parseAttributeValue: false,
  arrayMode: false,
  trimValues: true,
  //Trim string values of tag and attributes
  cdataTagName: false,
  cdataPositionChar: '\\c',
  tagValueProcessor: function (a, tagName) {
    return a;
  },
  attrValueProcessor: function (a, attrName) {
    return a;
  },
  stopNodes: [] //decodeStrict: false,

};
var defaultOptions_1 = defaultOptions;
const props = ['attributeNamePrefix', 'attrNodeName', 'textNodeName', 'ignoreAttributes', 'ignoreNameSpace', 'allowBooleanAttributes', 'parseNodeValue', 'parseAttributeValue', 'arrayMode', 'trimValues', 'cdataTagName', 'cdataPositionChar', 'tagValueProcessor', 'attrValueProcessor', 'parseTrueNumberOnly', 'stopNodes'];
var props_1 = props;
/**
 * Trim -> valueProcessor -> parse value
 * @param {string} tagName
 * @param {string} val
 * @param {object} options
 */

function processTagValue(tagName, val, options) {
  if (val) {
    if (options.trimValues) {
      val = val.trim();
    }

    val = options.tagValueProcessor(val, tagName);
    val = parseValue(val, options.parseNodeValue, options.parseTrueNumberOnly);
  }

  return val;
}

function resolveNameSpace(tagname, options) {
  if (options.ignoreNameSpace) {
    const tags = tagname.split(':');
    const prefix = tagname.charAt(0) === '/' ? '/' : '';

    if (tags[0] === 'xmlns') {
      return '';
    }

    if (tags.length === 2) {
      tagname = prefix + tags[1];
    }
  }

  return tagname;
}

function parseValue(val, shouldParse, parseTrueNumberOnly) {
  if (shouldParse && typeof val === 'string') {
    let parsed;

    if (val.trim() === '' || isNaN(val)) {
      parsed = val === 'true' ? true : val === 'false' ? false : val;
    } else {
      if (val.indexOf('0x') !== -1) {
        //support hexa decimal
        parsed = Number.parseInt(val, 16);
      } else if (val.indexOf('.') !== -1) {
        parsed = Number.parseFloat(val);
        val = val.replace(/\.?0+$/, "");
      } else {
        parsed = Number.parseInt(val, 10);
      }

      if (parseTrueNumberOnly) {
        parsed = String(parsed) === val ? parsed : val;
      }
    }

    return parsed;
  } else {
    if (util$1.isExist(val)) {
      return val;
    } else {
      return '';
    }
  }
} //TODO: change regex to capture NS
//const attrsRegx = new RegExp("([\\w\\-\\.\\:]+)\\s*=\\s*(['\"])((.|\n)*?)\\2","gm");


const attrsRegx = new RegExp('([^\\s=]+)\\s*(=\\s*([\'"])(.*?)\\3)?', 'g');

function buildAttributesMap(attrStr, options) {
  if (!options.ignoreAttributes && typeof attrStr === 'string') {
    attrStr = attrStr.replace(/\r?\n/g, ' '); //attrStr = attrStr || attrStr.trim();

    const matches = util$1.getAllMatches(attrStr, attrsRegx);
    const len = matches.length; //don't make it inline

    const attrs = {};

    for (let i = 0; i < len; i++) {
      const attrName = resolveNameSpace(matches[i][1], options);

      if (attrName.length) {
        if (matches[i][4] !== undefined) {
          if (options.trimValues) {
            matches[i][4] = matches[i][4].trim();
          }

          matches[i][4] = options.attrValueProcessor(matches[i][4], attrName);
          attrs[options.attributeNamePrefix + attrName] = parseValue(matches[i][4], options.parseAttributeValue, options.parseTrueNumberOnly);
        } else if (options.allowBooleanAttributes) {
          attrs[options.attributeNamePrefix + attrName] = true;
        }
      }
    }

    if (!Object.keys(attrs).length) {
      return;
    }

    if (options.attrNodeName) {
      const attrCollection = {};
      attrCollection[options.attrNodeName] = attrs;
      return attrCollection;
    }

    return attrs;
  }
}

const getTraversalObj = function (xmlData, options) {
  xmlData = xmlData.replace(/\r\n?/g, "\n");
  options = buildOptions(options, defaultOptions, props);
  const xmlObj = new xmlNode('!xml');
  let currentNode = xmlObj;
  let textData = ""; //function match(xmlData){

  for (let i = 0; i < xmlData.length; i++) {
    const ch = xmlData[i];

    if (ch === '<') {
      if (xmlData[i + 1] === '/') {
        //Closing Tag
        const closeIndex = findClosingIndex(xmlData, ">", i, "Closing Tag is not closed.");
        let tagName = xmlData.substring(i + 2, closeIndex).trim();

        if (options.ignoreNameSpace) {
          const colonIndex = tagName.indexOf(":");

          if (colonIndex !== -1) {
            tagName = tagName.substr(colonIndex + 1);
          }
        }
        /* if (currentNode.parent) {
          currentNode.parent.val = util.getValue(currentNode.parent.val) + '' + processTagValue2(tagName, textData , options);
        } */


        if (currentNode) {
          if (currentNode.val) {
            currentNode.val = util$1.getValue(currentNode.val) + '' + processTagValue(tagName, textData, options);
          } else {
            currentNode.val = processTagValue(tagName, textData, options);
          }
        }

        if (options.stopNodes.length && options.stopNodes.includes(currentNode.tagname)) {
          currentNode.child = [];

          if (currentNode.attrsMap == undefined) {
            currentNode.attrsMap = {};
          }

          currentNode.val = xmlData.substr(currentNode.startIndex + 1, i - currentNode.startIndex - 1);
        }

        currentNode = currentNode.parent;
        textData = "";
        i = closeIndex;
      } else if (xmlData[i + 1] === '?') {
        i = findClosingIndex(xmlData, "?>", i, "Pi Tag is not closed.");
      } else if (xmlData.substr(i + 1, 3) === '!--') {
        i = findClosingIndex(xmlData, "-->", i, "Comment is not closed.");
      } else if (xmlData.substr(i + 1, 2) === '!D') {
        const closeIndex = findClosingIndex(xmlData, ">", i, "DOCTYPE is not closed.");
        const tagExp = xmlData.substring(i, closeIndex);

        if (tagExp.indexOf("[") >= 0) {
          i = xmlData.indexOf("]>", i) + 1;
        } else {
          i = closeIndex;
        }
      } else if (xmlData.substr(i + 1, 2) === '![') {
        const closeIndex = findClosingIndex(xmlData, "]]>", i, "CDATA is not closed.") - 2;
        const tagExp = xmlData.substring(i + 9, closeIndex); //considerations
        //1. CDATA will always have parent node
        //2. A tag with CDATA is not a leaf node so it's value would be string type.

        if (textData) {
          currentNode.val = util$1.getValue(currentNode.val) + '' + processTagValue(currentNode.tagname, textData, options);
          textData = "";
        }

        if (options.cdataTagName) {
          //add cdata node
          const childNode = new xmlNode(options.cdataTagName, currentNode, tagExp);
          currentNode.addChild(childNode); //for backtracking

          currentNode.val = util$1.getValue(currentNode.val) + options.cdataPositionChar; //add rest value to parent node

          if (tagExp) {
            childNode.val = tagExp;
          }
        } else {
          currentNode.val = (currentNode.val || '') + (tagExp || '');
        }

        i = closeIndex + 2;
      } else {
        //Opening tag
        const result = closingIndexForOpeningTag(xmlData, i + 1);
        let tagExp = result.data;
        const closeIndex = result.index;
        const separatorIndex = tagExp.indexOf(" ");
        let tagName = tagExp;

        if (separatorIndex !== -1) {
          tagName = tagExp.substr(0, separatorIndex).replace(/\s\s*$/, '');
          tagExp = tagExp.substr(separatorIndex + 1);
        }

        if (options.ignoreNameSpace) {
          const colonIndex = tagName.indexOf(":");

          if (colonIndex !== -1) {
            tagName = tagName.substr(colonIndex + 1);
          }
        } //save text to parent node


        if (currentNode && textData) {
          if (currentNode.tagname !== '!xml') {
            currentNode.val = util$1.getValue(currentNode.val) + '' + processTagValue(currentNode.tagname, textData, options);
          }
        }

        if (tagExp.length > 0 && tagExp.lastIndexOf("/") === tagExp.length - 1) {
          //selfClosing tag
          if (tagName[tagName.length - 1] === "/") {
            //remove trailing '/'
            tagName = tagName.substr(0, tagName.length - 1);
            tagExp = tagName;
          } else {
            tagExp = tagExp.substr(0, tagExp.length - 1);
          }

          const childNode = new xmlNode(tagName, currentNode, '');

          if (tagName !== tagExp) {
            childNode.attrsMap = buildAttributesMap(tagExp, options);
          }

          currentNode.addChild(childNode);
        } else {
          //opening tag
          const childNode = new xmlNode(tagName, currentNode);

          if (options.stopNodes.length && options.stopNodes.includes(childNode.tagname)) {
            childNode.startIndex = closeIndex;
          }

          if (tagName !== tagExp) {
            childNode.attrsMap = buildAttributesMap(tagExp, options);
          }

          currentNode.addChild(childNode);
          currentNode = childNode;
        }

        textData = "";
        i = closeIndex;
      }
    } else {
      textData += xmlData[i];
    }
  }

  return xmlObj;
};

function closingIndexForOpeningTag(data, i) {
  let attrBoundary;
  let tagExp = "";

  for (let index = i; index < data.length; index++) {
    let ch = data[index];

    if (attrBoundary) {
      if (ch === attrBoundary) attrBoundary = ""; //reset
    } else if (ch === '"' || ch === "'") {
      attrBoundary = ch;
    } else if (ch === '>') {
      return {
        data: tagExp,
        index: index
      };
    } else if (ch === '\t') {
      ch = " ";
    }

    tagExp += ch;
  }
}

function findClosingIndex(xmlData, str, i, errMsg) {
  const closingIndex = xmlData.indexOf(str, i);

  if (closingIndex === -1) {
    throw new Error(errMsg);
  } else {
    return closingIndex + str.length - 1;
  }
}

var getTraversalObj_1 = getTraversalObj;
var xmlstr2xmlnode = {
  defaultOptions: defaultOptions_1,
  props: props_1,
  getTraversalObj: getTraversalObj_1
};

const defaultOptions$1 = {
  allowBooleanAttributes: false //A tag can have attributes without any value

};
const props$1 = ['allowBooleanAttributes']; //const tagsPattern = new RegExp("<\\/?([\\w:\\-_\.]+)\\s*\/?>","g");

var validate$1 = function (xmlData, options) {
  options = util$1.buildOptions(options, defaultOptions$1, props$1); //xmlData = xmlData.replace(/(\r\n|\n|\r)/gm,"");//make it single line
  //xmlData = xmlData.replace(/(^\s*<\?xml.*?\?>)/g,"");//Remove XML starting tag
  //xmlData = xmlData.replace(/(<!DOCTYPE[\s\w\"\.\/\-\:]+(\[.*\])*\s*>)/g,"");//Remove DOCTYPE

  const tags = [];
  let tagFound = false; //indicates that the root tag has been closed (aka. depth 0 has been reached)

  let reachedRoot = false;

  if (xmlData[0] === '\ufeff') {
    // check for byte order mark (BOM)
    xmlData = xmlData.substr(1);
  }

  for (let i = 0; i < xmlData.length; i++) {
    if (xmlData[i] === '<' && xmlData[i + 1] === '?') {
      i += 2;
      i = readPI(xmlData, i);
      if (i.err) return i;
    } else if (xmlData[i] === '<') {
      //starting of tag
      //read until you reach to '>' avoiding any '>' in attribute value
      i++;

      if (xmlData[i] === '!') {
        i = readCommentAndCDATA(xmlData, i);
        continue;
      } else {
        let closingTag = false;

        if (xmlData[i] === '/') {
          //closing tag
          closingTag = true;
          i++;
        } //read tagname


        let tagName = '';

        for (; i < xmlData.length && xmlData[i] !== '>' && xmlData[i] !== ' ' && xmlData[i] !== '\t' && xmlData[i] !== '\n' && xmlData[i] !== '\r'; i++) {
          tagName += xmlData[i];
        }

        tagName = tagName.trim(); //console.log(tagName);

        if (tagName[tagName.length - 1] === '/') {
          //self closing tag without attributes
          tagName = tagName.substring(0, tagName.length - 1); //continue;

          i--;
        }

        if (!validateTagName(tagName)) {
          let msg;

          if (tagName.trim().length === 0) {
            msg = "There is an unnecessary space between tag name and backward slash '</ ..'.";
          } else {
            msg = "Tag '" + tagName + "' is an invalid name.";
          }

          return getErrorObject('InvalidTag', msg, getLineNumberForPosition(xmlData, i));
        }

        const result = readAttributeStr(xmlData, i);

        if (result === false) {
          return getErrorObject('InvalidAttr', "Attributes for '" + tagName + "' have open quote.", getLineNumberForPosition(xmlData, i));
        }

        let attrStr = result.value;
        i = result.index;

        if (attrStr[attrStr.length - 1] === '/') {
          //self closing tag
          attrStr = attrStr.substring(0, attrStr.length - 1);
          const isValid = validateAttributeString(attrStr, options);

          if (isValid === true) {
            tagFound = true; //continue; //text may presents after self closing tag
          } else {
            //the result from the nested function returns the position of the error within the attribute
            //in order to get the 'true' error line, we need to calculate the position where the attribute begins (i - attrStr.length) and then add the position within the attribute
            //this gives us the absolute index in the entire xml, which we can use to find the line at last
            return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, i - attrStr.length + isValid.err.line));
          }
        } else if (closingTag) {
          if (!result.tagClosed) {
            return getErrorObject('InvalidTag', "Closing tag '" + tagName + "' doesn't have proper closing.", getLineNumberForPosition(xmlData, i));
          } else if (attrStr.trim().length > 0) {
            return getErrorObject('InvalidTag', "Closing tag '" + tagName + "' can't have attributes or invalid starting.", getLineNumberForPosition(xmlData, i));
          } else {
            const otg = tags.pop();

            if (tagName !== otg) {
              return getErrorObject('InvalidTag', "Closing tag '" + otg + "' is expected inplace of '" + tagName + "'.", getLineNumberForPosition(xmlData, i));
            } //when there are no more tags, we reached the root level.


            if (tags.length == 0) {
              reachedRoot = true;
            }
          }
        } else {
          const isValid = validateAttributeString(attrStr, options);

          if (isValid !== true) {
            //the result from the nested function returns the position of the error within the attribute
            //in order to get the 'true' error line, we need to calculate the position where the attribute begins (i - attrStr.length) and then add the position within the attribute
            //this gives us the absolute index in the entire xml, which we can use to find the line at last
            return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, i - attrStr.length + isValid.err.line));
          } //if the root level has been reached before ...


          if (reachedRoot === true) {
            return getErrorObject('InvalidXml', 'Multiple possible root nodes found.', getLineNumberForPosition(xmlData, i));
          } else {
            tags.push(tagName);
          }

          tagFound = true;
        } //skip tag text value
        //It may include comments and CDATA value


        for (i++; i < xmlData.length; i++) {
          if (xmlData[i] === '<') {
            if (xmlData[i + 1] === '!') {
              //comment or CADATA
              i++;
              i = readCommentAndCDATA(xmlData, i);
              continue;
            } else if (xmlData[i + 1] === '?') {
              i = readPI(xmlData, ++i);
              if (i.err) return i;
            } else {
              break;
            }
          } else if (xmlData[i] === '&') {
            const afterAmp = validateAmpersand(xmlData, i);
            if (afterAmp == -1) return getErrorObject('InvalidChar', "char '&' is not expected.", getLineNumberForPosition(xmlData, i));
            i = afterAmp;
          }
        } //end of reading tag text value


        if (xmlData[i] === '<') {
          i--;
        }
      }
    } else {
      if (xmlData[i] === ' ' || xmlData[i] === '\t' || xmlData[i] === '\n' || xmlData[i] === '\r') {
        continue;
      }

      return getErrorObject('InvalidChar', "char '" + xmlData[i] + "' is not expected.", getLineNumberForPosition(xmlData, i));
    }
  }

  if (!tagFound) {
    return getErrorObject('InvalidXml', 'Start tag expected.', 1);
  } else if (tags.length > 0) {
    return getErrorObject('InvalidXml', "Invalid '" + JSON.stringify(tags, null, 4).replace(/\r?\n/g, '') + "' found.", 1);
  }

  return true;
};
/**
 * Read Processing insstructions and skip
 * @param {*} xmlData
 * @param {*} i
 */


function readPI(xmlData, i) {
  var start = i;

  for (; i < xmlData.length; i++) {
    if (xmlData[i] == '?' || xmlData[i] == ' ') {
      //tagname
      var tagname = xmlData.substr(start, i - start);

      if (i > 5 && tagname === 'xml') {
        return getErrorObject('InvalidXml', 'XML declaration allowed only at the start of the document.', getLineNumberForPosition(xmlData, i));
      } else if (xmlData[i] == '?' && xmlData[i + 1] == '>') {
        //check if valid attribut string
        i++;
        break;
      } else {
        continue;
      }
    }
  }

  return i;
}

function readCommentAndCDATA(xmlData, i) {
  if (xmlData.length > i + 5 && xmlData[i + 1] === '-' && xmlData[i + 2] === '-') {
    //comment
    for (i += 3; i < xmlData.length; i++) {
      if (xmlData[i] === '-' && xmlData[i + 1] === '-' && xmlData[i + 2] === '>') {
        i += 2;
        break;
      }
    }
  } else if (xmlData.length > i + 8 && xmlData[i + 1] === 'D' && xmlData[i + 2] === 'O' && xmlData[i + 3] === 'C' && xmlData[i + 4] === 'T' && xmlData[i + 5] === 'Y' && xmlData[i + 6] === 'P' && xmlData[i + 7] === 'E') {
    let angleBracketsCount = 1;

    for (i += 8; i < xmlData.length; i++) {
      if (xmlData[i] === '<') {
        angleBracketsCount++;
      } else if (xmlData[i] === '>') {
        angleBracketsCount--;

        if (angleBracketsCount === 0) {
          break;
        }
      }
    }
  } else if (xmlData.length > i + 9 && xmlData[i + 1] === '[' && xmlData[i + 2] === 'C' && xmlData[i + 3] === 'D' && xmlData[i + 4] === 'A' && xmlData[i + 5] === 'T' && xmlData[i + 6] === 'A' && xmlData[i + 7] === '[') {
    for (i += 8; i < xmlData.length; i++) {
      if (xmlData[i] === ']' && xmlData[i + 1] === ']' && xmlData[i + 2] === '>') {
        i += 2;
        break;
      }
    }
  }

  return i;
}

var doubleQuote = '"';
var singleQuote = "'";
/**
 * Keep reading xmlData until '<' is found outside the attribute value.
 * @param {string} xmlData
 * @param {number} i
 */

function readAttributeStr(xmlData, i) {
  let attrStr = '';
  let startChar = '';
  let tagClosed = false;

  for (; i < xmlData.length; i++) {
    if (xmlData[i] === doubleQuote || xmlData[i] === singleQuote) {
      if (startChar === '') {
        startChar = xmlData[i];
      } else if (startChar !== xmlData[i]) {
        //if vaue is enclosed with double quote then single quotes are allowed inside the value and vice versa
        continue;
      } else {
        startChar = '';
      }
    } else if (xmlData[i] === '>') {
      if (startChar === '') {
        tagClosed = true;
        break;
      }
    }

    attrStr += xmlData[i];
  }

  if (startChar !== '') {
    return false;
  }

  return {
    value: attrStr,
    index: i,
    tagClosed: tagClosed
  };
}
/**
 * Select all the attributes whether valid or invalid.
 */


const validAttrStrRegxp = new RegExp('(\\s*)([^\\s=]+)(\\s*=)?(\\s*([\'"])(([\\s\\S])*?)\\5)?', 'g'); //attr, ="sd", a="amit's", a="sd"b="saf", ab  cd=""

function validateAttributeString(attrStr, options) {
  //console.log("start:"+attrStr+":end");
  //if(attrStr.trim().length === 0) return true; //empty string
  const matches = util$1.getAllMatches(attrStr, validAttrStrRegxp);
  const attrNames = {};

  for (let i = 0; i < matches.length; i++) {
    if (matches[i][1].length === 0) {
      //nospace before attribute name: a="sd"b="saf"
      return getErrorObject('InvalidAttr', "Attribute '" + matches[i][2] + "' has no space in starting.", getPositionFromMatch(attrStr, matches[i][0]));
    } else if (matches[i][3] === undefined && !options.allowBooleanAttributes) {
      //independent attribute: ab
      return getErrorObject('InvalidAttr', "boolean attribute '" + matches[i][2] + "' is not allowed.", getPositionFromMatch(attrStr, matches[i][0]));
    }
    /* else if(matches[i][6] === undefined){//attribute without value: ab=
                    return { err: { code:"InvalidAttr",msg:"attribute " + matches[i][2] + " has no value assigned."}};
                } */


    const attrName = matches[i][2];

    if (!validateAttrName(attrName)) {
      return getErrorObject('InvalidAttr', "Attribute '" + attrName + "' is an invalid name.", getPositionFromMatch(attrStr, matches[i][0]));
    }

    if (!attrNames.hasOwnProperty(attrName)) {
      //check for duplicate attribute.
      attrNames[attrName] = 1;
    } else {
      return getErrorObject('InvalidAttr', "Attribute '" + attrName + "' is repeated.", getPositionFromMatch(attrStr, matches[i][0]));
    }
  }

  return true;
}

function validateNumberAmpersand(xmlData, i) {
  let re = /\d/;

  if (xmlData[i] === 'x') {
    i++;
    re = /[\da-fA-F]/;
  }

  for (; i < xmlData.length; i++) {
    if (xmlData[i] === ';') return i;
    if (!xmlData[i].match(re)) break;
  }

  return -1;
}

function validateAmpersand(xmlData, i) {
  // https://www.w3.org/TR/xml/#dt-charref
  i++;
  if (xmlData[i] === ';') return -1;

  if (xmlData[i] === '#') {
    i++;
    return validateNumberAmpersand(xmlData, i);
  }

  let count = 0;

  for (; i < xmlData.length; i++, count++) {
    if (xmlData[i].match(/\w/) && count < 20) continue;
    if (xmlData[i] === ';') break;
    return -1;
  }

  return i;
}

function getErrorObject(code, message, lineNumber) {
  return {
    err: {
      code: code,
      msg: message,
      line: lineNumber
    }
  };
}

function validateAttrName(attrName) {
  return util$1.isName(attrName);
} // const startsWithXML = /^xml/i;


function validateTagName(tagname) {
  return util$1.isName(tagname)
  /* && !tagname.match(startsWithXML) */
  ;
} //this function returns the line number for the character at the given index


function getLineNumberForPosition(xmlData, index) {
  var lines = xmlData.substring(0, index).split(/\r?\n/);
  return lines.length;
} //this function returns the position of the last character of match within attrStr


function getPositionFromMatch(attrStr, match) {
  return attrStr.indexOf(match) + match.length;
}

var validator = {
  validate: validate$1
};

const char = function (a) {
  return String.fromCharCode(a);
};

const chars = {
  nilChar: char(176),
  missingChar: char(201),
  nilPremitive: char(175),
  missingPremitive: char(200),
  emptyChar: char(178),
  emptyValue: char(177),
  //empty Premitive
  boundryChar: char(179),
  objStart: char(198),
  arrStart: char(204),
  arrayEnd: char(185)
};
const charsArr = [chars.nilChar, chars.nilPremitive, chars.missingChar, chars.missingPremitive, chars.boundryChar, chars.emptyChar, chars.emptyValue, chars.arrayEnd, chars.objStart, chars.arrStart];

const _e = function (node, e_schema, options) {
  if (typeof e_schema === 'string') {
    //premitive
    if (node && node[0] && node[0].val !== undefined) {
      return getValue(node[0].val);
    } else {
      return getValue(node);
    }
  } else {
    const hasValidData = hasData(node);

    if (hasValidData === true) {
      let str = '';

      if (Array.isArray(e_schema)) {
        //attributes can't be repeated. hence check in children tags only
        str += chars.arrStart;
        const itemSchema = e_schema[0]; //var itemSchemaType = itemSchema;

        const arr_len = node.length;

        if (typeof itemSchema === 'string') {
          for (let arr_i = 0; arr_i < arr_len; arr_i++) {
            const r = getValue(node[arr_i].val);
            str = processValue(str, r);
          }
        } else {
          for (let arr_i = 0; arr_i < arr_len; arr_i++) {
            const r = _e(node[arr_i], itemSchema, options);

            str = processValue(str, r);
          }
        }

        str += chars.arrayEnd; //indicates that next item is not array item
      } else {
        //object
        str += chars.objStart;
        const keys = Object.keys(e_schema);

        if (Array.isArray(node)) {
          node = node[0];
        }

        for (let i in keys) {
          const key = keys[i]; //a property defined in schema can be present either in attrsMap or children tags
          //options.textNodeName will not present in both maps, take it's value from val
          //options.attrNodeName will be present in attrsMap

          let r;

          if (!options.ignoreAttributes && node.attrsMap && node.attrsMap[key]) {
            r = _e(node.attrsMap[key], e_schema[key], options);
          } else if (key === options.textNodeName) {
            r = _e(node.val, e_schema[key], options);
          } else {
            r = _e(node.child[key], e_schema[key], options);
          }

          str = processValue(str, r);
        }
      }

      return str;
    } else {
      return hasValidData;
    }
  }
};

const getValue = function (a
/*, type*/
) {
  switch (a) {
    case undefined:
      return chars.missingPremitive;

    case null:
      return chars.nilPremitive;

    case '':
      return chars.emptyValue;

    default:
      return a;
  }
};

const processValue = function (str, r) {
  if (!isAppChar(r[0]) && !isAppChar(str[str.length - 1])) {
    str += chars.boundryChar;
  }

  return str + r;
};

const isAppChar = function (ch) {
  return charsArr.indexOf(ch) !== -1;
};

function hasData(jObj) {
  if (jObj === undefined) {
    return chars.missingChar;
  } else if (jObj === null) {
    return chars.nilChar;
  } else if (jObj.child && Object.keys(jObj.child).length === 0 && (!jObj.attrsMap || Object.keys(jObj.attrsMap).length === 0)) {
    return chars.emptyChar;
  } else {
    return true;
  }
}

const buildOptions$1 = util$1.buildOptions;

const convert2nimn = function (node, e_schema, options) {
  options = buildOptions$1(options, xmlstr2xmlnode.defaultOptions, xmlstr2xmlnode.props);
  return _e(node, e_schema, options);
};

var convert2nimn_1 = convert2nimn;
var nimndata = {
  convert2nimn: convert2nimn_1
};

const buildOptions$2 = util$1.buildOptions; //TODO: do it later

const convertToJsonString = function (node, options) {
  options = buildOptions$2(options, xmlstr2xmlnode.defaultOptions, xmlstr2xmlnode.props);
  options.indentBy = options.indentBy || '';
  return _cToJsonStr(node, options);
};

const _cToJsonStr = function (node, options, level) {
  let jObj = '{'; //traver through all the children

  const keys = Object.keys(node.child);

  for (let index = 0; index < keys.length; index++) {
    var tagname = keys[index];

    if (node.child[tagname] && node.child[tagname].length > 1) {
      jObj += '"' + tagname + '" : [ ';

      for (var tag in node.child[tagname]) {
        jObj += _cToJsonStr(node.child[tagname][tag], options) + ' , ';
      }

      jObj = jObj.substr(0, jObj.length - 1) + ' ] '; //remove extra comma in last
    } else {
      jObj += '"' + tagname + '" : ' + _cToJsonStr(node.child[tagname][0], options) + ' ,';
    }
  }

  util$1.merge(jObj, node.attrsMap); //add attrsMap as new children

  if (util$1.isEmptyObject(jObj)) {
    return util$1.isExist(node.val) ? node.val : '';
  } else {
    if (util$1.isExist(node.val)) {
      if (!(typeof node.val === 'string' && (node.val === '' || node.val === options.cdataPositionChar))) {
        jObj += '"' + options.textNodeName + '" : ' + stringval(node.val);
      }
    }
  } //add value


  if (jObj[jObj.length - 1] === ',') {
    jObj = jObj.substr(0, jObj.length - 2);
  }

  return jObj + '}';
};

function stringval(v) {
  if (v === true || v === false || !isNaN(v)) {
    return v;
  } else {
    return '"' + v + '"';
  }
}

var convertToJsonString_1 = convertToJsonString;
var node2json_str = {
  convertToJsonString: convertToJsonString_1
};

const buildOptions$3 = util$1.buildOptions;
const defaultOptions$2 = {
  attributeNamePrefix: '@_',
  attrNodeName: false,
  textNodeName: '#text',
  ignoreAttributes: true,
  cdataTagName: false,
  cdataPositionChar: '\\c',
  format: false,
  indentBy: '  ',
  supressEmptyNode: false,
  tagValueProcessor: function (a) {
    return a;
  },
  attrValueProcessor: function (a) {
    return a;
  }
};
const props$2 = ['attributeNamePrefix', 'attrNodeName', 'textNodeName', 'ignoreAttributes', 'cdataTagName', 'cdataPositionChar', 'format', 'indentBy', 'supressEmptyNode', 'tagValueProcessor', 'attrValueProcessor'];

function Parser(options) {
  this.options = buildOptions$3(options, defaultOptions$2, props$2);

  if (this.options.ignoreAttributes || this.options.attrNodeName) {
    this.isAttribute = function ()
    /*a*/
    {
      return false;
    };
  } else {
    this.attrPrefixLen = this.options.attributeNamePrefix.length;
    this.isAttribute = isAttribute;
  }

  if (this.options.cdataTagName) {
    this.isCDATA = isCDATA;
  } else {
    this.isCDATA = function ()
    /*a*/
    {
      return false;
    };
  }

  this.replaceCDATAstr = replaceCDATAstr;
  this.replaceCDATAarr = replaceCDATAarr;

  if (this.options.format) {
    this.indentate = indentate;
    this.tagEndChar = '>\n';
    this.newLine = '\n';
  } else {
    this.indentate = function () {
      return '';
    };

    this.tagEndChar = '>';
    this.newLine = '';
  }

  if (this.options.supressEmptyNode) {
    this.buildTextNode = buildEmptyTextNode;
    this.buildObjNode = buildEmptyObjNode;
  } else {
    this.buildTextNode = buildTextValNode;
    this.buildObjNode = buildObjectNode;
  }

  this.buildTextValNode = buildTextValNode;
  this.buildObjectNode = buildObjectNode;
}

Parser.prototype.parse = function (jObj) {
  return this.j2x(jObj, 0).val;
};

Parser.prototype.j2x = function (jObj, level) {
  let attrStr = '';
  let val = '';
  const keys = Object.keys(jObj);
  const len = keys.length;

  for (let i = 0; i < len; i++) {
    const key = keys[i];

    if (typeof jObj[key] === 'undefined') ; else if (jObj[key] === null) {
      val += this.indentate(level) + '<' + key + '/' + this.tagEndChar;
    } else if (jObj[key] instanceof Date) {
      val += this.buildTextNode(jObj[key], key, '', level);
    } else if (typeof jObj[key] !== 'object') {
      //premitive type
      const attr = this.isAttribute(key);

      if (attr) {
        attrStr += ' ' + attr + '="' + this.options.attrValueProcessor('' + jObj[key]) + '"';
      } else if (this.isCDATA(key)) {
        if (jObj[this.options.textNodeName]) {
          val += this.replaceCDATAstr(jObj[this.options.textNodeName], jObj[key]);
        } else {
          val += this.replaceCDATAstr('', jObj[key]);
        }
      } else {
        //tag value
        if (key === this.options.textNodeName) {
          if (jObj[this.options.cdataTagName]) ; else {
            val += this.options.tagValueProcessor('' + jObj[key]);
          }
        } else {
          val += this.buildTextNode(jObj[key], key, '', level);
        }
      }
    } else if (Array.isArray(jObj[key])) {
      //repeated nodes
      if (this.isCDATA(key)) {
        val += this.indentate(level);

        if (jObj[this.options.textNodeName]) {
          val += this.replaceCDATAarr(jObj[this.options.textNodeName], jObj[key]);
        } else {
          val += this.replaceCDATAarr('', jObj[key]);
        }
      } else {
        //nested nodes
        const arrLen = jObj[key].length;

        for (let j = 0; j < arrLen; j++) {
          const item = jObj[key][j];

          if (typeof item === 'undefined') ; else if (item === null) {
            val += this.indentate(level) + '<' + key + '/' + this.tagEndChar;
          } else if (typeof item === 'object') {
            const result = this.j2x(item, level + 1);
            val += this.buildObjNode(result.val, key, result.attrStr, level);
          } else {
            val += this.buildTextNode(item, key, '', level);
          }
        }
      }
    } else {
      //nested node
      if (this.options.attrNodeName && key === this.options.attrNodeName) {
        const Ks = Object.keys(jObj[key]);
        const L = Ks.length;

        for (let j = 0; j < L; j++) {
          attrStr += ' ' + Ks[j] + '="' + this.options.attrValueProcessor('' + jObj[key][Ks[j]]) + '"';
        }
      } else {
        const result = this.j2x(jObj[key], level + 1);
        val += this.buildObjNode(result.val, key, result.attrStr, level);
      }
    }
  }

  return {
    attrStr: attrStr,
    val: val
  };
};

function replaceCDATAstr(str, cdata) {
  str = this.options.tagValueProcessor('' + str);

  if (this.options.cdataPositionChar === '' || str === '') {
    return str + '<![CDATA[' + cdata + ']]' + this.tagEndChar;
  } else {
    return str.replace(this.options.cdataPositionChar, '<![CDATA[' + cdata + ']]' + this.tagEndChar);
  }
}

function replaceCDATAarr(str, cdata) {
  str = this.options.tagValueProcessor('' + str);

  if (this.options.cdataPositionChar === '' || str === '') {
    return str + '<![CDATA[' + cdata.join(']]><![CDATA[') + ']]' + this.tagEndChar;
  } else {
    for (let v in cdata) {
      str = str.replace(this.options.cdataPositionChar, '<![CDATA[' + cdata[v] + ']]>');
    }

    return str + this.newLine;
  }
}

function buildObjectNode(val, key, attrStr, level) {
  if (attrStr && !val.includes('<')) {
    return this.indentate(level) + '<' + key + attrStr + '>' + val + //+ this.newLine
    // + this.indentate(level)
    '</' + key + this.tagEndChar;
  } else {
    return this.indentate(level) + '<' + key + attrStr + this.tagEndChar + val + //+ this.newLine
    this.indentate(level) + '</' + key + this.tagEndChar;
  }
}

function buildEmptyObjNode(val, key, attrStr, level) {
  if (val !== '') {
    return this.buildObjectNode(val, key, attrStr, level);
  } else {
    return this.indentate(level) + '<' + key + attrStr + '/' + this.tagEndChar; //+ this.newLine
  }
}

function buildTextValNode(val, key, attrStr, level) {
  return this.indentate(level) + '<' + key + attrStr + '>' + this.options.tagValueProcessor(val) + '</' + key + this.tagEndChar;
}

function buildEmptyTextNode(val, key, attrStr, level) {
  if (val !== '') {
    return this.buildTextValNode(val, key, attrStr, level);
  } else {
    return this.indentate(level) + '<' + key + attrStr + '/' + this.tagEndChar;
  }
}

function indentate(level) {
  return this.options.indentBy.repeat(level);
}

function isAttribute(name
/*, options*/
) {
  if (name.startsWith(this.options.attributeNamePrefix)) {
    return name.substr(this.attrPrefixLen);
  } else {
    return false;
  }
}

function isCDATA(name) {
  return name === this.options.cdataTagName;
} //formatting
//indentation
//\n after each closing or self closing tag


var json2xml = Parser;

var parser = createCommonjsModule(function (module, exports) {

  const x2xmlnode = xmlstr2xmlnode;
  const buildOptions = util$1.buildOptions;

  exports.parse = function (xmlData, options, validationOption) {
    if (validationOption) {
      if (validationOption === true) validationOption = {};
      const result = validator.validate(xmlData, validationOption);

      if (result !== true) {
        throw Error(result.err.msg);
      }
    }

    options = buildOptions(options, x2xmlnode.defaultOptions, x2xmlnode.props);
    const traversableObj = xmlstr2xmlnode.getTraversalObj(xmlData, options); //print(traversableObj, "  ");

    return node2json.convertToJson(traversableObj, options);
  };

  exports.convertTonimn = nimndata.convert2nimn;
  exports.getTraversalObj = xmlstr2xmlnode.getTraversalObj;
  exports.convertToJson = node2json.convertToJson;
  exports.convertToJsonString = node2json_str.convertToJsonString;
  exports.validate = validator.validate;
  exports.j2xParser = json2xml;

  exports.parseToNimn = function (xmlData, schema, options) {
    return exports.convertTonimn(exports.getTraversalObj(xmlData, options), schema, options);
  };
});

var serializeAws_restXmlHeadObjectCommand=function(input,context){return __awaiter(void 0,void 0,void 0,function(){var headers,resolvedPath,labelValue,labelValue,query,body,_a,hostname,_b,protocol,port;return __generator(this,function(_c){switch(_c.label){case 0:headers=__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign({},isSerializableHeaderValue(input.IfMatch)&&{"if-match":input.IfMatch}),isSerializableHeaderValue(input.IfModifiedSince)&&{"if-modified-since":dateToUtcString(input.IfModifiedSince).toString()}),isSerializableHeaderValue(input.IfNoneMatch)&&{"if-none-match":input.IfNoneMatch}),isSerializableHeaderValue(input.IfUnmodifiedSince)&&{"if-unmodified-since":dateToUtcString(input.IfUnmodifiedSince).toString()}),isSerializableHeaderValue(input.Range)&&{range:input.Range}),isSerializableHeaderValue(input.SSECustomerAlgorithm)&&{"x-amz-server-side-encryption-customer-algorithm":input.SSECustomerAlgorithm}),isSerializableHeaderValue(input.SSECustomerKey)&&{"x-amz-server-side-encryption-customer-key":input.SSECustomerKey}),isSerializableHeaderValue(input.SSECustomerKeyMD5)&&{"x-amz-server-side-encryption-customer-key-md5":input.SSECustomerKeyMD5}),isSerializableHeaderValue(input.RequestPayer)&&{"x-amz-request-payer":input.RequestPayer}),isSerializableHeaderValue(input.ExpectedBucketOwner)&&{"x-amz-expected-bucket-owner":input.ExpectedBucketOwner});resolvedPath="/{Bucket}/{Key+}";if(input.Bucket!==undefined){labelValue=input.Bucket;if(labelValue.length<=0){throw new Error("Empty value provided for input HTTP label: Bucket.");}resolvedPath=resolvedPath.replace("{Bucket}",extendedEncodeURIComponent(labelValue));}else {throw new Error("No value provided for input HTTP label: Bucket.");}if(input.Key!==undefined){labelValue=input.Key;if(labelValue.length<=0){throw new Error("Empty value provided for input HTTP label: Key.");}resolvedPath=resolvedPath.replace("{Key+}",labelValue.split("/").map(function(segment){return extendedEncodeURIComponent(segment);}).join("/"));}else {throw new Error("No value provided for input HTTP label: Key.");}query=__assign(__assign({},input.VersionId!==undefined&&{versionId:input.VersionId}),input.PartNumber!==undefined&&{partNumber:input.PartNumber.toString()});return [4/*yield*/,context.endpoint()];case 1:_a=_c.sent(),hostname=_a.hostname,_b=_a.protocol,protocol=_b===void 0?"https":_b,port=_a.port;return [2/*return*/,new HttpRequest({protocol:protocol,hostname:hostname,port:port,method:"HEAD",headers:headers,path:resolvedPath,query:query,body:body})];}});});};var serializeAws_restXmlPutObjectCommand=function(input,context){return __awaiter(void 0,void 0,void 0,function(){var headers,resolvedPath,labelValue,labelValue,query,body,contents,_a,hostname,_b,protocol,port;return __generator(this,function(_c){switch(_c.label){case 0:headers=__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign(__assign({"content-type":"application/octet-stream"},isSerializableHeaderValue(input.ACL)&&{"x-amz-acl":input.ACL}),isSerializableHeaderValue(input.CacheControl)&&{"cache-control":input.CacheControl}),isSerializableHeaderValue(input.ContentDisposition)&&{"content-disposition":input.ContentDisposition}),isSerializableHeaderValue(input.ContentEncoding)&&{"content-encoding":input.ContentEncoding}),isSerializableHeaderValue(input.ContentLanguage)&&{"content-language":input.ContentLanguage}),isSerializableHeaderValue(input.ContentLength)&&{"content-length":input.ContentLength.toString()}),isSerializableHeaderValue(input.ContentMD5)&&{"content-md5":input.ContentMD5}),isSerializableHeaderValue(input.ContentType)&&{"content-type":input.ContentType}),isSerializableHeaderValue(input.Expires)&&{expires:dateToUtcString(input.Expires).toString()}),isSerializableHeaderValue(input.GrantFullControl)&&{"x-amz-grant-full-control":input.GrantFullControl}),isSerializableHeaderValue(input.GrantRead)&&{"x-amz-grant-read":input.GrantRead}),isSerializableHeaderValue(input.GrantReadACP)&&{"x-amz-grant-read-acp":input.GrantReadACP}),isSerializableHeaderValue(input.GrantWriteACP)&&{"x-amz-grant-write-acp":input.GrantWriteACP}),isSerializableHeaderValue(input.ServerSideEncryption)&&{"x-amz-server-side-encryption":input.ServerSideEncryption}),isSerializableHeaderValue(input.StorageClass)&&{"x-amz-storage-class":input.StorageClass}),isSerializableHeaderValue(input.WebsiteRedirectLocation)&&{"x-amz-website-redirect-location":input.WebsiteRedirectLocation}),isSerializableHeaderValue(input.SSECustomerAlgorithm)&&{"x-amz-server-side-encryption-customer-algorithm":input.SSECustomerAlgorithm}),isSerializableHeaderValue(input.SSECustomerKey)&&{"x-amz-server-side-encryption-customer-key":input.SSECustomerKey}),isSerializableHeaderValue(input.SSECustomerKeyMD5)&&{"x-amz-server-side-encryption-customer-key-md5":input.SSECustomerKeyMD5}),isSerializableHeaderValue(input.SSEKMSKeyId)&&{"x-amz-server-side-encryption-aws-kms-key-id":input.SSEKMSKeyId}),isSerializableHeaderValue(input.SSEKMSEncryptionContext)&&{"x-amz-server-side-encryption-context":input.SSEKMSEncryptionContext}),isSerializableHeaderValue(input.BucketKeyEnabled)&&{"x-amz-server-side-encryption-bucket-key-enabled":input.BucketKeyEnabled.toString()}),isSerializableHeaderValue(input.RequestPayer)&&{"x-amz-request-payer":input.RequestPayer}),isSerializableHeaderValue(input.Tagging)&&{"x-amz-tagging":input.Tagging}),isSerializableHeaderValue(input.ObjectLockMode)&&{"x-amz-object-lock-mode":input.ObjectLockMode}),isSerializableHeaderValue(input.ObjectLockRetainUntilDate)&&{"x-amz-object-lock-retain-until-date":(input.ObjectLockRetainUntilDate.toISOString().split(".")[0]+"Z").toString()}),isSerializableHeaderValue(input.ObjectLockLegalHoldStatus)&&{"x-amz-object-lock-legal-hold":input.ObjectLockLegalHoldStatus}),isSerializableHeaderValue(input.ExpectedBucketOwner)&&{"x-amz-expected-bucket-owner":input.ExpectedBucketOwner}),input.Metadata!==undefined&&Object.keys(input.Metadata).reduce(function(acc,suffix){var _a;return __assign(__assign({},acc),(_a={},_a["x-amz-meta-"+suffix.toLowerCase()]=input.Metadata[suffix],_a));},{}));resolvedPath="/{Bucket}/{Key+}";if(input.Bucket!==undefined){labelValue=input.Bucket;if(labelValue.length<=0){throw new Error("Empty value provided for input HTTP label: Bucket.");}resolvedPath=resolvedPath.replace("{Bucket}",extendedEncodeURIComponent(labelValue));}else {throw new Error("No value provided for input HTTP label: Bucket.");}if(input.Key!==undefined){labelValue=input.Key;if(labelValue.length<=0){throw new Error("Empty value provided for input HTTP label: Key.");}resolvedPath=resolvedPath.replace("{Key+}",labelValue.split("/").map(function(segment){return extendedEncodeURIComponent(segment);}).join("/"));}else {throw new Error("No value provided for input HTTP label: Key.");}query={"x-id":"PutObject"};if(input.Body!==undefined){contents=input.Body;body=contents;}return [4/*yield*/,context.endpoint()];case 1:_a=_c.sent(),hostname=_a.hostname,_b=_a.protocol,protocol=_b===void 0?"https":_b,port=_a.port;return [2/*return*/,new HttpRequest({protocol:protocol,hostname:hostname,port:port,method:"PUT",headers:headers,path:resolvedPath,query:query,body:body})];}});});};var deserializeAws_restXmlHeadObjectCommand=function(output,context){return __awaiter(void 0,void 0,void 0,function(){var contents;return __generator(this,function(_a){switch(_a.label){case 0:if(output.statusCode!==200&&output.statusCode>=300){return [2/*return*/,deserializeAws_restXmlHeadObjectCommandError(output,context)];}contents={$metadata:deserializeMetadata(output),AcceptRanges:undefined,ArchiveStatus:undefined,BucketKeyEnabled:undefined,CacheControl:undefined,ContentDisposition:undefined,ContentEncoding:undefined,ContentLanguage:undefined,ContentLength:undefined,ContentType:undefined,DeleteMarker:undefined,ETag:undefined,Expiration:undefined,Expires:undefined,LastModified:undefined,Metadata:undefined,MissingMeta:undefined,ObjectLockLegalHoldStatus:undefined,ObjectLockMode:undefined,ObjectLockRetainUntilDate:undefined,PartsCount:undefined,ReplicationStatus:undefined,RequestCharged:undefined,Restore:undefined,SSECustomerAlgorithm:undefined,SSECustomerKeyMD5:undefined,SSEKMSKeyId:undefined,ServerSideEncryption:undefined,StorageClass:undefined,VersionId:undefined,WebsiteRedirectLocation:undefined};if(output.headers["x-amz-delete-marker"]!==undefined){contents.DeleteMarker=output.headers["x-amz-delete-marker"]==="true";}if(output.headers["accept-ranges"]!==undefined){contents.AcceptRanges=output.headers["accept-ranges"];}if(output.headers["x-amz-expiration"]!==undefined){contents.Expiration=output.headers["x-amz-expiration"];}if(output.headers["x-amz-restore"]!==undefined){contents.Restore=output.headers["x-amz-restore"];}if(output.headers["x-amz-archive-status"]!==undefined){contents.ArchiveStatus=output.headers["x-amz-archive-status"];}if(output.headers["last-modified"]!==undefined){contents.LastModified=new Date(output.headers["last-modified"]);}if(output.headers["content-length"]!==undefined){contents.ContentLength=parseInt(output.headers["content-length"],10);}if(output.headers["etag"]!==undefined){contents.ETag=output.headers["etag"];}if(output.headers["x-amz-missing-meta"]!==undefined){contents.MissingMeta=parseInt(output.headers["x-amz-missing-meta"],10);}if(output.headers["x-amz-version-id"]!==undefined){contents.VersionId=output.headers["x-amz-version-id"];}if(output.headers["cache-control"]!==undefined){contents.CacheControl=output.headers["cache-control"];}if(output.headers["content-disposition"]!==undefined){contents.ContentDisposition=output.headers["content-disposition"];}if(output.headers["content-encoding"]!==undefined){contents.ContentEncoding=output.headers["content-encoding"];}if(output.headers["content-language"]!==undefined){contents.ContentLanguage=output.headers["content-language"];}if(output.headers["content-type"]!==undefined){contents.ContentType=output.headers["content-type"];}if(output.headers["expires"]!==undefined){contents.Expires=new Date(output.headers["expires"]);}if(output.headers["x-amz-website-redirect-location"]!==undefined){contents.WebsiteRedirectLocation=output.headers["x-amz-website-redirect-location"];}if(output.headers["x-amz-server-side-encryption"]!==undefined){contents.ServerSideEncryption=output.headers["x-amz-server-side-encryption"];}if(output.headers["x-amz-server-side-encryption-customer-algorithm"]!==undefined){contents.SSECustomerAlgorithm=output.headers["x-amz-server-side-encryption-customer-algorithm"];}if(output.headers["x-amz-server-side-encryption-customer-key-md5"]!==undefined){contents.SSECustomerKeyMD5=output.headers["x-amz-server-side-encryption-customer-key-md5"];}if(output.headers["x-amz-server-side-encryption-aws-kms-key-id"]!==undefined){contents.SSEKMSKeyId=output.headers["x-amz-server-side-encryption-aws-kms-key-id"];}if(output.headers["x-amz-server-side-encryption-bucket-key-enabled"]!==undefined){contents.BucketKeyEnabled=output.headers["x-amz-server-side-encryption-bucket-key-enabled"]==="true";}if(output.headers["x-amz-storage-class"]!==undefined){contents.StorageClass=output.headers["x-amz-storage-class"];}if(output.headers["x-amz-request-charged"]!==undefined){contents.RequestCharged=output.headers["x-amz-request-charged"];}if(output.headers["x-amz-replication-status"]!==undefined){contents.ReplicationStatus=output.headers["x-amz-replication-status"];}if(output.headers["x-amz-mp-parts-count"]!==undefined){contents.PartsCount=parseInt(output.headers["x-amz-mp-parts-count"],10);}if(output.headers["x-amz-object-lock-mode"]!==undefined){contents.ObjectLockMode=output.headers["x-amz-object-lock-mode"];}if(output.headers["x-amz-object-lock-retain-until-date"]!==undefined){contents.ObjectLockRetainUntilDate=new Date(output.headers["x-amz-object-lock-retain-until-date"]);}if(output.headers["x-amz-object-lock-legal-hold"]!==undefined){contents.ObjectLockLegalHoldStatus=output.headers["x-amz-object-lock-legal-hold"];}Object.keys(output.headers).forEach(function(header){if(contents.Metadata===undefined){contents.Metadata={};}if(header.startsWith("x-amz-meta-")){contents.Metadata[header.substring(11)]=output.headers[header];}});return [4/*yield*/,collectBody(output.body,context)];case 1:_a.sent();return [2/*return*/,Promise.resolve(contents)];}});});};var deserializeAws_restXmlHeadObjectCommandError=function(output,context){return __awaiter(void 0,void 0,void 0,function(){var parsedOutput,_a,response,errorCode,_b,_c,parsedBody,message;var _d;return __generator(this,function(_e){switch(_e.label){case 0:_a=[__assign({},output)];_d={};return [4/*yield*/,parseBody(output.body,context)];case 1:parsedOutput=__assign.apply(void 0,_a.concat([(_d.body=_e.sent(),_d)]));errorCode="UnknownError";errorCode=loadRestXmlErrorCode(output,parsedOutput.body);_b=errorCode;switch(_b){case"NoSuchKey":return [3/*break*/,2];case"com.amazonaws.s3#NoSuchKey":return [3/*break*/,2];}return [3/*break*/,4];case 2:_c=[{}];return [4/*yield*/,deserializeAws_restXmlNoSuchKeyResponse(parsedOutput)];case 3:response=__assign.apply(void 0,[__assign.apply(void 0,_c.concat([_e.sent()])),{name:errorCode,$metadata:deserializeMetadata(output)}]);return [3/*break*/,5];case 4:parsedBody=parsedOutput.body;errorCode=parsedBody.code||parsedBody.Code||errorCode;response=__assign(__assign({},parsedBody),{name:""+errorCode,message:parsedBody.message||parsedBody.Message||errorCode,$fault:"client",$metadata:deserializeMetadata(output)});_e.label=5;case 5:message=response.message||response.Message||errorCode;response.message=message;delete response.Message;return [2/*return*/,Promise.reject(Object.assign(new Error(message),response))];}});});};var deserializeAws_restXmlPutObjectCommand=function(output,context){return __awaiter(void 0,void 0,void 0,function(){var contents;return __generator(this,function(_a){switch(_a.label){case 0:if(output.statusCode!==200&&output.statusCode>=300){return [2/*return*/,deserializeAws_restXmlPutObjectCommandError(output,context)];}contents={$metadata:deserializeMetadata(output),BucketKeyEnabled:undefined,ETag:undefined,Expiration:undefined,RequestCharged:undefined,SSECustomerAlgorithm:undefined,SSECustomerKeyMD5:undefined,SSEKMSEncryptionContext:undefined,SSEKMSKeyId:undefined,ServerSideEncryption:undefined,VersionId:undefined};if(output.headers["x-amz-expiration"]!==undefined){contents.Expiration=output.headers["x-amz-expiration"];}if(output.headers["etag"]!==undefined){contents.ETag=output.headers["etag"];}if(output.headers["x-amz-server-side-encryption"]!==undefined){contents.ServerSideEncryption=output.headers["x-amz-server-side-encryption"];}if(output.headers["x-amz-version-id"]!==undefined){contents.VersionId=output.headers["x-amz-version-id"];}if(output.headers["x-amz-server-side-encryption-customer-algorithm"]!==undefined){contents.SSECustomerAlgorithm=output.headers["x-amz-server-side-encryption-customer-algorithm"];}if(output.headers["x-amz-server-side-encryption-customer-key-md5"]!==undefined){contents.SSECustomerKeyMD5=output.headers["x-amz-server-side-encryption-customer-key-md5"];}if(output.headers["x-amz-server-side-encryption-aws-kms-key-id"]!==undefined){contents.SSEKMSKeyId=output.headers["x-amz-server-side-encryption-aws-kms-key-id"];}if(output.headers["x-amz-server-side-encryption-context"]!==undefined){contents.SSEKMSEncryptionContext=output.headers["x-amz-server-side-encryption-context"];}if(output.headers["x-amz-server-side-encryption-bucket-key-enabled"]!==undefined){contents.BucketKeyEnabled=output.headers["x-amz-server-side-encryption-bucket-key-enabled"]==="true";}if(output.headers["x-amz-request-charged"]!==undefined){contents.RequestCharged=output.headers["x-amz-request-charged"];}return [4/*yield*/,collectBody(output.body,context)];case 1:_a.sent();return [2/*return*/,Promise.resolve(contents)];}});});};var deserializeAws_restXmlPutObjectCommandError=function(output,context){return __awaiter(void 0,void 0,void 0,function(){var parsedOutput,_a,response,errorCode,parsedBody,message;var _b;return __generator(this,function(_c){switch(_c.label){case 0:_a=[__assign({},output)];_b={};return [4/*yield*/,parseBody(output.body,context)];case 1:parsedOutput=__assign.apply(void 0,_a.concat([(_b.body=_c.sent(),_b)]));errorCode="UnknownError";errorCode=loadRestXmlErrorCode(output,parsedOutput.body);switch(errorCode){default:parsedBody=parsedOutput.body;errorCode=parsedBody.code||parsedBody.Code||errorCode;response=__assign(__assign({},parsedBody),{name:""+errorCode,message:parsedBody.message||parsedBody.Message||errorCode,$fault:"client",$metadata:deserializeMetadata(output)});}message=response.message||response.Message||errorCode;response.message=message;delete response.Message;return [2/*return*/,Promise.reject(Object.assign(new Error(message),response))];}});});};var deserializeAws_restXmlNoSuchKeyResponse=function(parsedOutput,context){return __awaiter(void 0,void 0,void 0,function(){var contents;return __generator(this,function(_a){contents={name:"NoSuchKey",$fault:"client",$metadata:deserializeMetadata(parsedOutput)};parsedOutput.body;return [2/*return*/,contents];});});};var deserializeMetadata=function(output){var _a;return {httpStatusCode:output.statusCode,requestId:(_a=output.headers["x-amzn-requestid"])!==null&&_a!==void 0?_a:output.headers["x-amzn-request-id"],extendedRequestId:output.headers["x-amz-id-2"],cfId:output.headers["x-amz-cf-id"]};};// Collect low-level response body stream to Uint8Array.
var collectBody=function(streamBody,context){if(streamBody===void 0){streamBody=new Uint8Array();}if(streamBody instanceof Uint8Array){return Promise.resolve(streamBody);}return context.streamCollector(streamBody)||Promise.resolve(new Uint8Array());};// Encode Uint8Array data into string with utf-8.
var collectBodyString=function(streamBody,context){return collectBody(streamBody,context).then(function(body){return context.utf8Encoder(body);});};var isSerializableHeaderValue=function(value){return value!==undefined&&value!==null&&value!==""&&(!Object.getOwnPropertyNames(value).includes("length")||value.length!=0)&&(!Object.getOwnPropertyNames(value).includes("size")||value.size!=0);};var decodeEscapedXML=function(str){return str.replace(/&amp;/g,"&").replace(/&apos;/g,"'").replace(/&quot;/g,'"').replace(/&gt;/g,">").replace(/&lt;/g,"<");};var parseBody=function(streamBody,context){return collectBodyString(streamBody,context).then(function(encoded){if(encoded.length){var parsedObj=parser.parse(encoded,{attributeNamePrefix:"",ignoreAttributes:false,parseNodeValue:false,tagValueProcessor:function(val,tagName){return decodeEscapedXML(val);}});var textNodeName="#text";var key=Object.keys(parsedObj)[0];var parsedObjToReturn=parsedObj[key];if(parsedObjToReturn[textNodeName]){parsedObjToReturn[key]=parsedObjToReturn[textNodeName];delete parsedObjToReturn[textNodeName];}return getValueFromTextNode(parsedObjToReturn);}return {};});};var loadRestXmlErrorCode=function(output,data){if(data.Code!==undefined){return data.Code;}if(output.statusCode==404){return "NotFound";}return "";};

var deserializerMiddleware = function (options, deserializer) {
  return function (next, context) {
    return function (args) {
      return __awaiter$1(void 0, void 0, void 0, function () {
        var response, parsed;
        return __generator$1(this, function (_a) {
          switch (_a.label) {
            case 0:
              return [4
              /*yield*/
              , next(args)];

            case 1:
              response = _a.sent().response;
              return [4
              /*yield*/
              , deserializer(response, options)];

            case 2:
              parsed = _a.sent();
              return [2
              /*return*/
              , {
                response: response,
                output: parsed
              }];
          }
        });
      });
    };
  };
};

var serializerMiddleware = function (options, serializer) {
  return function (next, context) {
    return function (args) {
      return __awaiter$1(void 0, void 0, void 0, function () {
        var request;
        return __generator$1(this, function (_a) {
          switch (_a.label) {
            case 0:
              return [4
              /*yield*/
              , serializer(args.input, options)];

            case 1:
              request = _a.sent();
              return [2
              /*return*/
              , next(__assign$1(__assign$1({}, args), {
                request: request
              }))];
          }
        });
      });
    };
  };
};

var deserializerMiddlewareOption = {
  name: "deserializerMiddleware",
  step: "deserialize",
  tags: ["DESERIALIZER"],
  override: true
};
var serializerMiddlewareOption = {
  name: "serializerMiddleware",
  step: "serialize",
  tags: ["SERIALIZER"],
  override: true
};
function getSerdePlugin(config, serializer, deserializer) {
  return {
    applyToStack: function (commandStack) {
      commandStack.add(deserializerMiddleware(config, deserializer), deserializerMiddlewareOption);
      commandStack.add(serializerMiddleware(config, serializer), serializerMiddlewareOption);
    }
  };
}

function ssecMiddleware(options) {
  var _this = this;

  return function (next) {
    return function (args) {
      return __awaiter$1(_this, void 0, void 0, function () {
        var input, properties, properties_1, properties_1_1, prop, value, valueView, encoded, hash, _a, _b, _c, _d, e_1_1;

        var e_1, _e, _f;

        return __generator$1(this, function (_g) {
          switch (_g.label) {
            case 0:
              input = __assign$1({}, args.input);
              properties = [{
                target: "SSECustomerKey",
                hash: "SSECustomerKeyMD5"
              }, {
                target: "CopySourceSSECustomerKey",
                hash: "CopySourceSSECustomerKeyMD5"
              }];
              _g.label = 1;

            case 1:
              _g.trys.push([1, 6, 7, 8]);

              properties_1 = __values(properties), properties_1_1 = properties_1.next();
              _g.label = 2;

            case 2:
              if (!!properties_1_1.done) return [3
              /*break*/
              , 5];
              prop = properties_1_1.value;
              value = input[prop.target];
              if (!value) return [3
              /*break*/
              , 4];
              valueView = ArrayBuffer.isView(value) ? new Uint8Array(value.buffer, value.byteOffset, value.byteLength) : typeof value === "string" ? options.utf8Decoder(value) : new Uint8Array(value);
              encoded = options.base64Encoder(valueView);
              hash = new options.md5();
              hash.update(valueView);
              _a = [__assign$1({}, input)];
              _f = {}, _f[prop.target] = encoded;
              _b = prop.hash;
              _d = (_c = options).base64Encoder;
              return [4
              /*yield*/
              , hash.digest()];

            case 3:
              input = __assign$1.apply(void 0, _a.concat([(_f[_b] = _d.apply(_c, [_g.sent()]), _f)]));
              _g.label = 4;

            case 4:
              properties_1_1 = properties_1.next();
              return [3
              /*break*/
              , 2];

            case 5:
              return [3
              /*break*/
              , 8];

            case 6:
              e_1_1 = _g.sent();
              e_1 = {
                error: e_1_1
              };
              return [3
              /*break*/
              , 8];

            case 7:
              try {
                if (properties_1_1 && !properties_1_1.done && (_e = properties_1.return)) _e.call(properties_1);
              } finally {
                if (e_1) throw e_1.error;
              }

              return [7
              /*endfinally*/
              ];

            case 8:
              return [2
              /*return*/
              , next(__assign$1(__assign$1({}, args), {
                input: input
              }))];
          }
        });
      });
    };
  };
}
var ssecMiddlewareOptions = {
  name: "ssecMiddleware",
  step: "initialize",
  tags: ["SSE"],
  override: true
};
var getSsecPlugin = function (config) {
  return {
    applyToStack: function (clientStack) {
      clientStack.add(ssecMiddleware(config), ssecMiddlewareOptions);
    }
  };
};

/**
 * <p>The HEAD operation retrieves metadata from an object without returning the object
 *          itself. This operation is useful if you're only interested in an object's metadata. To use
 *          HEAD, you must have READ access to the object.</p>
 *
 *          <p>A <code>HEAD</code> request has the same options as a <code>GET</code> operation on an
 *          object. The response is identical to the <code>GET</code> response except that there is no
 *          response body.</p>
 *
 *          <p>If you encrypt an object by using server-side encryption with customer-provided
 *          encryption keys (SSE-C) when you store the object in Amazon S3, then when you retrieve the
 *          metadata from the object, you must use the following headers:</p>
 *          <ul>
 *             <li>
 *                <p>x-amz-server-side-encryption-customer-algorithm</p>
 *             </li>
 *             <li>
 *                <p>x-amz-server-side-encryption-customer-key</p>
 *             </li>
 *             <li>
 *                <p>x-amz-server-side-encryption-customer-key-MD5</p>
 *             </li>
 *          </ul>
 *          <p>For more information about SSE-C, see <a href="https://docs.aws.amazon.com/AmazonS3/latest/dev/ServerSideEncryptionCustomerKeys.html">Server-Side Encryption (Using
 *             Customer-Provided Encryption Keys)</a>.</p>
 *          <note>
 *             <p>Encryption request headers, like <code>x-amz-server-side-encryption</code>, should
 *             not be sent for GET requests if your object uses server-side encryption with CMKs stored
 *             in AWS KMS (SSE-KMS) or server-side encryption with Amazon S3–managed encryption keys
 *             (SSE-S3). If your object does use these types of keys, you’ll get an HTTP 400 BadRequest
 *             error.</p>
 *          </note>
 *
 *
 *
 *
 *
 *
 *
 *          <p>Request headers are limited to 8 KB in size. For more information, see <a href="https://docs.aws.amazon.com/AmazonS3/latest/API/RESTCommonRequestHeaders.html">Common Request
 *             Headers</a>.</p>
 *          <p>Consider the following when using request headers:</p>
 *          <ul>
 *             <li>
 *                <p> Consideration 1 – If both of the <code>If-Match</code> and
 *                   <code>If-Unmodified-Since</code> headers are present in the request as
 *                follows:</p>
 *                <ul>
 *                   <li>
 *                      <p>
 *                         <code>If-Match</code> condition evaluates to <code>true</code>, and;</p>
 *                   </li>
 *                   <li>
 *                      <p>
 *                         <code>If-Unmodified-Since</code> condition evaluates to
 *                      <code>false</code>;</p>
 *                   </li>
 *                </ul>
 *                <p>Then Amazon S3 returns <code>200 OK</code> and the data requested.</p>
 *             </li>
 *             <li>
 *                <p> Consideration 2 – If both of the <code>If-None-Match</code> and
 *                   <code>If-Modified-Since</code> headers are present in the request as
 *                follows:</p>
 *                <ul>
 *                   <li>
 *                      <p>
 *                         <code>If-None-Match</code> condition evaluates to <code>false</code>,
 *                      and;</p>
 *                   </li>
 *                   <li>
 *                      <p>
 *                         <code>If-Modified-Since</code> condition evaluates to
 *                      <code>true</code>;</p>
 *                   </li>
 *                </ul>
 *                <p>Then Amazon S3 returns the <code>304 Not Modified</code> response code.</p>
 *             </li>
 *          </ul>
 *
 *          <p>For more information about conditional requests, see <a href="https://tools.ietf.org/html/rfc7232">RFC 7232</a>.</p>
 *
 *          <p>
 *             <b>Permissions</b>
 *          </p>
 *          <p>You need the <code>s3:GetObject</code> permission for this operation. For more
 *          information, see <a href="https://docs.aws.amazon.com/AmazonS3/latest/dev/using-with-s3-actions.html">Specifying Permissions
 *             in a Policy</a>. If the object you request does not exist, the error Amazon S3 returns
 *          depends on whether you also have the s3:ListBucket permission.</p>
 *          <ul>
 *             <li>
 *                <p>If you have the <code>s3:ListBucket</code> permission on the bucket, Amazon S3 returns
 *                an HTTP status code 404 ("no such key") error.</p>
 *             </li>
 *             <li>
 *                <p>If you don’t have the <code>s3:ListBucket</code> permission, Amazon S3 returns an HTTP
 *                status code 403 ("access denied") error.</p>
 *             </li>
 *          </ul>
 *
 *          <p>The following operation is related to <code>HeadObject</code>:</p>
 *          <ul>
 *             <li>
 *                <p>
 *                   <a href="https://docs.aws.amazon.com/AmazonS3/latest/API/API_GetObject.html">GetObject</a>
 *                </p>
 *             </li>
 *          </ul>
 */

var HeadObjectCommand =
/** @class */
function (_super) {
  __extends(HeadObjectCommand, _super); // Start section: command_properties
  // End section: command_properties


  function HeadObjectCommand(input) {
    var _this = // Start section: command_constructor
    _super.call(this) || this;

    _this.input = input;
    return _this; // End section: command_constructor
  }
  /**
   * @internal
   */


  HeadObjectCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    this.middlewareStack.use(getSsecPlugin(configuration));
    this.middlewareStack.use(getBucketEndpointPlugin(configuration));
    var stack = clientStack.concat(this.middlewareStack);
    var logger = configuration.logger;
    var clientName = "S3Client";
    var commandName = "HeadObjectCommand";
    var handlerExecutionContext = {
      logger: logger,
      clientName: clientName,
      commandName: commandName,
      inputFilterSensitiveLog: HeadObjectRequest.filterSensitiveLog,
      outputFilterSensitiveLog: HeadObjectOutput.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function (request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };

  HeadObjectCommand.prototype.serialize = function (input, context) {
    return serializeAws_restXmlHeadObjectCommand(input, context);
  };

  HeadObjectCommand.prototype.deserialize = function (output, context) {
    return deserializeAws_restXmlHeadObjectCommand(output, context);
  };

  return HeadObjectCommand;
}(Command);

/**
 * <p>Adds an object to a bucket. You must have WRITE permissions on a bucket to add an object
 *          to it.</p>
 *
 *
 *          <p>Amazon S3 never adds partial objects; if you receive a success response, Amazon S3 added the
 *          entire object to the bucket.</p>
 *
 *          <p>Amazon S3 is a distributed system. If it receives multiple write requests for the same object
 *          simultaneously, it overwrites all but the last object written. Amazon S3 does not provide object
 *          locking; if you need this, make sure to build it into your application layer or use
 *          versioning instead.</p>
 *
 *          <p>To ensure that data is not corrupted traversing the network, use the
 *             <code>Content-MD5</code> header. When you use this header, Amazon S3 checks the object
 *          against the provided MD5 value and, if they do not match, returns an error. Additionally,
 *          you can calculate the MD5 while putting an object to Amazon S3 and compare the returned ETag to
 *          the calculated MD5 value.</p>
 *          <note>
 *             <p> The <code>Content-MD5</code> header is required for any request to upload an object
 *             with a retention period configured using Amazon S3 Object Lock. For more information about
 *             Amazon S3 Object Lock, see <a href="https://docs.aws.amazon.com/AmazonS3/latest/dev/object-lock-overview.html">Amazon S3 Object Lock Overview</a>
 *             in the <i>Amazon Simple Storage Service Developer Guide</i>. </p>
 *          </note>
 *
 *
 *          <p>
 *             <b>Server-side Encryption</b>
 *          </p>
 *          <p>You can optionally request server-side encryption. With server-side encryption, Amazon S3 encrypts your data as it writes it to disks in its data centers and decrypts the data
 *          when you access it. You have the option to provide your own encryption key or use AWS
 *          managed encryption keys (SSE-S3 or SSE-KMS). For more information, see <a href="https://docs.aws.amazon.com/AmazonS3/latest/dev/UsingServerSideEncryption.html">Using Server-Side
 *             Encryption</a>.</p>
 *          <p>If you request server-side encryption using AWS Key Management Service (SSE-KMS), you can enable an S3 Bucket Key at the object-level. For more information, see <a href="https://docs.aws.amazon.com/AmazonS3/latest/dev/bucket-key.html">Amazon S3 Bucket Keys</a> in the <i>Amazon Simple Storage Service Developer Guide</i>.</p>
 *          <p>
 *             <b>Access Control List (ACL)-Specific Request
 *          Headers</b>
 *          </p>
 *          <p>You can use headers to grant ACL- based permissions. By default, all objects are
 *          private. Only the owner has full access control. When adding a new object, you can grant
 *          permissions to individual AWS accounts or to predefined groups defined by Amazon S3. These
 *          permissions are then added to the ACL on the object. For more information, see <a href="https://docs.aws.amazon.com/AmazonS3/latest/dev/acl-overview.html">Access Control List
 *             (ACL) Overview</a> and <a href="https://docs.aws.amazon.com/AmazonS3/latest/dev/acl-using-rest-api.html">Managing ACLs Using the REST
 *             API</a>. </p>
 *
 *          <p>
 *             <b>Storage Class Options</b>
 *          </p>
 *          <p>By default, Amazon S3 uses the STANDARD Storage Class to store newly created objects. The
 *          STANDARD storage class provides high durability and high availability. Depending on
 *          performance needs, you can specify a different Storage Class. Amazon S3 on Outposts only uses
 *          the OUTPOSTS Storage Class. For more information, see <a href="https://docs.aws.amazon.com/AmazonS3/latest/dev/storage-class-intro.html">Storage Classes</a> in the <i>Amazon S3
 *             Service Developer Guide</i>.</p>
 *
 *
 *          <p>
 *             <b>Versioning</b>
 *          </p>
 *          <p>If you enable versioning for a bucket, Amazon S3 automatically generates a unique version ID
 *          for the object being stored. Amazon S3 returns this ID in the response. When you enable
 *          versioning for a bucket, if Amazon S3 receives multiple write requests for the same object
 *          simultaneously, it stores all of the objects.</p>
 *          <p>For more information about versioning, see <a href="https://docs.aws.amazon.com/AmazonS3/latest/dev/AddingObjectstoVersioningEnabledBuckets.html">Adding Objects to
 *             Versioning Enabled Buckets</a>. For information about returning the versioning state
 *          of a bucket, see <a href="https://docs.aws.amazon.com/AmazonS3/latest/API/API_GetBucketVersioning.html">GetBucketVersioning</a>. </p>
 *
 *
 *          <p class="title">
 *             <b>Related Resources</b>
 *          </p>
 *          <ul>
 *             <li>
 *                <p>
 *                   <a href="https://docs.aws.amazon.com/AmazonS3/latest/API/API_CopyObject.html">CopyObject</a>
 *                </p>
 *             </li>
 *             <li>
 *                <p>
 *                   <a href="https://docs.aws.amazon.com/AmazonS3/latest/API/API_DeleteObject.html">DeleteObject</a>
 *                </p>
 *             </li>
 *          </ul>
 */

var PutObjectCommand =
/** @class */
function (_super) {
  __extends(PutObjectCommand, _super); // Start section: command_properties
  // End section: command_properties


  function PutObjectCommand(input) {
    var _this = // Start section: command_constructor
    _super.call(this) || this;

    _this.input = input;
    return _this; // End section: command_constructor
  }
  /**
   * @internal
   */


  PutObjectCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    this.middlewareStack.use(getSsecPlugin(configuration));
    this.middlewareStack.use(getBucketEndpointPlugin(configuration));
    var stack = clientStack.concat(this.middlewareStack);
    var logger = configuration.logger;
    var clientName = "S3Client";
    var commandName = "PutObjectCommand";
    var handlerExecutionContext = {
      logger: logger,
      clientName: clientName,
      commandName: commandName,
      inputFilterSensitiveLog: PutObjectRequest.filterSensitiveLog,
      outputFilterSensitiveLog: PutObjectOutput.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function (request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };

  PutObjectCommand.prototype.serialize = function (input, context) {
    return serializeAws_restXmlPutObjectCommand(input, context);
  };

  PutObjectCommand.prototype.deserialize = function (output, context) {
    return deserializeAws_restXmlPutObjectCommand(output, context);
  };

  return PutObjectCommand;
}(Command);

var createError = createCommonjsModule(function (module, exports) {
  //     create-error.js 0.3.1
  //     (c) 2013 Tim Griesser
  //     This source may be freely distributed under the MIT license.
  (function (factory) {
    // object in multiple environments, while maintaining
    // relevant stack traces, messages, and prototypes.

    factory(function () {
      var toString = Object.prototype.toString; // Creates an new error type with a "name",
      // and any additional properties that should be set
      // on the error instance.

      return function () {
        var args = new Array(arguments.length);

        for (var i = 0; i < args.length; ++i) {
          args[i] = arguments[i];
        }

        var name = getName(args);
        var target = getTarget(args);
        var properties = getProps(args);

        function ErrorCtor(message, obj) {
          attachProps(this, properties);
          attachProps(this, obj);
          this.message = message || this.message;

          if (message instanceof Error) {
            this.message = message.message;
            this.stack = message.stack;
          } else if (Error.captureStackTrace) {
            Error.captureStackTrace(this, this.constructor);
          }
        }

        function Err() {
          this.constructor = ErrorCtor;
        }

        Err.prototype = target['prototype'];
        ErrorCtor.prototype = new Err();
        ErrorCtor.prototype.name = '' + name || 'CustomError';
        return ErrorCtor;
      }; // Just a few helpers to clean up the function above
      // https://github.com/petkaantonov/bluebird/wiki/Optimization-killers

      function getName(args) {
        if (args.length === 0) return '';
        return isError(args[0]) ? args[1] || '' : args[0];
      }

      function getTarget(args) {
        if (args.length === 0) return Error;
        return isError(args[0]) ? args[0] : Error;
      }

      function getProps(args) {
        if (args.length === 0) return null;
        return isError(args[0]) ? args[2] : args[1];
      }

      function inheritedKeys(obj) {
        var ret = [];

        for (var key in obj) {
          ret.push(key);
        }

        return ret;
      } // Right now we're just assuming that a function in the first argument is an error.


      function isError(obj) {
        return typeof obj === "function";
      } // We don't need the full underscore check here, since it should either be
      // an object-literal, or nothing at all.


      function isObject(obj) {
        return obj && typeof obj === "object" && toString.call(obj) === "[object Object]";
      } // Used to attach attributes to the error object in the constructor.


      function attachProps(context, target) {
        if (isObject(target)) {
          var keys = inheritedKeys(target);

          for (var i = 0, l = keys.length; i < l; ++i) {
            context[keys[i]] = clone(target[keys[i]]);
          }
        }
      } // Don't need the full-out "clone" mechanism here, since if you're
      // trying to set things other than empty arrays/objects on your
      // sub-classed `Error` object, you're probably doing it wrong.


      function clone(target) {
        if (target == null || typeof target !== "object") return target;
        var cloned = target.constructor ? target.constructor() : Object.create(null);

        for (var attr in target) {
          if (target.hasOwnProperty(attr)) {
            cloned[attr] = target[attr];
          }
        }

        return cloned;
      }
    }); // Boilerplate UMD definition block...
  })(function (createErrorLib) {
    {
      module.exports = createErrorLib();
    }
  });
});

const randomBytesAsync = util$2.promisify(crypto.randomBytes);
const RandomGenerationError = createError('RandomGenerationError', {
  code: 'RandomGenerationError'
});

function calculateParameters(range) {
  /* This does the equivalent of:
   *
   *    bitsNeeded = Math.ceil(Math.log2(range));
   *    bytesNeeded = Math.ceil(bitsNeeded / 8);
   *    mask = Math.pow(2, bitsNeeded) - 1;
   *
   * ... however, it implements it as bitwise operations, to sidestep any
   * possible implementation errors regarding floating point numbers in
   * JavaScript runtimes. This is an easier solution than assessing each
   * runtime and architecture individually.
   */
  let bitsNeeded = 0;
  let bytesNeeded = 0;
  let mask = 1;

  while (range > 0) {
    if (bitsNeeded % 8 === 0) {
      bytesNeeded += 1;
    }

    bitsNeeded += 1;
    mask = mask << 1 | 1;
    /* 0x00001111 -> 0x00011111 */

    /* SECURITY PATCH (March 8, 2016):
     *   As it turns out, `>>` is not the right operator to use here, and
     *   using it would cause strange outputs, that wouldn't fall into
     *   the specified range. This was remedied by switching to `>>>`
     *   instead, and adding checks for input parameters being within the
     *   range of 'safe integers' in JavaScript.
     */

    range = range >>> 1;
    /* 0x01000000 -> 0x00100000 */
  }

  return {
    bitsNeeded,
    bytesNeeded,
    mask
  };
}

async function secureRandomNumber(minimum, maximum) {
  if (minimum == null) {
    throw new RandomGenerationError('You must specify a minimum value.');
  }

  if (maximum == null) {
    throw new RandomGenerationError('You must specify a maximum value.');
  }

  if (minimum % 1 !== 0) {
    throw new RandomGenerationError('The minimum value must be an integer.');
  }

  if (maximum % 1 !== 0) {
    throw new RandomGenerationError('The maximum value must be an integer.');
  }

  if (!(maximum > minimum)) {
    throw new RandomGenerationError('The maximum value must be higher than the minimum value.');
  }
  /* We hardcode the values for the following:
   *
   *   https://developer.mozilla.org/en/docs/Web/JavaScript/Reference/Global_Objects/Number/MIN_SAFE_INTEGER
   *   https://developer.mozilla.org/en/docs/Web/JavaScript/Reference/Global_Objects/Number/MAX_SAFE_INTEGER
   *
   * ... as Babel does not appear to transpile them, despite being ES6.
   */


  if (minimum < -9007199254740991 || minimum > 9007199254740991) {
    throw new RandomGenerationError('The minimum value must be inbetween MIN_SAFE_INTEGER and MAX_SAFE_INTEGER.');
  }

  if (maximum < -9007199254740991 || maximum > 9007199254740991) {
    throw new RandomGenerationError('The maximum value must be inbetween MIN_SAFE_INTEGER and MAX_SAFE_INTEGER.');
  }

  let range = maximum - minimum;

  if (range < -9007199254740991 || range > 9007199254740991) {
    throw new RandomGenerationError('The range between the minimum and maximum value must be inbetween MIN_SAFE_INTEGER and MAX_SAFE_INTEGER.');
  }

  let {
    bitsNeeded,
    bytesNeeded,
    mask
  } = calculateParameters(range);
  const randomBytes = await randomBytesAsync(bytesNeeded);
  let randomValue = 0;
  /* Turn the random bytes into an integer, using bitwise operations. */

  for (let i = 0; i < bytesNeeded; i++) {
    randomValue |= randomBytes[i] << 8 * i;
  }
  /* We apply the mask to reduce the amount of attempts we might need
   * to make to get a number that is in range. This is somewhat like
   * the commonly used 'modulo trick', but without the bias:
   *
   *   "Let's say you invoke secure_rand(0, 60). When the other code
   *    generates a random integer, you might get 243. If you take
   *    (243 & 63)-- noting that the mask is 63-- you get 51. Since
   *    51 is less than 60, we can return this without bias. If we
   *    got 255, then 255 & 63 is 63. 63 > 60, so we try again.
   *
   *    The purpose of the mask is to reduce the number of random
   *    numbers discarded for the sake of ensuring an unbiased
   *    distribution. In the example above, 243 would discard, but
   *    (243 & 63) is in the range of 0 and 60."
   *
   *   (Source: Scott Arciszewski)
   */


  randomValue = randomValue & mask;

  if (randomValue <= range) {
    /* We've been working with 0 as a starting point, so we need to
     * add the `minimum` here. */
    return minimum + randomValue;
  } else {
    /* Outside of the acceptable range, throw it away and try again.
     * We don't try any modulo tricks, as this would introduce bias. */
    return secureRandomNumber(minimum, maximum);
  }
}

const bucket = process.env['OULIPO_BUCKET'];
const region = process.env['OULIPO_REGION'];
const prefix = process.env['OULIPO_PREFIX'];
const cdn_prefix = process.env['OULIPO_CDN_PREFIX'];
const chars$1 = 'abcdfghjijklmnopqrstuvwxyzABCDFGHIJKLMNOPQRSTUVWXYZ0123456789';

const randomChar = async () => chars$1[await secureRandomNumber(0, chars$1.length)];

const generate = () => Promise.all(new Array(6).fill(0).map(randomChar)).then(chars => chars.join(''));

const s3 = new S3Client({
  region
});
const responseHeaders = {
  'content-type': 'application/json',
  'cache-control': 'private,no-cache'
};

const errorResponse = error => ({
  statusCode: 400,
  body: JSON.stringify({
    error
  }),
  headers: responseHeaders
});

const successResponse = (url_long, url_short) => ({
  statusCode: 200,
  body: JSON.stringify({
    url_long: url_long,
    url_short: url_short
  }),
  headers: responseHeaders
});

const objectExists = Key => s3.send(new HeadObjectCommand({
  Bucket: bucket,
  Key
})).then(() => true, err => {
  if ('name' in err && err.name === 'NotFound') {
    return false;
  } else {
    return Promise.reject(err);
  }
});

const validUrl = url$1 => {
  if (typeof url$1 !== 'string') {
    return false;
  }

  try {
    const url_check = new url.URL(url$1);
    return !!(url_check && url_check.host && ['https:', 'http:'].indexOf(url_check.protocol) >= 0);
  } catch {
    return false;
  }
};

const checkAndCreateRedirect = async (url_long) => {
  let retry = 0;

  do {
    retry += 1;
    const id_short = await generate();
    const key_short = prefix + '/' + id_short;

    if (await objectExists(key_short)) {
      continue;
    }

    await s3.send(new PutObjectCommand({
      Bucket: bucket,
      Key: key_short,
      Body: '',
      WebsiteRedirectLocation: url_long,
      ContentType: 'text/plain',
      CacheControl: 'public, max-age=315576000'
    }));
    const ret_url = 'https://' + cdn_prefix + '/' + id_short;
    console.log('Okay! short_url = ' + ret_url);
    return ret_url;
  } while (retry <= 3);

  throw new Error('Cannot find a good short id, aborting.');
};

const handler = async event => {
  const {
    cdn_prefix: input_cdn_prefix,
    url_long
  } = JSON.parse(event.body ?? '');

  if (input_cdn_prefix !== cdn_prefix) {
    return errorResponse('Invalid CDN location');
  }

  if (!validUrl(url_long)) {
    return errorResponse('Missing or invalid URL format');
  }

  console.log('shrinking ' + url_long);

  try {
    const url_short = await checkAndCreateRedirect(url_long);
    return successResponse(url_long, url_short);
  } catch (e) {
    console.error(e);
    let message;

    if (typeof e === 'string') {
      message = e;
    } else if ('message' in e && typeof e.message === 'string') {
      message = e.message;
    } else {
      message = "It didn't work.";
    }

    return errorResponse(message);
  }
};

exports.handler = handler;
//# sourceMappingURL=index.js.map
